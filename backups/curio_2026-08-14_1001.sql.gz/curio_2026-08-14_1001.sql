--
-- PostgreSQL database dump
--

\restrict MYb0vGVg88gallReJ6QMCYz96diqSY51a28ZIkh5djWeRRvkI7CcQaMKLHKf87N

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text,
	negate boolean
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: send_binary(bytea, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: wal2json_escape_identifier(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.wal2json_escape_identifier(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    custom_claims_allowlist text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: account_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_licenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid,
    type text NOT NULL,
    quantity integer,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: assessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assessments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    email text,
    type text,
    h_score integer,
    w_score integer,
    y_score integer,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    token text,
    company text,
    role text
);


--
-- Name: career_guidance_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.career_guidance_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    profile text NOT NULL,
    career_level text NOT NULL,
    role_orientation text NOT NULL,
    industry text,
    risk_environment text,
    "values" text,
    compensation_priority text,
    other_assessments text,
    report_data jsonb NOT NULL,
    user_email text
);


--
-- Name: client_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    notes text,
    restrict_results boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    tier text DEFAULT 'basic'::text
);


--
-- Name: client_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid,
    email text NOT NULL,
    name text,
    password_hash text NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    last_login_at timestamp with time zone,
    provider text DEFAULT 'email'::text,
    provider_id text
);


--
-- Name: detection_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detection_feedback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    text_hash text NOT NULL,
    own_writing boolean NOT NULL,
    context text,
    hypothesis_raw text NOT NULL,
    actual_profile text,
    sample_text text
);


--
-- Name: fit_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fit_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid,
    user_id uuid,
    participant_name text,
    profile_type text NOT NULL,
    role text NOT NULL,
    score integer,
    demand_split jsonb,
    result_payload jsonb,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: library_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tool_num integer,
    collection text,
    title text NOT NULL,
    support_mode text,
    onepager_path text,
    kit_path text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    summary text,
    item_type text DEFAULT 'tool'::text NOT NULL,
    profile text,
    CONSTRAINT library_items_collection_check CHECK ((collection = ANY (ARRAY['A'::text, 'B'::text, 'C'::text, 'D'::text, 'E'::text])))
);


--
-- Name: mirror_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mirror_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token text NOT NULL,
    label text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    use_count integer DEFAULT 0 NOT NULL,
    daily_count integer DEFAULT 0 NOT NULL,
    daily_count_date date
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    user_id uuid
);


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stripe_session_id text NOT NULL,
    stripe_payment_intent text,
    product_type text NOT NULL,
    buyer_name text NOT NULL,
    buyer_email text NOT NULL,
    amount_paid integer NOT NULL,
    currency text DEFAULT 'usd'::text,
    tokens_generated integer NOT NULL,
    engagement_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    notification_sent boolean DEFAULT false,
    confirmation_sent boolean DEFAULT false
);


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token uuid NOT NULL,
    name text NOT NULL,
    email text,
    purpose text NOT NULL,
    engagement_id text NOT NULL,
    expires_at timestamp with time zone,
    used boolean DEFAULT false NOT NULL,
    used_at timestamp with time zone,
    result_payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company text,
    role text,
    link_sent_at timestamp with time zone,
    account_id uuid,
    granted_tier text DEFAULT 'basic'::text,
    profile_sent_at timestamp with time zone,
    created_for_name text,
    created_for_email text,
    granted_tools text[] DEFAULT ARRAY['assessment_tokens'::text]
);


--
-- Name: tool_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tool text NOT NULL,
    mode text NOT NULL,
    profile text,
    tokens_input integer,
    tokens_output integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: writing_samples; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.writing_samples (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    mirror_token_id uuid NOT NULL,
    sample_text text NOT NULL,
    mirror_output text NOT NULL,
    consented boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    binary_payload bytea
)
PARTITION BY RANGE (inserted_at);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    selected_columns text[],
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at, custom_claims_allowlist) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: account_licenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_licenses (id, account_id, type, quantity, expires_at, created_at) FROM stdin;
0ad29c06-a953-462f-845e-fe928a082f4b	0fc540e0-ef6c-4ce1-b856-2306eb0ad7f4	assessment_tokens	1	\N	2026-07-22 21:03:59.736008+00
b99cfdb7-55ea-4b2b-a88a-9cfe37d7963b	122222cc-b996-475e-ba8c-1e3b437a0be0	assessment_tokens	1	\N	2026-08-06 14:36:11.280516+00
7668352d-d48d-49f8-83b4-f470d77f1c13	017b98da-fcf8-499f-901f-2d30d006db33	assessment_tokens	1	\N	2026-08-09 16:55:55.673313+00
50a8dff2-0071-4d3a-9b57-61245fbec6a2	017b98da-fcf8-499f-901f-2d30d006db33	jd_analyzer	1	\N	2026-08-09 16:55:55.688495+00
b1e050d1-f8dd-458f-85f8-b495b518c042	017b98da-fcf8-499f-901f-2d30d006db33	library_b	1	\N	2026-08-09 16:55:55.701202+00
6bcdd75f-a0f0-430c-994d-2f5d4c544141	017b98da-fcf8-499f-901f-2d30d006db33	orientation_translator	1	\N	2026-08-09 16:55:55.713779+00
43fdcc4d-d3f3-4dd8-bd9e-59f1efb5d234	017b98da-fcf8-499f-901f-2d30d006db33	career_guidance	1	\N	2026-08-09 16:55:55.718002+00
9f218e55-0df5-4c96-a840-71a91fed6d32	017b98da-fcf8-499f-901f-2d30d006db33	progress_companion	1	\N	2026-08-09 16:55:55.781779+00
23077322-d281-49ab-8ba5-86bdba14b441	017b98da-fcf8-499f-901f-2d30d006db33	role_analyzer	1	\N	2026-08-09 16:55:55.786242+00
4712e492-d73f-48f4-b890-91748cb3b697	4a71ad09-aa7b-4f27-b69b-e5765163ad64	orientation_translator	1	\N	2026-08-11 18:20:52.079648+00
7bc05a7a-8bc1-4800-851f-99ef8145bca3	4a71ad09-aa7b-4f27-b69b-e5765163ad64	precision_companion	1	\N	2026-08-11 18:20:52.08128+00
9c60d7bb-6786-4849-9120-78640a52c081	4a71ad09-aa7b-4f27-b69b-e5765163ad64	library_full	1	\N	2026-08-11 18:20:52.068874+00
a3a41d7a-5553-4258-b588-11cafad9cfa6	4a71ad09-aa7b-4f27-b69b-e5765163ad64	jd_analyzer	1	\N	2026-08-11 18:20:52.089854+00
c4e181e6-9080-4e6e-826f-b5e3b7c571e4	4a71ad09-aa7b-4f27-b69b-e5765163ad64	role_analyzer	1	\N	2026-08-11 18:20:52.09897+00
7907ebf4-a46c-4330-8a21-b89bfcbf31b7	4a71ad09-aa7b-4f27-b69b-e5765163ad64	career_guidance	1	\N	2026-08-11 18:20:52.102225+00
fee933c3-8e75-475c-a4d8-2cd1fc1b4abc	2a082267-e1e6-47b7-98bb-20b8915a0db7	career_guidance	1	\N	2026-07-09 18:29:21.5853+00
d4edf4d9-d06f-49df-8db3-65e8fab4eac6	2a082267-e1e6-47b7-98bb-20b8915a0db7	role_analyzer	1	\N	2026-07-09 18:29:21.591707+00
be1211b6-fe90-4d0f-b9e5-28df962bd08f	2a082267-e1e6-47b7-98bb-20b8915a0db7	jd_analyzer	1	\N	2026-07-09 18:29:21.594555+00
63a344c2-3b3b-4716-b142-7f1089bee0b1	2a082267-e1e6-47b7-98bb-20b8915a0db7	precision_companion	1	\N	2026-07-09 18:29:21.604319+00
b95ab2da-3b01-4f77-ad23-73c398e95824	2a082267-e1e6-47b7-98bb-20b8915a0db7	library_full	1	\N	2026-07-09 18:29:21.604951+00
12fa2a57-4012-4b5c-b5d7-8da3a5f50f14	2a082267-e1e6-47b7-98bb-20b8915a0db7	progress_companion	1	\N	2026-07-09 18:29:21.615482+00
56e4dc74-5c76-4bb9-a15e-b050ecc42fd0	2a082267-e1e6-47b7-98bb-20b8915a0db7	orientation_translator	1	\N	2026-07-09 18:29:21.62065+00
fb2e01c0-9882-490b-a668-a764e81f658e	2a082267-e1e6-47b7-98bb-20b8915a0db7	purpose_companion	1	\N	2026-07-09 18:29:21.622035+00
dae0eb7f-8d68-467d-b84c-6f649b7b0a89	2a082267-e1e6-47b7-98bb-20b8915a0db7	assessment_tokens	1	\N	2026-07-09 18:29:21.62742+00
344340c8-d804-4fa7-aa62-2d8d46ceb672	fafc5b22-9492-444d-8b52-13bdb884e267	assessment_tokens	1	\N	2026-07-10 00:22:17.09861+00
0a4016e2-e6c2-43de-929c-72ac5a6fb861	fafc5b22-9492-444d-8b52-13bdb884e267	career_guidance	1	\N	2026-07-10 00:22:17.111154+00
ca0befd5-3e34-464a-8875-09a8a703ed22	d95df7d1-17a1-4702-9bb6-fe071b3ea207	career_guidance	1	\N	2026-07-17 16:43:08.36108+00
4881d3bd-c393-4c2c-a0ec-c6fcf81c0f01	d95df7d1-17a1-4702-9bb6-fe071b3ea207	jd_analyzer	1	\N	2026-07-17 16:43:08.372972+00
4febb431-04db-4a77-9221-29a69540c911	d95df7d1-17a1-4702-9bb6-fe071b3ea207	library_full	1	\N	2026-07-17 16:43:08.373093+00
3adc26ae-a8b9-4eb7-8211-b365d14e66df	d95df7d1-17a1-4702-9bb6-fe071b3ea207	purpose_companion	1	\N	2026-07-17 16:43:08.385723+00
090dec1b-5033-4e4a-98f6-75e75f290887	d95df7d1-17a1-4702-9bb6-fe071b3ea207	precision_companion	1	\N	2026-07-17 16:43:08.395775+00
3f502ca0-102b-4944-be73-5fe3bbc7947e	d95df7d1-17a1-4702-9bb6-fe071b3ea207	progress_companion	1	\N	2026-07-17 16:43:08.397275+00
e1322d88-4c60-46e8-9650-07322d7e0fa9	d95df7d1-17a1-4702-9bb6-fe071b3ea207	orientation_translator	1	\N	2026-07-17 16:43:08.395782+00
893a2148-ce31-4a2f-8343-da6bd951cd74	a9962f52-d3ca-4ce9-817b-f5e4bb281012	role_analyzer	1	\N	2026-07-17 20:12:01.097836+00
0863590b-f912-4140-88c3-5f6fc8159cda	a9962f52-d3ca-4ce9-817b-f5e4bb281012	assessment_tokens	1	\N	2026-07-17 20:12:01.116979+00
40ccef54-9ab3-4e6f-8384-d2d4a96314b3	a9962f52-d3ca-4ce9-817b-f5e4bb281012	career_guidance	1	\N	2026-07-17 20:12:01.118779+00
\.


--
-- Data for Name: assessments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assessments (id, name, email, type, h_score, w_score, y_score, submitted_at, token, company, role) FROM stdin;
635c7feb-cc11-49c5-99c7-93fd03edac9a	Ray	Raymondckearney@icloud.com	how-why	9	6	8	2026-08-06 03:33:28.817+00	\N	\N	\N
f22def66-2354-46f1-acf0-5a87288340c1	Ray	Raymondckearney@icloud.com	what-how	9	10	4	2026-08-06 12:57:02.162+00	\N	Curio	Founder
4f95c6e7-b21c-4359-8cd9-2be917a3ebcf	RAY TEST	raymondckearney@icloud.com	how-why	21	1	2	2026-08-06 14:32:48.968+00	ad9b8bbb-2d02-4b5a-a4ef-5e1f93c0e276	Curio	CEO
29c2b0d1-bb71-4dbd-90fe-65f7a2ead1a9	RAY TEST WHY WHAT TIE	Raymondckearney@icloud.com	why-how	2	1	21	2026-08-06 15:31:47.981+00	\N	Curio	CEO
ac76ba60-20fc-497a-baa9-7618e9ef34f7	RAY TEST WHAT WHY HOW TIE	raymondkearney@icloud.com	what-why	1	21	2	2026-08-07 00:57:16.938+00	\N	Curio	CEO
59bd94a8-f7e6-4626-aa2e-d36c5ed64579	RAY TEST HOW WHAT WHY TIE	Raymondck@icloud.com	how-what	21	2	1	2026-08-07 01:04:55.133+00	\N	Curio	CEO
2b40bcaf-d7ff-4990-a9b1-e143d4d88de4	Test User	testuser@example.com	what-how	8	9	6	2026-08-07 02:15:11.314+00	\N	Acme Corp	Director of Ops
3eed45e0-77f6-4249-ae27-65b960641979	Wade	wade@wadeforst.com	why-how	6	6	11	2026-08-09 16:54:34.947+00	3db45529-c058-47d9-b79d-e5de4aef6857	\N	\N
431eeaf0-3680-40b3-b5fe-74597f72a3d2	Linda	linda.mann444@gmail.com	why-what	2	9	12	2026-05-26 17:24:52+00	08739a52-a6fa-4ddc-829b-94f120c465e3	Cortico-x	Strategic Account Leader / RevOps leader
2bac5a81-c465-4a1d-b647-2069188c60c6	Jen Rivera	\N	how-why	16	2	5	2026-06-05 16:36:45.533+00	6da22bd3-97e9-4da9-b38d-7c01e7991ccb	\N	\N
f95881ec-0fdb-4117-bd25-8c1ec7179d31	Monica Althoff	monica.althoff@gmail.com	what-how	9	10	3	2026-06-11 17:10:09.468+00	57f9c2dc-2fea-4027-a3e1-15364ad9b53c	\N	\N
ed57cb83-c0c0-4f56-add5-661b424a629f	Betty Kearney	eebkearney@gmail.com	why-how	4	4	10	2026-06-15 19:13:00.779+00	60d5f29c-4aea-4a2d-b727-3cc78b5766f6	\N	\N
027beb77-dbf5-40c3-9986-f2157c319fc3	Kari Erickson	kari@kecoaching.com	why-how	5	4	14	2026-06-22 11:22:08.109+00	cf0894a0-8a6d-412e-9c4d-2767705ba4a6	\N	\N
36234097-d12e-4357-bd17-f3a2d5ff4da9	Francesca Philips	francesca@scaling.com	why-what	6	8	9	2026-06-23 16:20:15.732+00	8a92e80e-8863-4337-aeef-62ef22db7f35	\N	\N
58972792-aa70-4933-b9d7-025711879fbe	Troy Nielson	troy_nielson@byu.edu	why-how	7	5	11	2026-06-23 17:11:02.258+00	2e74803a-8fe0-443f-b4e1-e1f074506e09	\N	\N
1335db61-8b2e-42e7-8372-74eab32d26a0	Ava	avayoungmckula@gmail.com	what-how	5	16	2	2026-07-09 21:33:42.12+00	f87b1645-ab2c-4f7e-acdb-95d5db7c9ba2	\N	\N
c3cc2857-431f-46d4-856b-00794c7def9b	Kait	katehollis18@gmail.com	how-what	13	9	1	2026-07-17 18:09:29.049+00	ed683c28-b2b6-46dd-a5a4-fc106504d2a3	\N	\N
43c942af-33d8-45d8-84cf-a5098afb1468	Ray	raymondckearney@gmail.com	why-what	2	7	14	2026-07-17 19:24:45.879+00	92f5bdb5-bc8f-475c-ab3e-aa050355dce4	\N	\N
26d85fb6-0eca-4aa0-92c2-25435a912418	Shanna	shannayee13@gmail.com	why-how	4	3	16	2026-07-21 06:21:35.146+00	89327998-620f-4a01-9d0b-a60ad3fe0569	\N	\N
c7b69e44-9578-4e8f-8d2c-05a2626e0a33	Ray	raymondckearney@icloud.com	how-why	11	2	10	2026-08-05 02:26:17.692+00	4bbdb837-b7ca-46be-99a5-c44676c4f3e2	\N	\N
\.


--
-- Data for Name: career_guidance_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.career_guidance_reports (id, created_at, profile, career_level, role_orientation, industry, risk_environment, "values", compensation_priority, other_assessments, report_data, user_email) FROM stdin;
c8473763-21bc-497f-bdc7-d748657894fe	2026-07-01 01:01:25.005544+00	WHY-WHAT	Early Career (0–4 years)	Management	\N	Established company	\N	Balanced	DiSC D	{"roles": [{"fit": "This is the highest-confidence early management role for a WHY-WHAT, and an established company context makes it even more viable. The core demand of a team lead in strategy, consulting, or operations is exactly what this profile is wired for: identify what problem the team should be solving, align people around it, and push the work forward. In years one through four, you will find yourself energized by the brief — by the moment where a client or internal stakeholder presents a situation and you have to decide what the actual question is.\\n\\nEstablished companies create something valuable for an early-career WHY-WHAT manager: a track record. The organizational structure gives you a platform to demonstrate strategic clarity without having to build the platform itself. You can focus energy on the quality of thinking and direction-setting rather than on standing up a function from scratch.\\n\\nWith a DiSC D overlay, you will move fast and expect others to keep up. The combination of directional confidence and action-orientation is a genuine leadership asset here — you will not be the team lead who hedges. Watch that this doesn't become impatience with teammates who need more context before they can move. Speed without shared understanding creates rework.\\n\\nThe challenge in this role is the operational layer underneath the strategy work. Status updates, task-level dependencies, delivery tracking — this is where your tertiary HOW orientation creates real risk. A strong HOW partner on the team, or a clear escalation path to someone who holds execution detail, is the difference between a team that moves fast and a team that moves fast and then has to fix things.", "title": "Team Lead — Strategy, Consulting, or Business Operations", "energizing": [{"body": "In strategy and operations work, the most valuable leadership move is often the one that happens before work starts — deciding what the team is actually trying to solve. Your WHY primary orientation makes this natural. You will find yourself asking the question that reframes everything, and in a management role, that instinct becomes a directional gift to your team rather than a friction point.", "label": "Framing the problem before the team dives in"}, {"body": "The moment when a team goes from scattered to oriented is one you will consistently generate. Whether it's a new project, a new quarter, or a team that's gotten confused about priorities, your combination of purpose clarity and forward momentum — amplified by a DiSC D communication style — makes you effective at getting people aligned and moving quickly.", "label": "Running kickoffs and alignment sessions"}, {"body": "With DiSC D and a WHY primary orientation, you will be unusually effective in the room where decisions are made about resources, priorities, and visibility. You can articulate why the work matters and what needs to happen next with a directness that lands. This is a high-leverage activity for an early-career manager and one you should actively seek.", "label": "Advocating for your team's work to leadership"}, {"body": "Your WHAT secondary orientation means you are energized by movement and genuinely uncomfortable with extended indecision. In management, this translates to a leader who makes calls. Teams in established companies frequently stall waiting for someone to decide — you are wired to break that pattern, and your team will notice and value it.", "label": "Making calls when the team is stuck"}, {"body": "This is the work that sits at the intersection of your WHY and WHAT orientations: defining where the team is going and why it matters. At an established company, the organizational mission exists — your job is to translate it into something your team can feel. You will be better at this than most early managers.", "label": "Setting team goals and connecting them to organizational purpose"}], "strategies": [{"body": "Look for the person on your team or in your immediate network who is energized by the execution detail you find draining — the person who notices the missing dependency, who asks about the handoff process, who builds the tracker without being asked. That relationship is worth more to your management effectiveness than any skill you could develop. Name it explicitly with them: tell them you need someone who will tell you when the execution gaps are showing.", "label": "Identify your HOW partner in the first 60 days"}, {"body": "You need a mechanism that keeps granular delivery visible without requiring you to sustain attention on it personally. A simple weekly status doc — owned and maintained by the most HOW-oriented person on your team — keeps you informed without draining you. Your job is to review it, not produce it. Establish this in the first month before the gap becomes a pattern.", "label": "Build a standing one-page team status artifact — and let someone else own it"}, {"body": "Your natural instinct to orient around purpose is a management differentiator — but it only works if you externalize it consistently. At the start of every meeting, every project brief, every new initiative, make the purpose explicit and audible. Teams in established companies often operate without a clear articulation of why the work matters. You are unusually well-positioned to provide that. Do it deliberately, not just when you feel like it.", "label": "Lead with the 'why' explicitly in every team meeting"}, {"body": "DiSC D managers can come across as decided before the team has been heard — which creates compliance rather than commitment. In the first year, channel your directness into making decisions quickly after genuine input rather than before it. The perception you want to build is: fast and inclusive, not fast and closed. The difference is often one or two well-placed questions before you call the direction.", "label": "Use your DiSC D directness as a trust-building tool, not just a speed tool"}, {"body": "You will encounter a situation in year one where you can see that the team — or the organization — is solving the wrong problem. Your instinct will be to say so. Before you do, assess whether you've built enough relational credit with the stakeholders in the room for that observation to land as strategic rather than disruptive. If not, surface it privately with your manager first, build the case, and bring it forward when you're positioned to be heard.", "label": "Choose your first 'reframe' moment carefully"}], "challenging": [{"body": "The operational rhythm of team management — who owns what, what's blocked, what's at risk — is tertiary HOW work. You will find this genuinely draining rather than simply tedious. The risk is not that you'll do it badly; it's that you'll do it inconsistently because you keep gravitating toward the higher-altitude work. Build a system or a partnership that holds this without depending on your personal attention.", "label": "Tracking granular task completion across the team"}, {"body": "As a WHY-WHAT manager with DiSC D, your natural communication style is directional and fast. Team members with a strong HOW orientation will need more than a direction — they'll need to understand how the pieces fit before they can move with confidence. This gap will produce friction that feels like resistance to you and like being left behind to them. It's a translation challenge, not a performance problem.", "label": "Managing the team member who needs high detail and process clarity"}, {"body": "Because granular execution detail is genuinely in your blind spot, you may find it difficult to give specific, actionable feedback on how someone executed a deliverable rather than what they produced. At the early management stage, feedback specificity is a credibility signal. Build the habit of asking your HOW partner on the team what went wrong in the execution before delivering feedback, so your observations are grounded.", "label": "Giving feedback on execution quality"}, {"body": "Your instinct to question the frame — to ask whether the team is solving the right problem — is a genuine strategic asset. In an early-career management role at an established company, that instinct can land as not-yet-earned if you haven't built relational capital first. The same observation from a trusted leader reads as insight; from someone new, it reads as not-yet-committed. Sequence your strategic challenges carefully.", "label": "Building organizational credibility before questioning the direction"}]}, {"fit": "Product management is one of the most natural structural fits for a WHY-WHAT, and the Associate PM role in an established company is a viable early-career management path precisely because it puts you in the business of deciding what the product should do and why — before a single engineer writes a line of code. The core demand is direction-setting under ambiguity: taking a customer problem, a business goal, and a set of constraints, and producing a clear articulation of what to build and why it matters. This is your orientation in action.\\n\\nIn an established company, the APM role carries institutional scaffolding that early-career WHY-WHATs benefit from: existing user research frameworks, design partners, engineering processes, and leadership expectations that create guardrails without removing the strategic latitude you need to do your best thinking. Startups can work for this profile, but the established context lets you focus on learning the product discipline rather than inventing the company simultaneously.\\n\\nThe DiSC D overlay sharpens the APM value proposition: you will push roadmap decisions forward, advocate hard for your product vision in cross-functional rooms, and not be the PM who hedges every prioritization conversation. Engineering and design partners will find you energizing to work with because you give them clear direction and back it up with conviction. Watch that the conviction doesn't become closure — the best PMs stay genuinely curious about whether they have the right answer.\\n\\nThe structural challenge in APM roles is the execution layer: sprint planning details, ticket management, QA coordination, release checklists. This is the operational HOW work that keeps product development moving, and it is genuinely draining for a WHY-WHAT. In an established company, there is usually engineering infrastructure or a technical PM partner who can carry more of this — identify that coverage in your first 90 days.", "title": "Associate Product Manager", "energizing": [{"body": "Before any feature gets built, someone has to answer: what problem are we solving, and why does it matter now? This is the work that your WHY primary orientation makes you genuinely good at. You will find yourself energized by the blank page of a product brief in a way that many colleagues don't — the act of naming the problem clearly is satisfying, not intimidating.", "label": "Writing the product brief and defining the problem to solve"}, {"body": "Deciding what goes on the roadmap and defending it to stakeholders is direction-setting work — and with a WHAT secondary and DiSC D overlay, you will do this with more conviction and clarity than most APMs. You are not the PM who qualifies every recommendation. You make a call, explain the reasoning, and push it forward. Stakeholders often find this refreshing.", "label": "Roadmap prioritization and narrative building"}, {"body": "Your WHY orientation makes you naturally curious about the underlying problem rather than the surface request. In user research and customer discovery, this translates to asking the questions that reveal what's actually going on rather than confirming what you already think. You will find these conversations energizing — especially when they produce a reframe that changes what the team should build.", "label": "Discovery conversations with users and customers"}, {"body": "APMs sit at the intersection of engineering, design, marketing, and business stakeholders. Aligning those groups around a shared product direction is purpose-then-momentum work — exactly the sequence you are wired for. You will be unusually effective in rooms where people have different mental models of what the product should do, because you can find and articulate the shared purpose underneath the disagreement.", "label": "Cross-functional alignment meetings"}, {"body": "With DiSC D communication style and WHY-WHAT orientation, the executive pitch is where you will consistently outperform peers. You can frame the business case in terms of why it matters, what you're proposing, and why now — in a way that is both compelling and direct. Actively seek these opportunities in your first two years.", "label": "Pitching a new product direction or feature area to leadership"}], "strategies": [{"body": "Your WHY orientation will push you toward understanding the problem before committing to the solution. Not all established company environments default to this — many have backlogs full of feature requests that get treated as direction. In your first two months, establish explicitly with your engineering and design partners that you will define the problem clearly before roadmap items are committed. This will feel obvious to you but may be a meaningful cultural shift for your team.", "label": "Establish a 'discovery before roadmap' operating norm with your team in the first 60 days"}, {"body": "The gap between your product direction and a shipped product runs through operational HOW work you will find draining. In an established company, there is usually an engineering manager, technical lead, or program manager who is genuinely energized by the execution detail you're not. Identify that person and establish a working relationship with them explicitly — not just as a colleague, but as the person who will tell you when the implementation plan has gaps your brief didn't address.", "label": "Find your execution partner before you have an execution problem"}, {"body": "Product briefs, one-pagers, roadmap presentations — make it a discipline to lead every artifact with a clear articulation of why this problem matters and why now. This is both a quality control mechanism (if you can't write it, the direction isn't clear yet) and a reputation-building tool. In an established company, the PM who consistently connects work to purpose becomes the person leadership thinks of for the problems that actually matter.", "label": "Write the 'why' at the top of every document you produce"}, {"body": "The risk for a DiSC D APM is that the directness that makes you effective in executive rooms can shut down creative input from engineering and design partners who need to feel like genuine collaborators, not executors. In team settings, consciously create structured space for input before you share your view. Ask what's missing from the brief before you defend it. The teams that build the best products are the ones where the PM's conviction invites contribution rather than ending conversation.", "label": "Use your DiSC D directness to accelerate — not replace — team input"}, {"body": "In your first year as an APM, the most valuable mentor is not the PM with the biggest product vision — you can generate that yourself. The most valuable relationship is with a HOW-oriented PM who has figured out how to ship things reliably, who can show you how execution actually works, and who can tell you where your product briefs have gaps before they become engineering problems. That relationship is worth more than any PM training course.", "label": "Seek out the most experienced HOW-oriented PM in your organization and invest in that relationship"}], "challenging": [{"body": "The day-to-day operational rhythm of product development — writing detailed acceptance criteria, tracking sprint velocity, managing the backlog at the ticket level — is HOW work that sits in your tertiary orientation. It is not optional in an APM role; it is how the product gets built. Find an engineering partner or a technical PM who can take ownership of the execution scaffolding while you focus on the directional layer.", "label": "Sprint management and ticket-level execution detail"}, {"body": "Your instinct is to hand off with vision and high-level direction — and then be surprised when the engineering team has questions you didn't anticipate. Detailed specification writing requires sustained attention to how all the pieces fit together, which is genuine HOW work. In an established company, there are often templates and processes to help structure this. Use them, and build the habit of having a design or engineering partner review specs before they go out.", "label": "Writing exhaustive product specifications"}, {"body": "You are energized by the question of whether the team is solving the right problem. Stakeholders with a WHAT orientation will push back with urgency arguments — 'we need to move on this,' 'we're falling behind,' 'let's just ship something.' With a DiSC D overlay, your instinct may be to compete with that urgency rather than hold the strategic frame. Practice articulating why the direction question is worth the delay before it becomes a confrontation.", "label": "Holding direction when stakeholders push back with momentum arguments"}, {"body": "The operational detail of launching a product — coordinating release timing across engineering, marketing, support, and legal — is some of the most detail-intensive work in a PM role. It is entirely HOW work. Build an explicit partnership with your engineering manager and, where available, a release coordinator or program manager who owns this layer.", "label": "QA, release checklists, and launch coordination"}]}, {"fit": "Management consulting in an established firm is one of the highest-concentration WHY-WHAT environments that exists at the early-career level. The core of consulting work is exactly the orientation sequence this profile is built for: diagnose the real problem, determine what should be done, build the case, and push the client toward action. Every engagement starts with a brief that needs reframing; every presentation is an argument for a direction. You are wired for this work at a structural level.\\n\\nAt an established consulting firm specifically, the training infrastructure and project team model mitigate the execution blind spot in ways that a startup consulting shop or a solo advisory role would not. You will be surrounded by HOW-oriented colleagues whose job is to build the model, check the analysis, and produce the deliverable with precision. Your job is to contribute to the strategic framing and push the work toward a clear recommendation. The organizational structure does some of the coverage work for you.\\n\\nWith DiSC D, you will be one of the more direct junior consultants in the room — comfortable making a recommendation and defending it, less prone to the hedging and excessive qualification that can make junior consulting output feel inconclusive. This is a significant asset in client presentations and internal review sessions. It will also create friction with colleagues and managers who want to explore more options before closing in on a direction.\\n\\nThe realities of early-career consulting work include a meaningful amount of HOW-intensive work: building decks, running analyses, building financial models, formatting outputs. This is genuine drain territory for a WHY-WHAT. It is unavoidable at the junior level. The strategy is not to avoid it but to move through it efficiently and position yourself for the work that is actually energizing as early as you credibly can.", "title": "Junior Management Consultant", "energizing": [{"body": "In consulting, every engagement has an official question the client asked and a real question that will actually move their business. Your WHY orientation makes you alert to the gap between the two. You will be the person in the team room who asks whether the client brief is actually pointing at the right problem — and in an early-career consulting role, that instinct, when well-timed, earns you a reputation quickly.", "label": "Problem diagnosis and framing the client's real question"}, {"body": "The moment when a body of analysis resolves into a clear point of view — a recommendation the team is willing to put their name on — is energizing for a WHY-WHAT in a way it isn't for most junior consultants. Many peers at this level are uncomfortable making the call. You will be comfortable making it and articulating why. This is a differentiator.", "label": "Synthesizing findings into a recommendation"}, {"body": "With DiSC D and WHY-WHAT orientation, client-facing moments where you are communicating a direction — presenting findings, leading a working session, fielding challenges from senior client stakeholders — are where you will consistently outperform. You will be direct, clear, and confident in a way that clients read as credible. Seek out these opportunities rather than defaulting to the back-of-room analytical role.", "label": "Client presentations and steering committee moments"}, {"body": "At the beginning of each phase of an engagement, the project team has to decide what to investigate, what hypotheses to test, and what work will generate the most valuable insight. This planning-with-direction work is energizing for you — it sits at the intersection of purpose (what should we be trying to learn?) and forward movement (what are we actually doing this week?). You will add real value in these sessions.", "label": "Internal strategy sessions and shaping the workplan"}, {"body": "In consulting, the storyline — the logical thread that connects the client's situation to the insight to the recommendation — is what the final output rests on. Building that narrative structure is WHY-WHAT work. You are energized by the architecture of an argument, by finding the through-line that makes the recommendation feel inevitable. This is a skill that will compound across your career.", "label": "Building and delivering the storyline"}], "strategies": [{"body": "In consulting project teams, there is always a synthesis task: taking the week's analysis and building the so-what, identifying the implications, drafting the key message for each slide. Volunteer for this work explicitly and consistently. It is where your WHY-WHAT orientation produces the most distinctive output, it is the most visible work in the team, and it is how you build a reputation as a strategic thinker rather than an analytical executor in years one through two.", "label": "Volunteer for the synthesis role in every team room you're in"}, {"body": "On every project team, identify the colleague who is energized by the analytical precision work you find draining — the one who wants to build the model correctly and check every formula. Make that a real working relationship: you contribute the framing and the synthesis, they contribute the analytical rigor and QA. This is not division of labor by preference — it is structural coverage of your tertiary orientation blind spot.", "label": "Build an explicit analytical partnership with your most HOW-oriented teammate"}, {"body": "Because document precision is genuine HOW work and will not be your default, build a simple checklist — alignment, consistency, logic flow, source citations — that you run through before any slide deck goes to your manager for review. This takes 15 minutes and prevents the most common early-consulting reputation problems. The goal is not perfection; it is consistent baseline quality without depending on sustained granular attention.", "label": "Create a personal slide quality checklist and use it before every internal review"}, {"body": "Junior consultants often hedge recommendations with qualifications to demonstrate they've considered the complexity. With DiSC D and WHY-WHAT wiring, you are naturally inclined toward directness — use it. In team discussions, practice saying 'I think the recommendation is X, and here's why' rather than 'there are several options, each with tradeoffs.' Your willingness to make the call, internally and then externally, is a differentiator that gets noticed.", "label": "Make your recommendations explicit and direct in internal team discussions"}, {"body": "Before the project team locks into its workplan, there is a window — usually the first week of scoping — where the problem definition is still open. This is your window. Read the proposal, read the brief, talk to the client, and bring one clear question to your manager: 'Are we sure this is the right problem?' Framed as a genuine question rather than a challenge, this is how WHY-WHAT junior consultants differentiate themselves from execution-only analysts. It is also how you build the strategic credibility that earns you more of the energizing work.", "label": "Use the first week of every engagement to ask the question nobody asked"}], "challenging": [{"body": "Quantitative analysis at the detail level — building models, running sensitivity analyses, checking formulas, ensuring the logic holds through every scenario — is deep HOW work. At the junior consulting level, this is a meaningful part of the job. You can learn the mechanics, but sustained attention to granular analytical precision will cost you energy in a way it doesn't cost HOW-oriented colleagues. Partner with the person on your team who is genuinely energized by this layer.", "label": "Building and stress-testing detailed financial models"}, {"body": "Consulting output is often judged in part on the precision and polish of the presentation artifact. Slide formatting, consistency checking, and document quality control are operational HOW work that will drain you. This is not optional at the junior level — it is part of how you're evaluated. Build habits and checklists that help you do this efficiently, and identify colleagues who are willing to QA your slides before they go to the manager for review.", "label": "Perfecting slide formatting and document production"}, {"body": "Some consulting projects are primarily analytical — weeks of data analysis before any strategic synthesis begins. Extended HOW-intensive phases without the strategic framing work that energizes you will produce drain at a level that affects performance and wellbeing. Identify this early in a project and find ways to create small doses of synthesis work during the analytical phase to sustain your energy.", "label": "Sustaining analytical rigor through weeks of deep quantitative work"}, {"body": "Occasionally, you will be on a project where the partner or the client has effectively already decided the answer and the engagement is primarily about building the evidence. Your WHY orientation will resist this — you will want to actually investigate whether the direction is right. Learning to navigate this tension professionally, without either shutting down your instinct or creating unnecessary client relationship friction, is an early-career management consulting skill.", "label": "Accepting that the recommendation direction has already been decided"}]}, {"fit": "Brand and marketing management is direction-setting work that requires both a clear point of view on why something matters and the ability to push it into the market with urgency. At the associate manager level in an established company, this translates to owning a piece of the brand strategy, leading campaigns from brief to launch, and representing the brand's point of view in cross-functional rooms. This is a strong fit for WHY-WHAT orientation — the work rewards exactly the instinct to define purpose before choosing tactics.\\n\\nEstablished companies create an important advantage here: an existing brand with equity, guidelines, a customer base, and a set of organizational stakeholders who care about how the brand shows up. For an early-career WHY-WHAT, this is more useful than starting from scratch — you can focus on how to push the brand forward rather than what it is. The institutional scaffolding creates a platform for the directional and campaign work that energizes you.\\n\\nWith DiSC D, you will be a notably direct voice in creative reviews and agency conversations — clear about what you think is working, what isn't, and why. This is an asset in a function that can sometimes drift toward too many opinions and not enough decisions. Your willingness to make a call on creative direction will be valued by agency partners and appreciated by internal stakeholders who need someone to own the direction. Watch for the tendency to close on creative direction before fully incorporating team input.\\n\\nThe operational layer of marketing management — campaign trafficking, vendor management, budget reconciliation, legal review processes — is HOW work that will drain you. In an established company, there are usually marketing operations teams, project managers, and agency producers who hold this. Build those partnerships early and explicitly so the execution infrastructure doesn't become your energy cost.", "title": "Brand or Marketing Manager (Associate Level)", "energizing": [{"body": "The campaign brief — what we're trying to say, who we're saying it to, why it matters, what success looks like — is purpose-setting work. You will find yourself energized by the blank page of a brief in a way many marketing colleagues don't. The clarity you bring to a brief directly determines the quality of what the creative team and agency produce. This is high-leverage work and you are wired for it.", "label": "Writing and presenting the campaign brief"}, {"body": "When an agency presents creative options, someone has to decide which territory to develop and why. With DiSC D directness and WHY-WHAT orientation, you will be unusually clear and direct in these sessions — you have a point of view and can articulate the rationale. Creative partners and internal stakeholders frequently find this a relief after reviews where everyone hedges and nothing gets decided.", "label": "Creative territory reviews and making the call on direction"}, {"body": "The question of what a product or brand should stand for — and how to express it in language that actually moves people — is deeply energizing for WHY-WHATs. Positioning work lives at the intersection of purpose (why does this exist?) and direction (what should we say?). In an established company, this work emerges during brand reviews, product launches, and competitive repositioning moments. Seek out opportunities to be involved.", "label": "Positioning and messaging work"}, {"body": "Bringing a campaign to market requires aligning product, legal, media, social, and sales teams around a shared direction on a timeline. This is direction-setting and momentum work — exactly the WHY-WHAT sequence. You will be energized by the launch moment and by the coordination work that builds toward it, as long as the operational execution details are held by a project manager or marketing operations partner.", "label": "Cross-functional campaign launches"}, {"body": "In an established company, the brand manager is the person who holds the brand's point of view when other functions are making decisions that affect it. This is advocacy work — making the case for why the brand direction matters and what trade-offs aren't acceptable. With DiSC D and WHY-WHAT orientation, you will be direct and convincing in these rooms.", "label": "Representing the brand in internal stakeholder discussions"}], "strategies": [{"body": "The campaign brief is the document that determines whether the downstream work will be energizing or corrective. Make it a personal standard that you write the brief before any agency or creative partner touches the assignment. A WHY-WHAT who has not written the brief is a WHY-WHAT operating reactively, which is the worst context for this orientation. Writing the brief also positions you as the person who owns the strategic direction of the work, which is the reputation you want to build early.", "label": "Own the brief, always — and write it before the agency does"}, {"body": "In an established company, there is almost always a marketing operations team, project coordinator, or agency producer who holds the execution infrastructure of campaign management. Find that person, understand what they own, and establish explicitly that you will bring them into projects early so the operational layer is covered from the start. This is not delegating work you don't want — it is structural coverage of your tertiary blind spot, established before it becomes a problem.", "label": "Build a relationship with your marketing operations partner in week one"}, {"body": "The friction between marketing's urgency to launch and legal's need for review time is a predictable tension in established companies. With a WHAT secondary orientation and DiSC D, you will feel this friction acutely. Get ahead of it by scheduling a brief kickoff with your legal partner at the start of each campaign to understand their specific review requirements and timeline. What feels like a constraint becomes a known variable you can plan around.", "label": "Create a standing meeting with your legal and compliance contact at the start of each campaign"}, {"body": "Creative reviews in established companies can stall in a loop of collective indecision. As the brand manager with DiSC D directness, you have an opportunity to be the person who breaks that loop — but do it in a way that the team can follow. Explicitly frame your directness: 'I'm going to make a call here so we can move forward — here's my reasoning, and I want to hear if anyone sees it differently.' This invites the dissent you need to make a good call while demonstrating the decisiveness that marks you as a manager.", "label": "Use your DiSC D directness to accelerate creative decision-making — explicitly"}, {"body": "An early-career brand manager who can articulate — clearly and briefly — what the brand stands for, what it doesn't, and why it matters, has a significant organizational advantage. Use your WHY-WHAT orientation to produce this document in your first three months: one page, your point of view, grounded in what you've learned from the business and the customer. Share it with your manager and the cross-functional stakeholders who regularly interact with the brand. It establishes your strategic credibility and becomes a reference point for decisions when you're not in the room.", "label": "Build a one-page brand point-of-view document in your first 90 days and share it broadly"}], "challenging": [{"body": "Getting a campaign to market involves a significant amount of operational detail: trafficking creative to media partners, managing asset specifications across channels, coordinating approval workflows, reconciling budgets. This is HOW work that needs to be done precisely and consistently. It is not optional in a marketing manager role, but it is draining. In an established company, marketing operations or an agency producer typically owns this layer — establish that coverage relationship in your first 30 days.", "label": "Campaign trafficking and operational execution detail"}, {"body": "Marketing managers own budgets, and budget management is granular HOW work: purchase orders, vendor invoices, accruals, budget-to-actual reconciliation. This is not a place to be approximate — financial precision errors create organizational problems that are embarrassing and time-consuming. Build a system early (even a simple spreadsheet with a weekly update habit) that keeps this visible without requiring you to live in it.", "label": "Budget management and finance reconciliation"}, {"body": "Established companies have legal, regulatory, and compliance review processes for marketing materials that are detailed, sequential, and non-negotiable. The review process is structured HOW work — tracking feedback, managing redlines, ensuring every version gets to the right reviewer. Your impatience with this process will be a recurring friction point. Build a relationship with your legal and compliance partners early, understand their timelines, and build their review windows into your project plans before the campaign is in flight.", "label": "Legal and compliance review processes"}, {"body": "Campaign performance analysis — pulling data, building reports, analyzing what worked and why — requires sustained analytical precision. Post-campaign analysis is the work that should inform the next brief, which means it matters strategically. But the act of doing it is HOW work. Find an analytics partner or a marketing analyst who can produce the data and the initial synthesis, so you can contribute the strategic interpretation rather than the operational analysis.", "label": "Sustaining attention through extended analytics reviews"}]}, {"fit": "Business development — identifying opportunities, building the case for them, and moving the organization toward capturing them — is direction-finding and momentum work. At the associate level in an established company, especially when there is responsibility for a small team or initiative, this role concentrates the work that energizes a WHY-WHAT: deciding which opportunities are worth pursuing, articulating why, and pushing the organization to act on that view. The combination of WHY and WHAT is almost perfectly matched to the BD function.\\n\\nIn an established company, business development often sits at the boundary between the existing organization and what could be next — new partnerships, new markets, new product lines. This is exactly where a WHY-WHAT thrives: at the edge of the known, where the question 'are we going in the right direction?' is legitimate and where the ability to build conviction and momentum actually determines outcomes. You will find the ambiguity of BD energizing rather than uncomfortable.\\n\\nWith DiSC D, you will be notably effective in external meetings — with potential partners, customers, or acquisition targets. Your directness reads as confidence and competence in high-stakes external conversations, and your ability to articulate a clear strategic rationale for a partnership or opportunity will be valued. The DiSC D overlay also means you will push deals forward where a more cautious BD professional would stall, which in an established company context can be a meaningful advantage.\\n\\nThe challenge in a BD role is the analytical and documentation work that supports the business case: financial modeling, due diligence processes, contract review, and the operational tracking of a pipeline. This is structural HOW work. In an established company, there are usually finance partners, legal teams, and operations staff who hold the execution detail. Establish those partnerships early, before the detail work becomes a personal operational burden.", "title": "Business Development Associate (Leading a Small Team or Initiative)", "energizing": [{"body": "The BD function starts with a question: where should we be expanding, and why does this market or partner or product area represent a real opportunity? This is WHY orientation work at its most direct. You will be energized by the discovery phase — talking to potential partners, reading the competitive landscape, synthesizing what you're learning into a clear point of view on which opportunities are worth pursuing.", "label": "Identifying and framing new opportunities"}, {"body": "Turning an opportunity into an organizational commitment requires building the case — why this, why now, what it will take, what the return looks like. With WHY-WHAT orientation and DiSC D, you will produce business cases that are directional, compelling, and confident. You are not the BD professional who presents three options and asks leadership to choose — you present a recommendation and defend it.", "label": "Building and presenting the business case"}, {"body": "BD is a relationship function, and with DiSC D and WHY-WHAT orientation, you will be unusually effective in external relationship contexts. You are direct, you know what you're trying to accomplish, and you can articulate the value of a partnership in terms that the other party finds compelling. Relationship building that has a clear strategic purpose — not networking for its own sake — is energizing for this profile.", "label": "External relationship building with partners and prospects"}, {"body": "The early stages of a negotiation — defining the structure, articulating each party's interests, finding the terms that make a partnership viable — require the ability to hold a clear directional view while remaining genuinely open to the other side's perspective. With WHY-WHAT orientation, you can do this: you have a clear view of what you need, you can articulate why, and you can probe what the other side needs without losing your strategic anchor.", "label": "Leading early-stage partnership negotiations"}, {"body": "If you are leading a small team or initiative within the BD function, the goal-setting and strategy work is where your WHY-WHAT orientation becomes the organizational asset. Deciding what your team is going after this quarter and why — and building enough clarity around that direction that the team can execute independently — is direction-setting work that energizes you.", "label": "Setting the strategy for your team or initiative area"}], "strategies": [{"body": "A one-page opportunity thesis — what is this, why does it matter strategically, what do we need to believe for it to work, what are the three biggest risks — forces the WHY clarity that is your orientation's primary contribution. It also creates a shared artifact your team can work from and that internal stakeholders can evaluate. Produce one for every opportunity in your pipeline, before the business case is built, and share it early to get input on whether the framing is right.", "label": "Build a simple 'opportunity thesis' template and use it for every opportunity you pursue"}, {"body": "The analytical and legal work that supports a BD deal needs structural HOW coverage that you build before you need it. In your first month, identify the finance business partner and the legal contact who support BD transactions. Have an explicit conversation about how you'll work together — what you'll bring them, when, and what you'll need from them. Deals close faster when these relationships are already warm when diligence starts.", "label": "Establish a finance and legal BD partner in your first month"}, {"body": "As a manager, the most important thing you can do for your team each quarter is tell them where you're going and why. With WHY-WHAT orientation, you are wired to do this — but make it explicit and documented. Write a one-paragraph team north star for each quarter: what are we trying to accomplish, why does it matter, and how will we know we've succeeded? Share it with the team in a meeting, not just via email. This is the management behavior that your orientation makes natural and your team will find genuinely orienting.", "label": "Set a team goal, not a task list, at the start of each quarter"}, {"body": "The operational discipline of keeping your BD pipeline accurate and current will not come naturally. Build a standing 15-minute calendar block each week — same time, every week — where you review your pipeline, update the CRM, and identify what's stalled. The constraint is the protection: 15 minutes is short enough that you will do it, and frequent enough that the pipeline never gets far from reality. Do not let it expand into a longer process review — that will become its own drain.", "label": "Create a weekly 15-minute pipeline review habit with yourself"}, {"body": "In BD, deals stall because no one will name the obstacle or make the call that moves things forward. Your DiSC D directness is a structural advantage here — use it deliberately. In every external meeting, identify the specific next step that will move the deal forward and name it explicitly before the meeting ends: 'I'd like us to agree that by [date], you'll share [specific thing] and I'll come back with [specific thing].' This move — direct, specific, time-bound — compresses deal timelines and signals professionalism to counterparts.", "label": "Use your DiSC D directness to compress deal timelines with intent"}], "challenging": [{"body": "When a deal moves toward execution, due diligence begins: financial review, legal review, operational assessment, risk mapping. This is detailed, sequential, precision-oriented HOW work. In an established company, finance and legal teams typically own the primary diligence work — your role is to coordinate and interpret, not produce. Establish those partnerships before your first deal closes so the transition into diligence doesn't catch you in operational territory you're not built for.", "label": "Due diligence processes and analytical documentation"}, {"body": "BD organizations require accurate pipeline management: tracking the status of every opportunity, logging meeting notes, updating probability estimates, forecasting close dates. This is operational HOW work — repetitive, granular, and genuinely draining for a WHY-WHAT. Build the habit of CRM updates immediately after every external meeting, not at end of week, or you will find yourself reconstructing a pipeline that has drifted into inaccuracy.", "label": "Pipeline tracking and CRM management"}, {"body": "Early-stage opportunity identification and late-stage closing are both energizing. The extended middle of a deal — weeks of back-and-forth on terms, waiting for internal approvals, managing stakeholder alignment across both organizations — is slower and less directionally clear. This is where your WHAT orientation creates impatience: the momentum has stalled and there isn't a clear next step that resolves it. Build a practice of identifying and creating micro-next-steps during stalled deal phases to sustain your energy.", "label": "The long middle of a deal"}, {"body": "Once a partnership is signed, the BD team often transitions to partnership management — which is operationally intensive. If you remain in a management role through this phase, you will be managing people through HOW-heavy execution work that you find draining. Ensure your team includes at least one HOW-oriented member who can hold the execution detail of active partnerships without depending on your sustained attention.", "label": "Managing the team through execution and delivery detail"}]}], "nextSteps": ["Before your next interview or informational conversation, write two sentences on why the specific problem this organization is working on matters to you — not the industry, not the company's reputation, the actual problem. If you cannot write those two sentences, that is useful data about whether the role will sustain your energy.", "Map the execution coverage gap in any role you are seriously considering: who on the team or in the organization is energized by the operational and detail work that sits in your tertiary HOW orientation? If you cannot identify that person before you accept an offer, that gap will become your first management problem.", "In your current or next role, identify one meeting in the next 30 days where you have been executing without a clear sense of why the work matters — and bring the question explicitly. Framed as genuine curiosity rather than challenge, this is how early-career WHY-WHATs build a reputation for strategic thinking rather than waiting until they have the seniority to make it their job.", "When evaluating offers at established companies, weight the quality and autonomy of the problem over the prestige of the company name. You will outperform in environments where you have real directional latitude and a meaningful problem to orient around — and underperform in environments where the structure routes you into execution without access to the why, regardless of how impressive the brand is."], "watchFors": ["The execution handoff: you will set direction with confidence and genuine clarity, but the granular mechanics of how your team gets from A to B will have gaps you don't see — structural HOW coverage on your team is not optional.", "The credibility window: in early management roles at established companies, the instinct to question the frame or redirect the goal can read as not-yet-ready before you've built the relational capital to make it land as strategic — sequence matters."], "energizers": ["Leading a team toward a goal that genuinely matters to you — the combination of meaningful direction and visible progress is the fuel this profile runs on.", "The moments when a room full of people who aren't aligned leave aligned — translating your conviction about where things should go into shared momentum is where you do your best work.", "Identifying that the team is solving the wrong problem and saying so — your instinct to reframe before committing is a leadership asset, not a delay."], "alignmentLabel": "STRONG SIGNAL", "environmentNote": "For a WHY-WHAT, the most important environmental signal is not the company's brand or size — it is whether the environment gives you a real problem to orient around. Established companies are a strong choice at the early-career stage precisely because the problems exist and are visible: there is a market to compete in, a customer to serve, a strategy to execute against. What you are evaluating in any established company environment is whether the role you are in gives you genuine access to the directional work — or whether the structure routes you exclusively into execution without a line of sight to the why.\\n\\nThe signals that an established company will work for you: your manager asks for your point of view on where things should go, not just your work product; the team has enough HOW orientation to carry the execution detail without depending on you; you are invited into rooms where direction is being set, not just communicated; and the company has a purpose you can personally connect to. The signals that should give you pause: the role is defined primarily by process compliance and operational metrics, the team has no clear HOW-oriented execution partner, your manager rewards output volume over strategic quality, or you are two or three levels removed from any decision that involves direction-setting.\\n\\nIn an established company specifically, watch for the organizational bureaucracy dynamic. Large, established organizations have process layers that can route WHY-WHAT energy into approval workflows, committee reviews, and alignment meetings that feel like obstruction rather than organization. This is real, and it is more draining for your profile than for most. The mitigation is not avoiding established companies — it is choosing roles within them that have enough autonomy to set direction without every decision requiring multi-stakeholder sign-off. In your interviews and offer evaluation, ask specifically: 'Who makes the call on direction in this role?' The answer tells you more about whether the environment will work for you than almost any other question you could ask.", "alignmentPercent": 82, "alignmentSentence": "WHY-WHAT is one of the most naturally management-oriented profiles in the framework — energized by setting direction, rallying people around a purpose, and moving toward a goal — and established companies offer enough structure to channel that drive without the chaos that can scatter it."}	\N
de7ed7fd-9e09-432e-98e2-bf5f2fec2068	2026-07-01 15:37:11.73024+00	WHY-WHAT	Early Career (0–4 years)	Open to Both	healthcare	Established company	\N	Primary consideration	DiSC - D	{"roles": [{"fit": "Healthcare strategy teams at established companies — health systems, payers, pharma — exist specifically to answer the questions that haven't been properly named yet. Why is patient volume declining in this service line? Is this acquisition creating the value we projected? Should we enter this new market or double down on the one we have? These are WHY-WHAT questions, and analysts who can reframe them and push toward a clear direction get noticed fast.\\n\\nIn years one through three of this role, you will discover that your value isn't in building the financial model — it's in knowing which model to build and why it matters. You will find yourself in rooms where smart people are analyzing the wrong thing, and your instinct to step back and ask whether the question itself is right will be the contribution that distinguishes you from peers with stronger technical execution.\\n\\nThe DiSC D dimension will serve you well here. Healthcare strategy conversations can stall in analysis and consensus-building. Your directness will move things, and in an established company with deliberate decision-making cycles, a junior voice that pushes for clarity and action — delivered with confidence rather than impatience — gets remembered. The challenge is calibrating how hard you push before you've earned the room's trust.", "title": "Strategy & Operations Analyst", "energizing": [{"body": "The earliest and most energizing phase of any strategy project is the one where the problem isn't fully named yet. What's actually driving the trend? What's the real question behind the question the executive asked? This is where your primary orientation generates genuine fuel, and healthcare is full of problems that reward this kind of upstream thinking.", "label": "Diagnosing strategic problems before solutions exist"}, {"body": "Taking three weeks of data, interviews, and analysis and turning it into a clear point of view — this is one and two orientation work simultaneously. You are energized by the moment clarity emerges and even more by the act of making the case for it. In strategy roles, that synthesis product is often the most visible thing you produce.", "label": "Synthesizing insight into a directional recommendation"}, {"body": "Your DiSC D profile adds a dimension here: you don't just communicate findings, you advocate for them. Healthcare leaders are often cautious and consensus-oriented by training, and an early-career analyst who can walk into an executive presentation with a clear point of view and defend it under scrutiny stands out immediately.", "label": "Presenting to leadership and building conviction"}, {"body": "Whether it's a post-merger integration, a service line restructure, or a shift in care delivery model, you are most energized when the problem is genuinely consequential and the answer isn't obvious. Strategy and ops roles at established health companies offer a steady supply of these questions — especially as the industry works through the aftershocks of value-based care, digital health, and workforce disruption.", "label": "Working on transformation and change questions"}], "strategies": [{"body": "Identify one analyst or associate on your team who is energized by execution detail — the person who actually enjoys building the project tracker and maintaining the documentation. Build a real working relationship with them, not a transactional one. Offer to take the upstream diagnostic and narrative work they find draining in exchange for coverage on the execution infrastructure you find draining. Name it directly — most people respond well to a colleague who understands their own wiring.", "label": "Find a HOW-oriented partner early and make the relationship explicit"}, {"body": "Your DiSC D profile and WHY-WHAT instinct will make you want to push for a point of view quickly. In an established healthcare company, that instinct needs a counterweight early in your tenure. Before your first major presentation or recommendation, make sure you can articulate the strongest version of the opposing view. Walking into the room having genuinely wrestled with the counterargument is what separates directness from overconfidence in the eyes of senior leaders.", "label": "Lead with curiosity before conviction in your first 12 months"}, {"body": "When new projects are scoped, there is often a brief, undervalued phase where someone has to structure what question is actually being asked. Volunteer for this every time. It is where you do your best thinking, it creates visibility with leadership, and it gives you legitimate influence over what the team works on — which means more energizing work throughout the engagement.", "label": "Volunteer explicitly for the problem-framing phase of every project"}, {"body": "When you hand work to a more execution-oriented colleague or move from strategy to implementation, build a one-page handoff document that captures the strategic intent, the key decisions made, and the open questions. This takes 30 minutes and prevents the failure mode the WHY-WHAT profile is most prone to: the beautiful plan that falls apart because the execution team didn't have the context. It also protects your reputation when things go wrong downstream.", "label": "Create a handoff protocol for execution deliverables"}, {"body": "Compensation at this level in healthcare strategy is higher at companies working on genuinely hard problems — payer-provider convergence, value-based care contracting, health equity, behavioral health integration. Within established companies, the strategy roles closest to these questions will command a premium over roles maintaining stable business lines. Orient your role search and internal moves toward the unsettled questions.", "label": "Track which healthcare problems are genuinely unsettled"}], "challenging": [{"body": "Strategy projects generate a significant volume of tracking work: meeting notes, project plans, status updates, stakeholder maps, decision logs. This is HOW-orientation work, and it will drain you. In a well-structured strategy team, analysts share this load or have operational support — but in years one and two, you are often expected to own it entirely.", "label": "Building and maintaining detailed project documentation"}, {"body": "Once a recommendation is approved and the team moves into implementation planning, your energy will drop. The question has been answered; what remains is building the machinery. This is real — not a motivation problem — and it becomes visible to managers and teammates who notice your engagement shift after the strategic phase closes.", "label": "Sustaining attention on execution after the direction is set"}, {"body": "Established healthcare companies move deliberately. Decisions require clinical, legal, compliance, and financial sign-off. You will have clarity on the answer long before the organization is ready to move on it, and your DiSC D directness may create friction with colleagues who interpret urgency as skipping due diligence.", "label": "Managing the gap between your speed and your organization's"}]}, {"fit": "Healthcare consulting at an established firm — whether a Big 4 advisory practice, a Huron or Chartis, or a payer/provider-focused boutique — is structurally well-suited to the WHY-WHAT profile. The work is organized around questions, not functions. You are not a department; you are an answer machine. The most respected consultants in healthcare practices are the ones who consistently reframe what the client is actually asking and then move the engagement toward a clear, defensible answer.\\n\\nYou are entering a profession that rewards the instinct to ask whether the question is right before answering it. Unlike internal strategy roles, consulting gives you the additional fuel of frequent context-switching — every engagement is a new problem, a new system, a new set of assumptions to pressure-test. Your DiSC D dimension will help you hold your own in client rooms earlier than most peers, and in a profession where presence and conviction carry real weight, that is a genuine advantage.\\n\\nThe early-career version of this role is demanding on the HOW side. Deliverable production, data cleaning, model maintenance, deck formatting — you will spend meaningful time on work that drains you. The firms and teams that retain WHY-WHAT consultants early are the ones where associates are given real analytical ownership quickly, not just execution support. How you evaluate offers and choose teams within a firm matters as much as the firm itself.", "title": "Management Consulting Associate (Healthcare Practice)", "energizing": [{"body": "The problem structuring phase — building the issue tree, defining the hypothesis, deciding what questions actually matter — is where you are most alive. In healthcare consulting, this phase has direct client impact: a well-framed problem produces a useful engagement; a poorly framed one produces a polished answer to the wrong question. Your instinct to slow down and get the frame right before moving is a professional asset here.", "label": "Structuring the problem before the engagement runs"}, {"body": "Your DiSC D profile means you enter rooms with energy and presence. Discovery interviews — talking to CMOs, operations leaders, clinical staff, and finance teams to understand what's actually happening inside an organization — require exactly this. You will find yourself energized by the detective work of synthesizing what different stakeholders believe about the same problem, and by the moment when a clear picture starts to emerge.", "label": "Client-facing discovery and stakeholder interviews"}, {"body": "The final presentation in a consulting engagement is one of the highest-leverage moments in the profession. You are translating months of work into a clear direction for a client who has to act on it. This is WHY-WHAT work in its purest form — making the case for a direction you believe in, to people who need to be moved. Your combination of strategic conviction and DiSC D directness will serve you well in these moments.", "label": "Building and delivering the narrative"}, {"body": "A healthcare consulting practice will expose you to payers, providers, life sciences, health tech, and government health programs across a two-to-three year period. Each engagement is a new problem, a new system, a new set of assumptions. The variety is genuinely energizing for WHY-WHAT profiles — you are not optimizing the same process repeatedly; you are diagnosing different problems every few months.", "label": "Engagement variety across healthcare sub-sectors"}], "strategies": [{"body": "Within any healthcare consulting firm, some teams are structured around senior-driven strategy with associates in execution support; others genuinely push analytic ownership down early. In the next 30 days, if you are evaluating offers or considering a move, reach out to two or three associates at your target firms and ask directly: what percentage of your time is on problem structuring versus deliverable production? The answer matters more than the firm's brand.", "label": "Choose your first team or practice more carefully than your firm"}, {"body": "Every consulting team has someone who is genuinely energized by model integrity, formatting standards, and process documentation. Find them in the first week of each engagement. Offer to take a larger share of the client-facing and synthesis work in exchange for more support on the production side. This is not laziness — it is intelligent allocation of cognitive energy, and most HOW-oriented teammates will welcome it.", "label": "Partner explicitly with the HOW-oriented analyst on every engagement"}, {"body": "Before you run the analysis, write down what you think you will find and why. This is a habit that makes WHY-WHAT consultants exceptionally sharp — it sharpens your diagnostic instinct, makes you faster at interpreting results, and forces you to notice when the data contradicts your framing. It also makes your synthesis significantly faster, which buys back time from the execution work you find draining.", "label": "Document your hypotheses before the data comes back"}, {"body": "Healthcare executives — especially physicians and nurses who've moved into leadership — respond poorly to directness that doesn't acknowledge the complexity of clinical environments. Your DiSC D confidence can read as dismissiveness to clinicians who've spent years navigating the human cost of system failures. A single sentence that acknowledges that complexity before delivering your recommendation will change how the room receives it.", "label": "Soften directness with clinical framing in healthcare client rooms"}, {"body": "Consulting practices focused on regulatory compliance, EMR implementation, or billing optimization are HOW-orientation environments. The compensation ceiling is lower, the work is more process-intensive, and the problems are defined, not open. Healthcare strategy and transformation practices — growth strategy, care delivery redesign, payer-provider integration — command higher compensation and are structurally better suited to your profile. Be deliberate about this distinction when evaluating practice areas.", "label": "Target healthcare practices with strategy and transformation work, not compliance or IT"}], "challenging": [{"body": "A meaningful portion of early-career consulting hours is spent building, formatting, and revising decks, models, and documentation. This is HOW-orientation work — granular, detail-dependent, and process-intensive. It will drain you, and it doesn't diminish with effort. The key is not to become excellent at it but to become efficient enough that it costs you less time than it costs your energy.", "label": "Deck and deliverable production at the associate level"}, {"body": "Many healthcare consulting engagements extend into implementation — building the new operating model, project managing the change, tracking milestone completion. Once the strategic direction is set, your energy will drop, and the people around you, including your manager, may notice. Being honest with yourself and your team lead about where you are most useful — and asking to be staffed on the diagnostic and strategy phases — is a legitimate career management move.", "label": "Sustained engagement with implementation-phase work"}, {"body": "Health systems and payers are large, heavily regulated, consensus-driven organizations. Your DiSC D directness and WHY-WHAT impatience with slow decisions will create friction if not calibrated to the client's decision-making culture. The clients you find most frustrating will be the ones where governance processes require six stakeholder approvals before any recommendation can be acted on — which is most of them.", "label": "Managing the pace of established healthcare clients"}, {"body": "Time tracking, utilization reporting, knowledge management submissions, internal staffing conversations — consulting firms generate a significant administrative load. This work is HOW-orientation work at its most draining because it is not connected to a problem worth solving. Building efficient habits early, rather than letting it pile up, is the only mitigation that actually works.", "label": "Internal firm process and administrative overhead"}]}, {"fit": "Product management in healthcare — at a digital health company, a health system building internal tools, or a health tech company inside an established payer or pharmacy benefit manager — is one of the most natural fits for the WHY-WHAT profile in the entire industry. The core output of a product manager is a direction: here is the problem we are solving, here is who we are solving it for, and here is what done looks like. That is a WHY-WHAT sentence.\\n\\nIn years one through three of this role, you will discover that your ability to hold the why before the what — to push back on a feature request and ask what problem it is actually solving — is the capability that separates the product managers who get things built from the ones who build the right things. Healthcare is a field where the gap between those two groups is especially large, because the problems are urgent, the stakes are clinical, and the organizations building solutions often lose sight of what they are trying to change.\\n\\nYour DiSC D profile accelerates your credibility in cross-functional rooms. PMs in healthcare have to manage up to executives, laterally with clinical, legal, and compliance, and down with engineering and design — often in the same conversation. The combination of directness and conviction you bring will help you hold those rooms and move decisions that would otherwise stall in committee.", "title": "Healthcare Product Manager", "energizing": [{"body": "User research, clinical workflow observation, stakeholder interviews, competitive analysis — these are all in service of answering one question: what is actually broken and why? This phase is where WHY-WHAT product managers do their best work. You will find yourself energized by the detective work of getting to a problem definition that is sharp enough to actually guide a product decision.", "label": "Discovery: naming the problem before the solution exists"}, {"body": "The product requirement document, the one-pager, the strategy brief — whatever the format, the act of translating a problem into a clear direction is genuinely energizing. Your DiSC D directness means you will not write hedged, committee-friendly documents. You will have a point of view, and you will defend it. In healthcare product orgs where indecision is common, this is a real differentiator.", "label": "Writing the product brief and making the case for a direction"}, {"body": "Deciding what to build next — and making the case for why — is the recurring high-stakes decision in product management. You are energized by the clarity question: among all the things we could do, which one matters most and why? In a healthcare context, these decisions often have clinical implications, which adds a layer of purpose that will sustain your engagement.", "label": "Roadmap strategy and prioritization"}, {"body": "PMs in healthcare must influence clinical, legal, compliance, engineering, and design teams without formal authority. Your DiSC D profile means you do not wait for permission to take a position. Combined with your WHY-WHAT instinct to connect every decision to a clear purpose, you will naturally lead cross-functional conversations in a way that creates movement — which is the most valued PM capability in any healthcare organization.", "label": "Cross-functional leadership without direct authority"}], "strategies": [{"body": "Within healthcare product organizations, there is a meaningful difference between product roles focused on clinical or market strategy — where the questions are open and the direction is still being set — and platform or infrastructure product roles, where the work is predominantly execution-oriented. In the next 30 days, when evaluating PM openings, look at the product area, not just the title. Strategy-oriented product roles will sustain your energy and command higher compensation over time.", "label": "Pursue roles in product strategy or growth product, not platform or infrastructure"}, {"body": "In an established healthcare company, there is almost always a technical program manager, a delivery lead, or a senior engineer who is energized by the execution architecture you find draining. Make this person your closest working partner. Be explicit: your value is in the upstream problem framing and strategic decisions; their value is in the operational machinery that makes execution reliable. This is a structural partnership need, not a personal preference.", "label": "Find a technical program manager or senior engineer to own execution infrastructure"}, {"body": "Before your next product brief or roadmap presentation, write two sentences on why the problem you're solving matters to the patient, the clinician, or the health system — not just why it matters to the product. If you can write those sentences quickly and believe them, that's a signal you're working on the right problem. If you can't, that's useful data about whether this feature belongs on the roadmap at all.", "label": "Write a crisp 'why this problem' section for every product brief you own"}, {"body": "Healthcare product reviews tend to drift toward consensus and away from decisions. Your natural mode — coming in with a clear recommendation rather than a set of options — will be unusual in most established healthcare organizations and highly valued once it consistently produces better outcomes. Build the habit of ending every cross-functional meeting with a stated decision and owner. Over time, this becomes your professional identity, and it is worth more than any technical skill in a PM career.", "label": "Use your DiSC D directness to accelerate decisions in cross-functional reviews"}, {"body": "In some established healthcare companies, product is a function of technology delivery rather than business strategy — PMs are project managers in practice, executing roadmaps that executives set. In others, product is the organizing function for company direction. The difference in compensation, influence, and daily energy is significant. Ask directly in interviews: 'Can you give me an example of a product decision that changed the company's strategy?' The answer will tell you everything.", "label": "Target companies where product drives strategy, not IT"}], "challenging": [{"body": "The HOW side of product management — maintaining the backlog, writing precise acceptance criteria, managing dependencies across engineering teams, tracking ticket status — is real and sustained. In an established healthcare company with mature agile processes, this work is significant and cannot be fully delegated. It will drain you, and unlike the strategic work, it does not get lighter as you become more senior in an IC product role.", "label": "Managing the sprint and maintaining detailed technical documentation"}, {"body": "Healthcare products — especially anything touching clinical workflows, patient data, or billing — generate a significant compliance and documentation burden. FDA pathways, HIPAA requirements, clinical evidence documentation: these are HOW-orientation requirements that are non-negotiable in the industry. Build a structural relationship with your regulatory and compliance partners from day one, because this is not work you can avoid or delegate entirely.", "label": "Regulatory and compliance documentation"}, {"body": "Once the direction is set and the engineering team is building, your primary orientation work is largely done. What remains is execution support — answering questions, clarifying requirements, reviewing designs, running sprint ceremonies. This phase will feel slow and draining compared to the discovery and strategy phases. Managing your energy through it, and finding ways to stay connected to the strategic question behind the build, is a real challenge in years one through three.", "label": "Sustaining engagement through the build phase"}]}, {"fit": "Healthcare business development — at a health system pursuing growth and partnership strategies, a payer expanding into new markets, or a life sciences company building commercial relationships — is a natural early-career environment for WHY-WHAT profiles. The core activity is making the case for a direction: here is why this partnership creates value, here is what we are trying to build, here is why we should move. You will spend most of your time in rooms where someone has to hold a vision and sell it, and that is where you generate the most energy.\\n\\nIn years one through four, business development roles in healthcare will expose you to the full strategic landscape of the industry faster than almost any other function. You will work on market analyses, partnership structures, acquisition rationales, and competitive positioning — all of it in service of answering the question: where should we go next and why? Your DiSC D profile means you will not wait for the opportunity to be fully de-risked before pushing to move. In a field where hesitancy can mean losing a market window, that instinct is valuable.\\n\\nThe compensation upside in healthcare BD roles is real, particularly at companies operating at the intersection of strategy and commercial growth — specialty pharmacy, value-based care organizations, and health systems with active M&A pipelines. The ceiling is higher in these environments than in operational or clinical support roles, and early-career professionals who demonstrate strategic ownership get there faster.", "title": "Business Development Associate (Healthcare)", "energizing": [{"body": "The front end of any BD process is a diagnostic question: where is the market moving, what gaps exist, and which of those gaps represents a genuine opportunity for this organization? This is primary orientation work — naming the opportunity before the organization has decided to pursue it. You will be energized by the research and synthesis phase of this work, and particularly by the moment when a clear opportunity crystallizes.", "label": "Market analysis and opportunity identification"}, {"body": "Healthcare partnerships — JVs, distribution agreements, clinical collaborations, payor contracts — require someone who can walk into a room and make the case for why this relationship creates value. Your WHY-WHAT profile means you arrive with a clear point of view on why the partnership matters, not just a list of terms. Your DiSC D directness means you will not be passive in those rooms. Combined, these two things make you a credible presence in partner-facing work earlier than most early-career BD professionals.", "label": "Pitching and presenting to potential partners"}, {"body": "BD teams in established healthcare companies need to understand what competitors and potential partners are doing — and, more importantly, what it means for the organization's direction. Synthesizing industry news, conference signals, and market data into a clear strategic implication is work that energizes you. It is upstream of the deal; it is about making sense of the landscape before deciding where to move.", "label": "Competitive and strategic intelligence synthesis"}, {"body": "Acquisitions, major partnerships, and market entry decisions in healthcare can change an organization's trajectory for a decade. The stakes and the purpose are both real. WHY-WHAT profiles are specifically energized by work that is both consequential and directionally meaningful, and early exposure to M&A or significant partnership processes — even in a support role — will give you some of the most engaging work available in early-career healthcare.", "label": "Working on high-stakes, consequential transactions"}], "strategies": [{"body": "In most BD teams, there is a clear division between the narrative work — why this opportunity matters, what the strategic case is — and the analytical work — what the numbers say. Claim the former explicitly. Offer to take the lead on writing the opportunity memo and preparing the pitch materials. Bring a finance or analytical partner in for the modeling. This is not shirking; it is specialization, and it produces better outputs when done intentionally.", "label": "Own the opportunity memo and the partner pitch, not the model"}, {"body": "In the next 30 days, start building a one-page map of the competitive and partnership landscape in the specific segment your organization operates in — whether that's value-based care, specialty pharmacy, health tech, or another area. Update it monthly. This becomes your professional signature: the person on the team who knows the landscape and can see the opportunity before it becomes obvious. It is also the kind of work that justifies your involvement in higher-stakes conversations earlier than your title would normally allow.", "label": "Build a live map of the healthcare landscape in your focus area"}, {"body": "Identify one colleague in finance, legal, or program management who is energized by the operational machinery of deal execution — the tracking, the documentation, the process management. Make this relationship a priority. When you are working on the same transaction, be explicit about who owns what. This is a structural partnership need that will determine how effectively you operate in BD throughout your career, not just right now.", "label": "Find a deal execution partner early in your career"}, {"body": "Some BD teams in established healthcare companies manage existing relationships rather than develop new ones. Others are actively sourcing new partnerships, markets, or acquisitions. The first is a HOW-heavy role — managing process and relationship continuity. The second is a WHY-WHAT role. Before accepting a BD position or internal move, ask: what percentage of the team's time is on new opportunity identification versus existing partnership management? The answer directly affects both your energy and your compensation ceiling.", "label": "Target BD teams with active pipelines, not maintenance portfolios"}, {"body": "In healthcare, where institutional culture tends toward consensus and deliberation, your directness will make you memorable. The goal is not to soften it but to deploy it with precision. Before a partner meeting or internal pitch, decide in advance what you are pushing for — a specific decision, a commitment to next steps, a clear no — and drive to that outcome explicitly. Directness in service of a clear outcome builds your reputation. Directness without a clear ask can read as aggression in a clinical culture.", "label": "Treat your DiSC D directness as a tool to calibrate, not suppress"}], "challenging": [{"body": "The middle phase of any BD transaction is a detailed, documentation-intensive, process-driven exercise. Financial models, data room management, legal tracking, regulatory review — this is sustained HOW-orientation work. In an established company, much of it is managed by legal, finance, and integration teams, but BD associates are often expected to coordinate across all of them. The coordination overhead alone will drain you even before you get to the documentation itself.", "label": "Due diligence documentation and tracking"}, {"body": "Healthcare deals move slowly. Regulatory reviews, clinical governance processes, and multi-stakeholder approval chains mean that a partnership you identified and pitched in Q1 may not close until Q4 — or may not close at all. Your DiSC D directness and WHY-WHAT impatience will create real friction during these phases. The discipline of maintaining partner relationships through ambiguity, without pushing so hard you damage the relationship, is a genuine skill you will need to develop.", "label": "Managing relationships through slow or stalled deal processes"}, {"body": "BD roles in healthcare often require basic financial modeling — valuation inputs, revenue projections, market sizing models. This is HOW-orientation work, and while you will develop competency, it will not energize you. The risk is spending disproportionate time on model refinement rather than on the strategic framing and relationship work that actually moves deals. Recognize the minimum viable level of modeling precision required for each decision and stop there.", "label": "Granular financial modeling and valuation analysis"}]}, {"fit": "Program management in healthcare — running a quality improvement initiative at a health system, leading a new care model launch at a payer, or managing a multi-site implementation at a health services company — is a role where the WHY-WHAT profile can generate real impact and real energy, with one important condition: the role must have genuine strategic ownership, not just execution coordination. That distinction matters enormously for this profile.\\n\\nAt their best, WHY-WHAT program managers in healthcare are the people who understand why the program exists and can translate that purpose into the directional decisions that keep it on track. They are not the people who build the project plan and track the RAID log — they are the people who notice when the program has drifted from its original intent and have the credibility to push it back. In years one through three, you will discover that your ability to hold the strategic frame under operational pressure is a rare capability in healthcare program environments where execution urgency can overwhelm purpose clarity.\\n\\nIn an established healthcare company, program management roles focused on transformation — care delivery redesign, new market launches, organizational change — will command better compensation and offer more energizing work than roles managing ongoing operational programs. The label is the same; the work is completely different. Be deliberate about which type you are evaluating.", "title": "Healthcare Program Manager", "energizing": [{"body": "The front end of any meaningful healthcare program — why are we doing this, what does success look like, and how do we know when we have achieved it — is genuine WHY-WHAT work. You will be energized by the scoping and visioning phase, and particularly by the challenge of getting a diverse group of clinical, operational, and administrative stakeholders to align on what the program is actually trying to change.", "label": "Defining program scope and articulating the case for change"}, {"body": "Healthcare programs touch clinical quality, operations, finance, legal, and IT simultaneously. The program manager is often the only person whose job is to hold all of those perspectives at once and keep them pointed at the same goal. Your DiSC D directness means you will call out misalignment when others are avoiding it, and your WHY-WHAT instinct means you will trace disagreements back to purpose rather than letting them fester at the operational level.", "label": "Navigating stakeholder alignment across functions"}, {"body": "Programs stall. Stakeholders misalign, assumptions prove wrong, external conditions change. The moment when a program needs to be diagnosed and reset is where you are most energized — it is a strategic problem masquerading as an operational one, and you are built to reframe it. Healthcare organizations with the self-awareness to bring you into these moments will get significantly more value from this role than the title suggests.", "label": "Diagnosing why a program is off track and resetting direction"}, {"body": "Program review presentations — to steering committees, executive sponsors, and board-level audiences — are moments when the WHY-WHAT profile shines. You can connect program-level decisions to organizational strategy in a way that makes leadership confident the program is pointed at the right goal. Your DiSC D confidence means you will hold the room under scrutiny, not defer to it.", "label": "Presenting program strategy and outcomes to leadership"}], "strategies": [{"body": "In the next program you take on, make it a non-negotiable that each major workstream has a designated lead who is responsible for the detailed plan and status tracking — not just a subject matter expert who attends meetings. This is not empire-building; it is the structural design that allows you to operate at the level where you add the most value. Program managers who try to hold all of the detail themselves produce worse outcomes than those who build the right team architecture.", "label": "Insist on workstream leads who own execution detail"}, {"body": "Before your next steering committee or executive update, write one sentence that connects the decision you are asking for to the program's core purpose. This is a 15-minute habit that will prevent the most common failure mode in healthcare program management: tactical decisions that slowly move the program away from its original intent without anyone noticing. It also protects your credibility with sponsors who need to trust that the program manager is holding the strategic frame, not just the project plan.", "label": "Anchor every program decision to the original case for change"}, {"body": "Within established healthcare companies, program management roles fall into two categories: programs that are building something new, and programs that are maintaining something that exists. The first is energizing; the second is almost entirely HOW-orientation work. In the next 30 days, evaluate any open program management roles against this distinction. Transformation-focused program offices in health systems and payers offer better compensation, more strategic visibility, and more energizing daily work.", "label": "Pursue transformation and change management programs, not operational run-state"}, {"body": "Healthcare programs live and die on clinical credibility. A program manager who is seen as a strategic business partner to at least one respected clinical leader — rather than as an administrative function — operates with significantly more influence and runs better programs. In your first 60 days on any program, identify the clinical leader who is most aligned with the program's purpose and invest in that relationship as a strategic priority, not a nice-to-have.", "label": "Build a coalition with one clinical champion early in every program"}], "challenging": [{"body": "Program management is defined by the tools that keep complex work organized: project plans, RAID logs, status reports, decision trackers, meeting notes. These are HOW-orientation artifacts, and they are the core administrative infrastructure of the role. In an established healthcare company, there is often a program coordinator or project analyst who owns some of this — but not all of it, and not forever. This is the part of the role that will drain you most consistently.", "label": "Maintaining the detailed project plan and tracking documentation"}, {"body": "Healthcare transformation programs run for 12 to 36 months. Once the direction is set and the work shifts to sustained implementation, your energy will drop. Keeping a cross-functional team engaged and moving through the middle months of a long program — when the initial excitement has faded and the end is not yet visible — is HOW-WHAT work, and it is draining for you to generate it artificially.", "label": "Managing team momentum through long implementation phases"}, {"body": "Multi-workstream programs in healthcare — where clinical, IT, operations, and compliance workstreams are all running in parallel and blocking each other — require someone who is energized by tracking granular dependencies. You are not that person. You can understand the dependencies conceptually, but maintaining the detail over months of execution is costly. Without a HOW-oriented project lead on each workstream, this will become a persistent drain and a structural risk.", "label": "Granular interdependency management across workstreams"}]}], "nextSteps": ["In the next two weeks, identify one person in your current organization or network who is energized by execution detail — maintaining the project plan, owning the documentation, tracking dependencies. Have a direct conversation about how you two could work together. This relationship is worth more to your career trajectory than any credential or technical skill you could develop right now.", "Before your next interview or internal opportunity conversation, write two sentences on why the specific problem this organization is working on matters — not why the company is well-regarded, but why the problem is worth solving. If you can write those sentences quickly and mean them, that is a signal this role will sustain your energy. If you can't, that is useful data worth acting on.", "Evaluate the next two or three roles you consider against one question: is the primary output of this role a direction or a deliverable? Roles where the output is a direction — a recommendation, a strategy, a decision — will energize you. Roles where the output is a deliverable — a document, a model, a process — will drain you over time, regardless of the title. Make this distinction a non-negotiable filter.", "Given your compensation priority, research the specific pay bands for strategic roles at the healthcare organization types you are targeting — health systems versus national payers versus health tech companies. The difference between the top and bottom quartile of established healthcare employers for early-career strategy and BD roles can be 30 to 40 percent. This is not a reason to avoid mission-driven organizations, but it is a reason to know the market before you negotiate."], "watchFors": ["Healthcare organizations run on compliance, documentation, and process fidelity — the granular execution work that follows a strategic decision will land on your plate unless you build a structural partnership with someone wired to own it", "In early career roles, your instinct to question the frame before committing to the plan can read as resistance to more senior colleagues; learning to signal conviction alongside curiosity will protect your credibility while you build it"], "energizers": ["Reframing a clinical, operational, or market problem that the organization has accepted as fixed — and making the case for why it needs to be approached differently", "Setting direction on high-stakes questions where purpose and momentum both matter, like new program launches, market entry decisions, or organizational change initiatives", "Pitching, presenting, and building stakeholder conviction around a direction you believe in — especially when you have to move a room that was heading somewhere else"], "alignmentLabel": "STRONG SIGNAL", "environmentNote": "Established healthcare companies — health systems, national payers, large pharmacy benefit managers, established health tech companies — offer a specific set of conditions that work for the WHY-WHAT profile and a specific set that work against it. The conditions that work: these organizations have consequential, well-resourced strategic problems and the institutional complexity that makes a profile like yours genuinely valuable. A WHY-WHAT analyst who can navigate a large health system's political and governance landscape and still push for a clear direction will outperform peers with stronger technical execution. The conditions that work against you: these organizations move slowly, reward consensus, and generate significant administrative and compliance overhead. The decision-making pace will frustrate you regularly, and the institutional culture can make directness — especially at a junior level — read as impatience rather than clarity.\\n\\nIn established healthcare companies, the signals that indicate an environment will work for you are specific: look for organizations where strategy is a real function with executive access, not a rebranded planning office. Look for leaders who can describe a strategic decision they made that went against institutional consensus. Look for roles where the problem you are working on is genuinely unsettled — not where the answer is known and you are executing toward it. In interviews, ask what the last major strategic direction change was and why it happened. If the answer is vague or recent, that tells you something about how much the organization actually reconsiders its direction.\\n\\nGiven your primary compensation priority, note that established healthcare companies show significant variation in strategic role compensation. Health systems below the top quartile in market position tend to underpay strategic roles relative to national payers, pharmacy benefit managers, and large health tech companies. Within any established company, the roles closest to growth, M&A, or transformation initiatives command a premium over operational program management or support functions. Be deliberate about which part of an established company you are entering — the organization's stability does not guarantee your role's upside.", "alignmentPercent": 82, "alignmentSentence": "The WHY-WHAT profile is a strong match for healthcare's defining tension: the field is full of urgent problems that demand both strategic clarity and decisive action, and that is precisely where this profile generates its best work."}	\N
a0ee1aaf-49fc-4b8e-bf49-69365fe15786	2026-07-01 15:50:22.900517+00	WHAT-WHY	Senior / Executive (12+ years)	Management	tech	\N	\N	Balanced	DiSC - D	{"roles": [{"fit": "At the VP level, product leadership is fundamentally about setting a destination the organization can pursue with urgency — and then holding that destination while teams move. Your WHAT-WHY wiring makes you exceptionally suited to this: you generate momentum, translate strategy into clear priorities, and give teams the conviction they need to move fast.\\n\\nThe role demands cross-functional influence, ruthless prioritization, and the ability to make consequential decisions before all the data is in. Your DiSC D profile compounds this — you will be direct, decisive, and comfortable owning hard calls. The risk at this level is moving past strategic reframes too quickly once a roadmap is set.", "title": "Vice President of Product Management", "energizing": [{"body": "Defining where the product goes next directly activates your primary WHY-oriented purpose drive.", "label": "Setting and defending product vision"}, {"body": "Getting engineering, design, and go-to-market moving in the same direction is your natural mode.", "label": "Driving cross-functional alignment at speed"}, {"body": "Choosing what not to build requires the conviction and decisiveness your profile generates naturally.", "label": "Prioritizing ruthlessly under resource constraints"}, {"body": "Backing a strategic bet and mobilizing the organization behind it is where you are at your best.", "label": "Sponsoring high-stakes product bets"}], "strategies": [{"body": "Put someone explicitly responsible for execution architecture directly on your team, not downstream.", "label": "Hire a HOW-primary Chief of Staff or Senior PM"}, {"body": "Identify one leader you trust to challenge the destination — and commit to giving them real hearing.", "label": "Build a standing WHY voice into your leadership team"}, {"body": "Create a dedicated quarterly session to question direction before execution reviews consume all leadership attention.", "label": "Separate roadmap reviews from strategy reviews"}, {"body": "Your DiSC D profile moves fast; your team needs to understand why, not just what was decided.", "label": "Make your decision-making rationale explicit in writing"}], "challenging": [{"body": "You will set direction confidently, but the process scaffolding that makes it repeatable requires a HOW partner.", "label": "Ensuring execution infrastructure beneath your roadmap"}, {"body": "Your DiSC D instinct is to push through friction, but strategic reframes from WHY voices deserve time.", "label": "Pausing when a WHY-oriented leader questions the destination"}, {"body": "Engineers and technical PMs need process clarity you will not naturally provide without structural effort.", "label": "Managing HOW-primary direct reports effectively"}]}, {"fit": "The COO role at a senior level is fundamentally about translating organizational ambition into sustained execution — holding the system together while the CEO sets direction. Your WHAT-WHY profile gives you the goal-orientation and people-mobilizing power this role demands. You will thrive driving operational momentum across multiple business units and ensuring the organization is actually moving, not just planning.\\n\\nAt executive scale, the COO also inherits significant process and infrastructure responsibility. This is the core watch-for for your profile: the operational depth the role demands — process design, cross-system dependencies, operational metrics architecture — requires deliberate HOW coverage in your leadership team.", "title": "Chief Operating Officer", "energizing": [{"body": "Translating board-level ambition into organizational motion is a direct expression of your primary orientation.", "label": "Mobilizing large organizations toward quarterly and annual goals"}, {"body": "Your DiSC D profile makes you effective and direct in performance conversations that others avoid.", "label": "Running high-stakes business reviews and driving accountability"}, {"body": "Redesigning how a company operates toward a clearer goal energizes your WHAT primary and WHY secondary.", "label": "Leading organizational transformation and restructuring"}, {"body": "Recruiting, developing, and holding a C-1 leadership team to high standards is work you find genuinely motivating.", "label": "Building and developing senior leadership teams"}], "strategies": [{"body": "Explicitly position this role as owning process architecture so you can own organizational momentum without overlap.", "label": "Build your VP of Operations as a structural HOW counterpart"}, {"body": "Your energy spikes at milestones — design the operating cadence around them so the organization benefits from that energy.", "label": "Establish a weekly operating rhythm with clear milestone checkpoints"}, {"body": "Create a personal rule for when organizational momentum should override and when a WHY challenge should stop you.", "label": "Be deliberate about when to push through vs. when to pause on strategy"}], "challenging": [{"body": "The COO is responsible for the systems underneath execution — work that is genuinely draining for your profile.", "label": "Owning process and operational infrastructure directly"}, {"body": "Your direct style is an asset, but board relationships reward patience and strategic ambiguity your profile finds costly.", "label": "Navigating complex board and governance dynamics"}, {"body": "Engagement, retention, and process compliance data require sustained HOW-oriented attention to use well.", "label": "Sustaining attention on organizational health metrics"}]}, {"fit": "The General Manager role is one of the highest-leverage matches for your profile at the senior level. You own a P&L, set the strategic direction for a business unit, and are accountable for the team that executes it. The role demands goal clarity, fast decision-making, cross-functional mobilization, and the ability to hold a team accountable to results — all of which sit at the intersection of your WHAT primary and WHY secondary.\\n\\nAt senior level in tech, GMs frequently operate across product, sales, and engineering simultaneously. Your DiSC D profile will be a direct asset in the commercial and organizational accountability dimensions. The structural challenge is that GMs also inherit significant operational complexity, and the gap between your directional confidence and the operational detail required to make it reliable will surface repeatedly.", "title": "General Manager", "energizing": [{"body": "Owning a destination with full accountability is the environment where your profile performs at its peak.", "label": "Setting the P&L vision and holding the business to it"}, {"body": "Deciding where to invest and where to cut requires exactly the conviction and speed your profile generates.", "label": "Making fast resource allocation and prioritization decisions"}, {"body": "Business development and market expansion work activates both your goal-orientation and your purpose sense.", "label": "Driving commercial momentum through partnerships and growth bets"}, {"body": "Recruiting, setting expectations, and creating a winning team environment is deeply energizing for your profile.", "label": "Building a high-performance leadership team culture"}], "strategies": [{"body": "GMs who are WHAT-primary consistently under-invest in operations leadership until a failure makes it obvious.", "label": "Hire a Head of Operations before you feel like you need one"}, {"body": "A dedicated session asking whether the goals themselves are still right protects you from executing brilliantly in the wrong direction.", "label": "Run a quarterly goal audit separate from business reviews"}, {"body": "Your DiSC D instinct is to state the direction — HOW-primary teams need to understand why to commit.", "label": "When communicating decisions to technical teams, lead with the problem, not the answer"}, {"body": "A WHY voice outside your chain of command gives you honest challenge on destination questions without organizational friction.", "label": "Identify one trusted WHY-primary peer for strategic pressure-testing"}], "challenging": [{"body": "Supply chain, process reliability, and cost structure details require HOW-primary coverage you must deliberately build in.", "label": "Managing the operational complexity underneath P&L ownership"}, {"body": "Your instinct is to move — pausing to genuinely evaluate whether the goal itself needs changing is structurally hard.", "label": "Holding direction steady when market signals create pressure to pivot"}, {"body": "Your DiSC D directness can read as dismissive to engineers and analysts who need more process context.", "label": "Communicating strategic rationale to technical or HOW-primary teams"}]}, {"fit": "Sales leadership at the senior level in tech is one of the most natural homes for a WHAT-WHY profile. The role is fundamentally about mobilizing a large team toward aggressive revenue goals, sustaining organizational momentum across quarters, and personally modeling the conviction that the destination is worth pursuing. Your DiSC D profile makes you credible, direct, and effective in commercial contexts where hesitation reads as weakness.\\n\\nAt the senior level, Head of Sales carries significant organizational design and pipeline infrastructure responsibility. This is where the watch-for lives: the CRM discipline, forecasting rigor, and process consistency that make a sales organization reliable are genuinely draining for your profile and require a strong HOW-primary VP of Sales Operations as a structural counterpart.", "title": "Head of Sales", "energizing": [{"body": "This is a direct expression of your primary orientation — a compelling goal with a team that needs to move.", "label": "Setting aggressive revenue targets and rallying the team to hit them"}, {"body": "Entering a high-stakes commercial conversation with conviction and closing it is deeply activating for your profile.", "label": "Personally driving strategic enterprise deals"}, {"body": "Designing territories, hiring leaders, and creating the team structure to hit the next stage of scale energizes you.", "label": "Building and restructuring the sales organization for growth"}, {"body": "Sharing conviction, modeling approach, and pushing the team toward the goal is work you find genuinely motivating.", "label": "Coaching senior reps and managers on winning strategies"}], "strategies": [{"body": "Pipeline discipline, forecasting, and CRM architecture must be owned by a HOW-primary leader, not inherited by you.", "label": "Build VP of Sales Operations as a non-negotiable structural counterpart"}, {"body": "Your WHY secondary means you perform better when the revenue goal connects to something that matters — make that visible to the team.", "label": "Tie team culture explicitly to a mission beyond quota"}, {"body": "Your natural mode is direct and fast — a consistent cadence protects HOW-primary direct reports who need predictable structure.", "label": "Create structured performance review checkpoints, not ad hoc management"}], "challenging": [{"body": "This is HOW-primary work that a WHAT-WHY executive must delegate structurally, not periodically.", "label": "Owning CRM hygiene, forecasting accuracy, and pipeline process"}, {"body": "Your DiSC D directness accelerates hard conversations — but HOW-primary reps need more context before they commit to change.", "label": "Managing underperformance conversations with patience and process"}, {"body": "Sustained momentum through quarters without wins requires energy expenditure that your profile finds genuinely costly.", "label": "Sustaining organizational motivation through long pipeline droughts"}]}], "nextSteps": ["In your next role evaluation, write two sentences on why the specific business problem this company is trying to solve matters — if you cannot write them with conviction, that is a meaningful signal about fit.", "Map your current or target leadership team for HOW-primary coverage: if no one on your direct team owns process architecture and execution infrastructure, that is the highest-leverage hire you can make.", "Before your next strategic planning cycle, schedule one session with a WHY-oriented peer explicitly for the purpose of questioning whether your goals are still the right goals — not how to hit them."], "watchFors": ["Optimizing execution brilliantly toward the wrong organizational goal", "Moving past strategic reframes before the team has genuinely considered them", "Leaving HOW-oriented direct reports under-supported on process infrastructure", "Confusing speed of decision with quality of direction"], "energizers": ["Rallying senior teams around a compelling, high-stakes destination", "Driving organizational momentum through ambiguity and complexity", "Making fast, high-conviction decisions with incomplete information", "Translating strategic goals into clear team priorities", "Building and accelerating growth in a product or business"], "environmentNote": "The signal to look for in any tech environment is whether the organization gives a senior leader a real destination to pursue, genuine authority to mobilize resources toward it, and a team structure that allows HOW-primary work to be owned by someone other than you. When those three conditions are absent, your profile will generate friction that no amount of effort resolves."}	\N
424f219a-d3a6-4100-91b8-9c7d4ffa13c4	2026-07-01 18:19:20.218903+00	HOW-WHY	Early Career (0–4 years)	Individual Contributor	\N	Established company	\N	Balanced	DiSC: iD | StrengthsFinder: Activator, Achiever, Woo, Strategic, Positivity	{"roles": [{"fit": "Data analysis is one of the highest-confidence role matches for a HOW-WHY in early career. The core output is understanding — turning complex, ambiguous data into insight that changes how the organization sees a problem. That is precisely where your primary orientation generates energy. You are entering a role where depth is the product, not a delay.\\n\\nIn an established company, you will find structured data environments, defined tooling, and real analytical problems with genuine stakes. The friction you will feel is organizational: pressure to summarize findings before you feel they are complete, and momentum requirements you will find draining.", "title": "Data Analyst", "energizing": [{"body": "When a metric moves unexpectedly, you will be the person who actually figures out why — not just that it moved. This is your primary orientation at full power.", "label": "Root cause investigation"}, {"body": "Designing the logic for how a business question gets answered, before touching a single dataset, is where your HOW orientation generates its best work.", "label": "Building analytical frameworks from scratch"}, {"body": "When you spot an assumption baked into a dashboard that no one has questioned, that moment is genuinely energizing — your WHY secondary asking whether the measurement is even the right one.", "label": "Finding the flaw in the existing model"}, {"body": "The moment a dense, multi-variable analysis resolves into one clear, defensible finding is deeply satisfying for this profile. That compression is the craft.", "label": "Synthesizing complexity into a clean insight"}], "strategies": [{"body": "Identify someone in your team who is energized by moving analysis into action. Share findings with them before presenting to stakeholders — their urgency will calibrate your timing.", "label": "Find one WHAT-oriented colleague to be your deployment partner"}, {"body": "Before beginning any investigation, write one sentence describing what a finished answer looks like. This creates a commit point that protects you from indefinite refinement.", "label": "Define 'complete enough' before you start each analysis"}, {"body": "Your StrengthsFinder profile wants to start and finish things. Channel that energy into publishing findings on a cadence — make shipping a milestone, not an afterthought.", "label": "Use your Activator and Achiever themes as a deployment forcing function"}, {"body": "Before writing a full report, draft the single most important finding in one sentence. This translation work is a drain, but doing it first makes the rest of the communication cleaner.", "label": "Build a one-slide summary habit for every analysis"}], "challenging": [{"body": "Stakeholders will frequently ask for findings before you are ready to give them. This is a structural drain, not a maturity gap — it will not get easier with time.", "label": "Shipping before the analysis feels complete"}, {"body": "Your DiSC iD and Woo themes will help you in rooms, but the communication density of your analytical thinking requires deliberate bridging work that costs energy.", "label": "Translating findings for non-analytical audiences"}, {"body": "In early career, scope is set by others. Being told which questions matter — and which do not — can feel like being handed an incomplete problem to solve.", "label": "Prioritizing when everything feels equally worth understanding"}]}, {"fit": "UX research is a strong structural match for a HOW-WHY in early career. The role exists to answer questions other teams cannot answer on their own — why users behave the way they do, where assumptions have broken down, what the product is actually solving versus what it claims to solve. That is your primary orientation applied to human systems instead of data systems.\\n\\nIn an established company, research is typically a recognized function with defined methods and stakeholder relationships already in place. You will enter with real problems to investigate and the autonomy to choose how to investigate them — which is where you do your best work.", "title": "UX Researcher", "energizing": [{"body": "Choosing the right method for a specific research question — not defaulting to the standard approach — is where your HOW orientation generates genuine engagement.", "label": "Designing a research methodology from first principles"}, {"body": "When your synthesis reveals something about users that contradicts a product assumption, that discovery moment is what this role is built to produce. It is high-energy work for you.", "label": "Finding the behavioral pattern nobody had named yet"}, {"body": "Your WHY secondary will consistently push back on the premise of a research brief. That instinct is a professional asset in this role, not a delay.", "label": "Interrogating whether the research question itself is the right one"}, {"body": "The analytical work of finding patterns across many hours of qualitative data rewards the depth your primary orientation demands. Few colleagues will stay in that material as long as you will.", "label": "Deep synthesis across multiple user sessions"}], "strategies": [{"body": "Document every insight, even from early scrappy studies. An established company often has no central research memory — building one makes your depth visible and structurally valuable.", "label": "Build a research repository from your first week"}, {"body": "Find the PM who is most curious about user behavior. That relationship is the deployment mechanism for your analytical work — without it, findings stay in a deck.", "label": "Partner with a product manager who will champion your findings"}, {"body": "Before any study, write out what decisions this research will influence and what findings would change the product team's direction. Scoping prevents the research from expanding past what is deployable.", "label": "Use your Strategic theme to scope each study before it starts"}, {"body": "Adopt a fixed template — three key insights, one recommendation per insight, one supporting quote — and use it every time. The constraint protects you from the communication density that loses stakeholders.", "label": "Commit to a findings-sharing format that constrains your density"}], "challenging": [{"body": "Product cycles move faster than rigorous research wants to. You will be asked to compress timelines in ways that feel like they compromise the work — and they sometimes do.", "label": "Delivering research on product team timelines"}, {"body": "Your natural output is a system map. Your stakeholders want a bullet. The translation is real work, and your DiSC iD energy will help you in the room but will not write the one-pager for you.", "label": "Socializing findings to stakeholders who want a headline"}, {"body": "When five teams want research simultaneously, prioritization decisions are made outside your control. Operating with an incomplete picture of which problems matter most is a recurring drain.", "label": "Prioritizing which research questions get answered"}]}, {"fit": "Business analysis in an established company is a strong early-career fit for a HOW-WHY. The role is fundamentally about understanding how a business system works — its processes, its data, its inefficiencies — and designing improvements that hold up under scrutiny. That maps directly to your primary orientation. The quality benchmark in this role is not speed; it is accuracy, and that is a meaningful difference from most early-career environments.\\n\\nYou will enter a role where stakeholders bring you problems they cannot fully articulate, and your job is to figure out what the problem actually is before proposing a solution. That diagnostic phase is where you will be most energized — and most valuable.", "title": "Business Analyst", "energizing": [{"body": "Documenting how a process actually works — versus how it is documented — and finding where it breaks is precisely the kind of investigative work your HOW orientation finds most engaging.", "label": "Process mapping and gap analysis"}, {"body": "Translating an ambiguous business need into a precise, testable specification is your HOW primary at its most useful. Established companies rarely have enough people who will do this work well.", "label": "Building the requirements document nobody else wanted to write"}, {"body": "Asking 'what happens when X' before implementation begins is your structural contribution to any project. In early career, this habit builds credibility faster than almost anything else.", "label": "Stress-testing proposed solutions before they are built"}, {"body": "When five stakeholders have five different versions of what the problem is, your ability to hold all of it and find the underlying system is where you outperform peers.", "label": "Synthesizing stakeholder input into a coherent picture"}], "strategies": [{"body": "Before analysis begins, agree with your manager on when a recommendation is needed. That date creates the commit point your work needs to deploy rather than continue refining.", "label": "Establish a 'recommendation by' date at the start of every workstream"}, {"body": "Your DiSC iD and StrengthsFinder themes give you a genuine relational warmth that is unusual for analytically-oriented roles. Use it to build credibility with stakeholders before you need it.", "label": "Use your Positivity and Woo themes to build stakeholder trust early"}, {"body": "A brief weekly message — one sentence on what you found, one on what you are investigating next — creates visibility without requiring you to shift into full communication mode repeatedly.", "label": "Build a standing update format and use it consistently"}, {"body": "Not every inefficiency you find is worth solving. Early in your career, ask your manager which findings will get resourced. This protects you from doing excellent analysis on problems nobody will act on.", "label": "Identify which process gaps are worth fixing versus worth documenting"}], "challenging": [{"body": "Project managers will want a recommendation on a timeline that does not accommodate your natural thoroughness. This is a structural tension in every project you join — not a solvable problem.", "label": "Delivering recommendations before the analysis feels complete"}, {"body": "Established companies reward those who communicate progress consistently. The check-in work feels like overhead to you, but absence of it creates credibility gaps in early career.", "label": "Maintaining visibility with stakeholders between deliverables"}, {"body": "Business problems are deeply connected. Your instinct to follow every thread before concluding is a quality asset and a timeline liability — you will need to choose which threads to cut.", "label": "Managing scope when every thread feels equally worth pulling"}]}, {"fit": "Quality assurance is a role built entirely around your primary orientation: finding what is wrong before it reaches the real world. In an established company, QA sits at the intersection of precision and consequence — the work matters because the cost of what you catch not being caught is real. That is the kind of stakes that makes depth feel worthwhile rather than self-indulgent.\\n\\nYou are entering a role where 'good enough' is not an acceptable output, and the thoroughness your HOW orientation demands is not a liability — it is the job description. Your WHY secondary will also push you to ask whether the right things are being tested, which is a genuine differentiator in most QA functions.", "title": "Quality Assurance Analyst", "energizing": [{"body": "Writing a test that finds an edge case nobody anticipated is exactly what your HOW primary orientation is built for. The rigor is the craft here, not overhead.", "label": "Designing test cases that break assumptions in the product"}, {"body": "When something fails, you will not stop at documenting the failure — you will want to understand the system condition that allowed it. That is analytical depth the role genuinely rewards.", "label": "Root cause analysis when a defect is found"}, {"body": "Your WHY secondary will push you to ask whether the team is testing the right things, not just whether it is testing them correctly. That meta-level scrutiny is valuable and often absent.", "label": "Questioning whether the test coverage itself is sufficient"}, {"body": "Writing test plans that teach the next person how the system works — not just what to click — is the kind of systemic contribution this role allows and your profile values.", "label": "Building test documentation that encodes institutional knowledge"}], "strategies": [{"body": "Seek out the testing work with the most ambiguity — where no script exists yet. That is where your analytical depth creates the most value and where you will find energy rather than drain.", "label": "Volunteer for exploratory testing assignments, not just scripted regression"}, {"body": "Document not just individual defects but the categories of assumptions that keep failing. This analytical layer makes your work visible as systems thinking, not just ticket-closing.", "label": "Build a defect pattern log from your first month"}, {"body": "Before sending a defect to a developer or product manager, write the business consequence in one sentence. This translation makes your findings land without requiring stakeholders to interpret technical detail.", "label": "Create a one-sentence risk summary for every defect you escalate"}, {"body": "In established companies, there is usually an engineer who has been burned by insufficient QA. That person will become your internal champion — their credibility is your deployment mechanism.", "label": "Find a senior engineer or developer who values your thoroughness"}], "challenging": [{"body": "Sprint cycles and release dates will create pressure to sign off before you feel the coverage is adequate. This is a structural drain you will encounter in every cycle — not an aberration.", "label": "Release pressure that compresses testing timelines"}, {"body": "Translating a technical finding into business impact language, under time pressure, to an audience that is not fully engaged with the risk — this is where your communication density becomes a real cost.", "label": "Communicating defect severity to stakeholders who want to ship"}, {"body": "Regression testing — re-running the same scenarios after every change — is real work in this role. The repetition is a drain on your HOW orientation, which seeks novelty and genuine complexity.", "label": "Staying energized in highly repetitive testing phases"}]}], "nextSteps": ["In your next role conversation or interview, ask specifically how the team handles situations where analysis and timelines are in tension — the answer will tell you whether your depth will be valued or managed around.", "Identify one person in your current or target organization who is energized by building momentum and moving findings into action. That relationship is more valuable right now than any technical skill you could develop.", "Before your next analysis or investigation, write one sentence describing what 'complete enough' looks like for this specific deliverable — and share it with your manager before you start.", "Your DiSC iD and Woo themes give you unusual relational energy for a precision-oriented profile. Use that in the first 60 days of any new role to build trust with stakeholders before you need to deliver hard findings."], "watchFors": ["Refining past the point where work should ship", "Communication density that loses colleagues who needed a summary", "Deployment drag when no one creates urgency to release", "Underestimating how much momentum work costs you"], "energizers": ["Diagnosing problems others have stopped trying to understand", "Building rigorous analysis that changes how a team sees something", "Finding the flaw in an assumption everyone has accepted", "Redesigning a process that everyone else just works around", "Deep autonomy over approach on a genuinely hard problem"], "environmentNote": "In an established company, your HOW-WHY orientation will find more structural support than in a startup — defined systems, real data, and problems with enough history to reward depth. The watch-for in this environment is credibility through visibility. Established companies notice people who communicate progress, not just deliver results. Your natural mode is to go quiet and go deep. Build the habit of surfacing your work before it is finished.\\n\\nThe other pattern to watch: established companies can have slow-moving decision processes that leave your analysis sitting without a deployment path. Find the stakeholder who acts on findings, not just the one who commissions them."}	\N
68a0871d-f1ed-4129-910e-970c2bea38a9	2026-07-01 18:30:41.438294+00	WHY-HOW	Early Career (0–4 years)	Management	tech	High-growth / Startup	work-life balance	Primary consideration	DiSC: Di | StrengthsFinder: Relator, Positivity, Maximizer, Woo, Adaptability	{"roles": [{"fit": "Product management in early-stage tech companies rewards the exact combination you bring: a deep need to understand why a product should exist before deciding what it should do, paired with the systems thinking to map how all the parts connect. In a startup, PMs who can articulate a sharp problem statement and reason through the full architecture of a solution are rare and valued.\\n\\nAt 0–4 years, you will find yourself drawn to the diagnostic work — user research, competitive analysis, defining success metrics — and energized when you can make a case for why a direction matters. Watch for the pressure to ship before the picture feels complete.", "title": "Product Manager", "energizing": [{"body": "Writing the problem statement and shaping the 'why now' narrative draws directly on your WHY orientation — this is where you will do your clearest thinking.", "label": "Problem Definition and Framing"}, {"body": "Synthesizing user interviews into a coherent model of how people interact with a product is HOW-orientation work at its best, and you will go deeper here than most early-career PMs.", "label": "User Research and Systems Mapping"}, {"body": "Your Relator and Woo strengths give you real interpersonal range — you can build the trust needed to align engineering, design, and sales around a shared direction.", "label": "Cross-Functional Alignment"}, {"body": "Writing PRDs, strategy memos, and product briefs channels your need for completeness and gives your thinking a form the team can act on.", "label": "Strategy Documentation"}], "strategies": [{"body": "Find the engineer or tech lead who wants to move fast and trusts your direction. Let them hold sprint momentum while you hold product clarity.", "label": "Partner with a WHAT-oriented Engineering Lead"}, {"body": "For each initiative, write one sentence on what 'good enough to ship' looks like before you begin. This gives you a forcing function that respects your need for completeness without blocking delivery.", "label": "Define 'Complete Enough' Before You Start"}, {"body": "You build deep one-on-one trust naturally. Schedule weekly user conversations and let those relationships become the grounding for your product instincts.", "label": "Use Your Relator Strength for User Proximity"}, {"body": "Protect two to three mornings a week for analysis and writing. In a startup, calendar white space disappears — block it before others fill it.", "label": "Block Deep Work Time Explicitly"}], "challenging": [{"body": "Startup PMs are expected to push product out the door fast. Your instinct to fully understand before committing will create friction with engineering teams in sprint cycles.", "label": "Sprint Velocity and Shipping Pressure"}, {"body": "Your Maximizer strength and HOW orientation both pull toward getting things right — but startup PM work demands cutting scope and accepting 'good enough' repeatedly.", "label": "Ruthless Prioritization"}, {"body": "Status updates, coordination meetings, and managing up are WHAT-orientation drains that grow as the team grows — and they will pull you from the deep work that energizes you.", "label": "Stakeholder Management Overhead"}]}, {"fit": "Engineering management at an early-stage startup asks you to hold two things simultaneously: a deep understanding of how the technical systems work and a clear sense of why the team's work matters to the company's direction. Your WHY-HOW profile is structurally suited to this — you will be drawn to diagnosing why a team is underperforming and to building the technical and organizational architecture that fixes it.\\n\\nIn years one through four, you will find yourself most engaged when you are close to both the people and the problem. The challenge is that EM roles increasingly demand the WHAT orientation — driving delivery, unblocking sprint cycles, and managing organizational momentum — and that work will cost you energy you cannot fully recover.", "title": "Engineering Manager", "energizing": [{"body": "Reviewing system design decisions and helping engineers think through trade-offs draws directly on your HOW orientation — you will add real value here and find it genuinely absorbing.", "label": "Technical Architecture Reviews"}, {"body": "Your Relator and Maximizer strengths make deep individual mentorship a natural source of energy — you will remember what each engineer cares about and push them toward their best work.", "label": "One-on-One Coaching"}, {"body": "When a team is slowing down for unclear reasons, your instinct to trace root causes rather than apply surface fixes will surface issues others miss.", "label": "Diagnosing Team Dysfunction"}], "strategies": [{"body": "In your first 30 days, tell each direct report what you care about in a one-on-one. This sets expectations and lets your Relator strength do its work immediately.", "label": "Be Explicit About Your Coaching Philosophy Early"}, {"body": "Find someone who wants to own delivery tracking and sprint coordination. This is WHAT-orientation work — delegate it structurally, not occasionally.", "label": "Hire or Partner with a Strong Technical Program Manager"}, {"body": "You will earn credibility fastest by asking better questions about technical trade-offs than anyone else in the room — lean into this rather than competing on tenure or speed.", "label": "Anchor Your Authority in Diagnostic Depth"}], "challenging": [{"body": "Startups measure EMs heavily on shipping. Holding the team's delivery pace while resisting your own pull toward depth and completeness will be a recurring tension.", "label": "Delivery Accountability at Startup Speed"}, {"body": "Weekly status updates, roadmap reviews, and executive syncs are coordination overhead that drains your energy without engaging your thinking.", "label": "Managing Up and Reporting Cadence"}, {"body": "At 0–4 years, senior engineers may have more technical experience than you. Establishing the credibility to slow a technical decision down and ask harder questions takes deliberate effort.", "label": "Early-Career Authority in a Technical Room"}]}, {"fit": "Product operations is the role that lives between strategy and execution — diagnosing where the product development process is breaking, designing better systems, and ensuring the insights from customers and data actually reach the decisions that matter. For a WHY-HOW in early-career tech, this role offers something rare: it rewards deep systems thinking and genuine curiosity about why things work the way they do, without requiring you to own delivery velocity directly.\\n\\nIn a startup context, product ops roles are often undefined and self-directed, which suits your profile well. You will spend your best energy building frameworks and surfacing insights — and you will need a strong WHAT partner to ensure those frameworks get adopted rather than admired.", "title": "Product Operations Manager", "energizing": [{"body": "Auditing how product decisions get made and redesigning the process so it works better is HOW-orientation work in a real organizational context — you will go deep and find it energizing.", "label": "Process Diagnosis and Redesign"}, {"body": "Pulling together qualitative and quantitative signals into a coherent picture of where the product is working and where it isn't draws on your WHY and HOW orientations together.", "label": "Synthesizing Customer and Product Data"}, {"body": "Designing the rituals, templates, and systems that make the product team more effective is a high-leverage contribution that rewards completeness and rigor.", "label": "Cross-Functional Framework Building"}, {"body": "Your instinct to ask 'what happens when X?' before the team encounters X is a genuine organizational asset in a startup where few people are looking that far ahead.", "label": "Surfacing Systemic Risks"}], "strategies": [{"body": "Find the PM or program manager who wants to drive adoption of new processes. Position your work as building what they will deploy — not owning the rollout yourself.", "label": "Identify Your WHAT Partner in the First 60 Days"}, {"body": "Pick the single most broken part of how the team works and fix it completely. One fully functioning system earns more credibility than five half-built ones.", "label": "Start with One Process, Not Five"}, {"body": "Your natural ability to connect with people quickly gives you access to candid information across the organization. Use it deliberately to gather the signal your analysis needs.", "label": "Use Your Woo Strength to Build Stakeholder Access"}], "challenging": [{"body": "Building a better process is one thing. Getting a fast-moving team to actually use it requires WHAT-orientation energy — rallying, pushing, following up — that will drain you.", "label": "Adoption and Change Management"}, {"body": "In a startup, product ops roles are often undefined. The constant negotiation of what the role is and isn't requires comfort with incomplete structure that your HOW orientation resists.", "label": "Scope Ambiguity in Early-Stage Companies"}]}, {"fit": "Strategy and operations roles at high-growth startups are often the most intellectually demanding generalist positions available at early career — they ask you to diagnose organizational problems, build solutions, and influence decisions across functions without direct authority. Your WHY-HOW profile is well-suited to the diagnostic and solution-design work at the core of these roles: you will think more carefully about root causes and design more complete solutions than most peers at the same career stage.\\n\\nCompensation in well-funded tech startups tends to be strong for strategy and ops roles, and equity upside is real. The friction is that these roles also demand significant WHAT-orientation work — managing project timelines, driving cross-functional momentum, and producing outputs at startup speed — which will be a recurring energy cost.", "title": "Strategy and Operations Manager", "energizing": [{"body": "Mapping why a team, process, or business unit is underperforming and designing a rigorous solution is the core work of strategy and ops — and it draws directly on your WHY and HOW orientations.", "label": "Organizational Diagnostics"}, {"body": "Creating the models, frameworks, and decision tools the leadership team uses to navigate complex choices is HOW-orientation work with direct organizational impact.", "label": "Building Analytical Frameworks"}, {"body": "Your WHY orientation gives you genuine insight into how operational decisions connect to strategic direction — a perspective that is rare and valued at the leadership table.", "label": "Connecting Work to Company Direction"}, {"body": "Your Relator and Maximizer strengths make you a natural mentor — and in strategy and ops teams, developing junior analysts is one of the highest-leverage things a manager can do.", "label": "Mentoring and Developing Early Analysts"}], "strategies": [{"body": "Before starting any initiative, write a two-sentence statement of the problem and why solving it matters now. This keeps your WHY orientation engaged and gives stakeholders a clear framing.", "label": "Anchor Each Project in a Sharp Problem Statement"}, {"body": "Find the program manager or chief of staff who owns timelines and follow-through. Make that relationship a structural one — not a one-off coordination call.", "label": "Build a Delivery Partner Relationship Early"}, {"body": "Early-career employees in strategy and ops gain credibility partly through presence. Your Positivity and Woo strengths give you natural access to senior rooms — use them to ask the deeper question, not just to be liked.", "label": "Use Your Positivity Strength Intentionally in Leadership Rooms"}, {"body": "In your first performance conversation, ask explicitly for one initiative you can own end-to-end with sufficient time to do it properly. This gives your HOW orientation a home while the rest of the role stays broad.", "label": "Negotiate for Depth on One or Two Workstreams"}], "challenging": [{"body": "Strategy and ops in a startup is not a consulting engagement — work is expected to move fast and ship rough. Your instinct to fully understand before committing will create friction.", "label": "Pace of Delivery in a Startup Environment"}, {"body": "Influencing cross-functional teams without direct authority requires WHAT-orientation energy — persistent follow-through, relationship maintenance, and momentum-keeping that drains your profile.", "label": "Managing Without Deep Authority"}, {"body": "The generalist nature of strategy and ops means you will often need to move on before a problem feels fully solved — a persistent source of tension for your HOW orientation.", "label": "Breadth vs. Depth Trade-offs"}]}, {"fit": "Customer success in a high-growth tech startup asks you to build deep relationships with customers, diagnose why they are or aren't getting value from the product, and design solutions that work for them systemically — not just in the moment. Your WHY-HOW profile and your Relator, Woo, and Maximizer StrengthsFinder themes make you structurally well-suited to the depth-oriented side of this role: you will naturally go further into a customer's context than most CSMs, and that depth often drives the retention and expansion outcomes startups care about most.\\n\\nCompensation in enterprise-facing CSM roles at funded startups often includes strong base salary and variable tied to net revenue retention — a structure that rewards the long-game relationship building your profile does naturally. The challenge is the volume and velocity that early-stage CSM teams often demand.", "title": "Customer Success Manager", "energizing": [{"body": "Spending real time understanding why a customer adopted the product, where it is or isn't working, and what success actually looks like for them is HOW-WHY work at its core.", "label": "Deep Customer Diagnostics"}, {"body": "Building a rigorous, customer-specific success plan that maps milestones to their actual business goals draws on your systems thinking and gives your completeness instinct a real output.", "label": "Designing Onboarding and Success Plans"}, {"body": "Preparing and delivering a quarterly business review that connects product usage to customer outcomes is WHY-HOW work — you will do this more rigorously than most peers and be recognized for it.", "label": "Executive Business Reviews"}], "strategies": [{"body": "Smaller account volumes allow you to do the deep diagnostic work that generates real retention. Avoid SMB CSM roles — the volume will drain you before the depth has a chance to work.", "label": "Negotiate for a Mid-Market or Enterprise Segment"}, {"body": "Create a simple decision framework for yourself: which requests require a thorough response and which can be handled with a quick answer or a handoff. This protects your deep work time without sacrificing responsiveness.", "label": "Build a Personal Triage System for Reactive Requests"}, {"body": "The deep one-on-one trust your Relator theme builds is genuinely differentiated in CS — customers who feel known stay. Make relationship depth an explicit part of your account strategy, not just a personal style.", "label": "Use Your Relator Strength as a Retention Strategy"}], "challenging": [{"body": "Early-career CSM roles at startups often require managing 30–50+ accounts simultaneously. Your instinct to go deep on every relationship is structurally incompatible with that volume.", "label": "High-Volume Account Management"}, {"body": "Customers expect fast responses; your natural mode is to fully understand before responding. This tension will show up most in reactive support situations.", "label": "Urgency and Response Time Expectations"}]}, {"fit": "Management consulting is one of the roles where your profile has the strongest structural fit in the early-career tech space. The core of the work — deeply understanding a client's system, diagnosing what is actually wrong, and designing a solution rigorous enough to hold up — is WHY-HOW work in its purest form. In tech-focused consulting practices, you will encounter clients whose problems are complex and whose organizations reward the kind of thinking you do naturally.\\n\\nCompensation at top-tier and specialist tech consulting firms at early career is strong and transparent. The meaningful tension is pace: consulting runs on deliverable cycles and client deadlines that reward WHAT-orientation energy, and your instinct to fully understand before committing will need a structural outlet, not just personal discipline.", "title": "Management Consultant", "energizing": [{"body": "The initial diagnostic phase of a consulting engagement — understanding the client's system, identifying the real problem, and forming hypotheses — is where your WHY-HOW profile does its best work.", "label": "Problem Framing and Hypothesis Development"}, {"body": "Synthesizing complex qualitative and quantitative data into a coherent picture of what is actually happening is HOW-orientation work that you will find genuinely absorbing.", "label": "Deep Research and Synthesis"}, {"body": "Building the architecture of a solution — not just the headline recommendation but the full logic of how it would work — is HOW work with real organizational consequence.", "label": "Designing Recommendations"}, {"body": "Your Relator and Woo strengths give you real range with clients — you can build deep trust and broad warmth, which translates directly into client retention and referrals.", "label": "Client Relationship Building"}], "strategies": [{"body": "Your analysis will often be the strongest on the team. The gap will be translating it into executive communication. Find a senior consultant whose decks are clean and simple, and study how they make choices about what to cut.", "label": "Find a Mentor Who Is Strong at Slide Narrative"}, {"body": "In the first two weeks of any engagement, invest in building genuine one-on-one relationships with two or three key client stakeholders. The candid information those relationships unlock will make your analysis sharper than anything else.", "label": "Use Your Relator Theme for Client Access"}, {"body": "Before beginning a work product, agree with yourself and your project lead on what 'done' looks like. This gives your HOW orientation a finish line rather than an open horizon.", "label": "Define Your 'Complete Enough' Threshold Per Deliverable"}, {"body": "Boutique firms focused on tech strategy or organizational design will give you more depth per engagement than generalist consulting. This protects the quality of your thinking and reduces the context-switching drain.", "label": "Seek Firms with Specialist Tech or Org Design Practices"}], "challenging": [{"body": "Consulting timelines move fast and the expectation is polished output under time pressure. Your instinct to refine past the point of diminishing returns will create friction in client delivery cycles.", "label": "Deliverable Velocity and Project Deadlines"}, {"body": "Your natural communication is dense and complete — a reflection of how thoroughly you have thought through a problem. Executive audiences often need the opposite: sparse, high-confidence recommendations.", "label": "Communicating to Non-Analytical Audiences"}, {"body": "The breadth of consulting — moving between clients and industries without sufficient time to go deep on any one — is a recurring energy drain for your HOW orientation.", "label": "Context-Switching Across Clients and Industries"}]}], "nextSteps": ["Before your next interview or coffee chat, write two sentences on why the specific problem this company is solving matters — if you cannot write them with conviction, treat that as a signal worth taking seriously.", "Look at your current or target role and identify the one person on the team whose primary energy comes from driving momentum and delivery. That relationship is your most important structural investment — build it deliberately.", "For each role you are seriously considering, ask your potential manager directly: 'What does a great week look like for someone in this role?' Listen for whether the answer is mostly about outputs shipped or mostly about problems understood and solved.", "Given that compensation is a primary consideration, research total compensation data — base, equity, and bonus structure — for each role type at Series A through Series C companies in your target segment before your first offer conversation, so you are negotiating from a specific number rather than a general preference."], "watchFors": ["Momentum stalls when analysis crowds out action", "Shipping pressure in startups will feel relentless and uncomfortable", "Management overhead competes directly with deep thinking time", "Early-career authority gaps make it hard to slow teams down"], "energizers": ["Diagnosing why a system or team is underperforming", "Building something rigorous from early ambiguity", "Connecting a team's work to a larger purpose", "Designing how a product or process should actually work", "Mentoring others through complexity with depth and care"], "environmentNote": "High-growth startup environments reward speed, iteration, and tolerance for ambiguity — qualities that run against your natural mode in important ways. The work that will energize you most is diagnosis, systems design, and building something rigorous, and startups do have that work. But it sits inside an environment that will also consistently push you to ship before you feel ready, coordinate across more people than you want to, and treat momentum as the primary signal of success.\\n\\nThe specific thing to look for in a startup is whether the leadership team values depth or just speed. Interview the founders or your potential manager on how they make hard product or strategic decisions. If the answer is instinct and velocity, that environment will drain you faster than the role itself suggests. If the answer involves real diagnostic work and a genuine investment in getting the problem right, you have found a startup where your profile has a structural home."}	\N
3bd61c9d-8cff-4ce3-b622-753918d4720f	2026-07-01 18:37:17.385275+00	HOW-WHY	Early Career (0–4 years)	Management	finance	High-growth / Startup	autonomy	Primary consideration	DiSC: DC | StrengthsFinder: Activator, Connectedness, Futuristic, Focus, Woo	{"roles": [{"fit": "At a high-growth fintech or financial data company, an Analytics Manager is asked to build the function, not just run it — defining how analysis gets done, what rigor looks like, and which questions the team is equipped to answer. That design work is squarely in your primary orientation. The role rewards depth over speed, and in early-stage companies, the person who builds the analytical foundation often shapes how the whole organization makes decisions.\\n\\nYour Activator theme will push you to get the team moving, and your Focus theme will keep the work from scattering. The challenge is that management in a startup moves fast, and you will be pulled toward deployment timelines before your standards feel met.", "title": "Analytics Manager", "energizing": [{"body": "Defining what questions the team answers, how they validate findings, and what quality looks like — this is primary-orientation work that energizes you and sets the standard others build on.", "label": "Designing the analytical framework"}, {"body": "Root cause analysis across complex data pipelines is where your HOW orientation produces outsized value that most early managers cannot match.", "label": "Diagnosing why a metric or model is producing wrong outputs"}, {"body": "Building a team where every member can hold complexity without shortcuts gives you the HOW coverage that makes the function durable.", "label": "Hiring for analytical depth"}, {"body": "Your WHY secondary orientation means you care whether findings land — not just whether they're correct — which makes your output unusually actionable for leadership.", "label": "Connecting analysis to strategic decisions"}], "strategies": [{"body": "Find a senior analyst who thrives on momentum and milestone energy. That person manages team pace and delivery urgency while you protect analytical quality.", "label": "Hire a WHAT-primary deputy early"}, {"body": "Before a sprint starts, specify what validation standard applies to this analysis — not all analyses require the same depth. This protects both quality and delivery.", "label": "Define your personal 'complete enough' threshold per decision type"}, {"body": "Write every finding in full for the team record, then draft a three-sentence version for leadership. The depth stays; the presentation adapts.", "label": "Build a two-format communication habit"}, {"body": "Don't accept default sprint cycles. At the start of each project, establish the timeline you need to meet your standard — before momentum pressure sets in.", "label": "Negotiate deliverable timelines at the project intake stage"}], "challenging": [{"body": "Your WHAT is tertiary — rallying energy when work is slow-moving or inconclusive will cost you, and your team will look to you for that fuel.", "label": "Sustaining team momentum during long analytical cycles"}, {"body": "Fintech startups move on incomplete data. Being asked to present findings before your own confidence threshold is met will be a recurring, genuine drain.", "label": "Shipping analyses under startup time pressure"}, {"body": "Founders and C-suite leaders in growth companies want conclusions fast. Your natural communication depth will require active translation to avoid losing the room.", "label": "Managing up with brevity"}]}, {"fit": "At a high-growth lending platform, payments company, or crypto-adjacent fintech, a Risk Manager in years one through four is usually the person who builds the risk function from limited infrastructure — identifying exposure, designing controls, and making the case to leadership before something breaks. Your HOW orientation is structurally suited to this: you see failure modes others miss, and your WHY secondary means you will connect risk findings to outcomes that actually matter to the business.\\n\\nCompensation at this level in growth-stage financial services is strong, particularly when risk oversight is tied to regulatory compliance or capital decisions. Autonomy is typically high because the function is being built, not inherited.", "title": "Risk Manager", "energizing": [{"body": "Early-stage risk functions have unmapped territory — your HOW orientation finds the structural gaps before they become incidents.", "label": "Identifying exposures nobody has formally named yet"}, {"body": "Designing how risk gets monitored, escalated, and mitigated in a new environment is primary-orientation work with lasting organizational impact.", "label": "Building the control framework from scratch"}, {"body": "Your WHY secondary means risk findings don't stay in the function — you can translate them into the language of decisions the business actually needs to make.", "label": "Connecting risk posture to strategic decisions"}], "strategies": [{"body": "Before presenting risk findings, map the three questions leadership will ask. Preparing those answers in advance compresses your communication without sacrificing accuracy.", "label": "Use your Futuristic theme to pre-scenario plan leadership conversations"}, {"body": "That person becomes the internal champion who moves the risk recommendations forward. Your analysis reaches decisions faster without you having to generate the momentum.", "label": "Partner with a business-line owner who has WHAT energy"}, {"body": "Document your assumptions explicitly and flag confidence levels. This protects your standards while allowing you to deliver under startup time constraints.", "label": "Set a 'flag and move' protocol for incomplete data situations"}], "challenging": [{"body": "Growth-stage leaders want to move. Delivering a thorough risk analysis to someone who wants a yes or no will require active compression of your natural depth.", "label": "Communicating risk to impatient founders"}, {"body": "Risk decisions in startups often must be made with partial information. Being pushed to commit to a risk recommendation before you feel ready is structurally draining.", "label": "Creating urgency without the data being complete"}]}, {"fit": "At a growth-stage hedge fund, systematic trading firm, or quantitative asset manager, a Quantitative Research Analyst spends the majority of their time building and stress-testing models — finding where assumptions break, improving the architecture, and ensuring the system produces reliable outputs. This is among the highest-fit environments your profile can enter in finance. The work rewards depth over speed, and organizations that do this well protect analytical time from organizational overhead.\\n\\nCompensation at quant firms is among the highest in finance for early-career professionals. Management at this level means leading a small research team or project — depth is still the primary output, not organizational administration.", "title": "Quantitative Research Analyst", "energizing": [{"body": "Finding where a model breaks under conditions nobody tested yet is primary-orientation work — and in quant finance, it directly produces economic value.", "label": "Stress-testing model assumptions until they hold"}, {"body": "Root cause analysis on a system with real stakes is exactly the kind of problem your HOW orientation is built for.", "label": "Redesigning a model architecture that's producing unexplained variance"}, {"body": "Directing the depth and methodology of a focused team — rather than managing organizational processes — plays to your primary orientation while giving you early leadership experience.", "label": "Leading a small research team on a defined analytical problem"}, {"body": "Your WHY secondary means you won't stop at producing a correct output — you'll care whether it changes how a decision gets made.", "label": "Connecting model outputs to portfolio decisions"}], "strategies": [{"body": "Before a research project starts, establish with leadership what 'production ready' means for this specific model. Define the validation standard, then work backward to a timeline.", "label": "Negotiate research timelines before they are set externally"}, {"body": "That person manages team momentum, deadline urgency, and communication velocity while you protect analytical quality on the work that matters most.", "label": "Hire or partner with a research associate who has WHAT energy"}, {"body": "Block multi-hour research windows before the week fills with coordination requests. Your best output requires uninterrupted depth — protect it structurally.", "label": "Use your Focus StrengthsFinder theme to protect deep work blocks"}], "challenging": [{"body": "Trading environments have deployment schedules. Being asked to release a model at 85% confidence when you know what the remaining 15% would reveal is a genuine structural drain.", "label": "Deploying a model before it feels complete"}, {"body": "WHAT-tertiary managers struggle to sustain momentum energy. On a team grinding through a six-month research problem, you will need someone else generating the forward drive.", "label": "Managing team energy during long research cycles"}]}, {"fit": "At a growth-stage lending platform, venture debt firm, or specialty finance company, a Credit Analyst in early career builds the judgment and analytical infrastructure that determines which bets the company makes. The work is primarily HOW-oriented — evaluating financial statements, stress-testing assumptions, building credit models, and identifying what the surface numbers don't show. Your profile is structurally suited to this, and your WHY secondary means you will connect credit findings to actual business decisions rather than producing analysis that lives in a report.\\n\\nIn a startup lending environment, analysts with your depth often move into lead roles faster than in established institutions, because the function is being built and analytical ownership is visible.", "title": "Credit Analyst", "energizing": [{"body": "Identifying what a clean-looking credit file is hiding requires the kind of structural pattern recognition your HOW orientation is built for.", "label": "Finding the risk a borrower's financials are obscuring"}, {"body": "When a new asset class or borrower type arrives with no existing model, your primary orientation generates the framework others will use.", "label": "Building the credit model from first principles"}, {"body": "Your WHY secondary means your analysis naturally reaches toward what it means for the business — which makes you unusually useful in credit committee rooms.", "label": "Connecting credit findings to portfolio-level decisions"}], "strategies": [{"body": "Force the summary to exist before the depth is written. This creates a communication artifact for stakeholders without requiring you to compress after the fact.", "label": "Build a credit memo template with an executive summary section first"}, {"body": "Small credits get a defined shorter process; large credits get your full depth. This protects quality where it matters most without creating friction on routine decisions.", "label": "Define tiered analysis standards by credit size"}, {"body": "That person runs the pipeline, manages the workflow pace, and keeps the team's ticket queue moving while you focus on the complex credits that require your depth.", "label": "Find a WHAT-primary credit associate for volume management"}], "challenging": [{"body": "High-growth lenders need fast decisions. Being pushed to approve at speed before you've exhausted your own analysis is a structural conflict with your quality standard.", "label": "Approving credits under volume pressure before full analysis is complete"}, {"body": "Leading a credit team requires generating forward momentum, keeping analysts engaged, and sustaining output velocity — all WHAT-tertiary friction for you.", "label": "Managing a junior analyst team's energy and pace"}, {"body": "Credit committee members or founders who didn't read the memo will want a brief summary. Your thorough analysis requires active translation to reach them.", "label": "Compressing complex credit narratives for non-analytical stakeholders"}]}, {"fit": "At a high-growth fintech, neobank, or financial infrastructure company, a Financial Planning and Analysis Manager at early career level typically inherits a broken or underdeveloped forecasting function and is asked to build it properly. That design challenge — understanding why the current model is wrong, redesigning the architecture, and building the process that makes forecasting reliable — is primary-orientation work. Your HOW orientation produces the analytical integrity that makes the function credible to leadership, and your WHY secondary connects the numbers to strategic decisions.\\n\\nIn startup environments, the FP&A function is often the first place leadership looks when they need analytical clarity. Visibility and compensation for this role in growth-stage companies are meaningfully higher than in established institutions.", "title": "Financial Planning and Analysis Manager", "energizing": [{"body": "Finding the structural flaw in a model everyone else has accepted produces exactly the kind of insight your HOW orientation is energized by.", "label": "Diagnosing why the existing forecast model keeps missing"}, {"body": "Building a model that actually reflects how the business works — not how someone assumed it worked — is primary-orientation work with direct financial impact.", "label": "Redesigning the forecast architecture from the variance analysis up"}, {"body": "Your WHY secondary means FP&A output in your hands doesn't stay in a spreadsheet — it reaches decisions.", "label": "Connecting financial performance to decisions the leadership team needs to make"}, {"body": "Hiring analysts who share your commitment to getting it right creates a function with genuine credibility rather than one that produces optimistic numbers on demand.", "label": "Building a small team with the right analytical discipline"}], "strategies": [{"body": "Define what 'board-ready' means for your forecast — specific confidence intervals, tested assumptions, documented caveats. This gives you a defensible standard rather than a moving target.", "label": "Establish a model validation protocol before budget season begins"}, {"body": "That person manages the delivery calendar, keeps the team on deadline, and creates urgency — while you protect the analytical integrity of what gets delivered.", "label": "Hire an FP&A analyst with WHAT energy as your first team member"}, {"body": "FP&A managers who are trusted by the business get better data and earlier access to decisions. Your interpersonal range makes that relationship-building available to you — use it intentionally.", "label": "Use your Woo and Connectedness themes to build credibility with business-line leaders"}, {"body": "This normalizes analytical honesty in the organization, protects your credibility when forecasts miss, and educates leadership on what the numbers actually mean.", "label": "Build a 'assumptions and caveats' section into every forecast presentation"}], "challenging": [{"body": "Board cycles don't wait for complete analysis. Being asked to present a forecast you don't fully trust yet is a recurring structural tension in this role.", "label": "Producing a forecast under board deadline pressure before the model feels validated"}, {"body": "FP&A has hard delivery deadlines and the manager is responsible for the team making them. Generating the rallying energy to hit those deadlines is WHAT-tertiary drain.", "label": "Driving team urgency during budget season"}]}, {"fit": "At a high-growth payments company, crypto platform, or lending startup, a Compliance Manager is often building regulatory infrastructure from limited precedent — designing controls, interpreting ambiguous rules, and identifying where the business's current practices create exposure. This is structural design work at its core, and your HOW orientation is the primary asset. Your WHY secondary means you will connect compliance findings to why they matter for the business, not just whether a box is checked.\\n\\nCompliance managers at growth-stage companies in financial services carry significant autonomy over how the function is built. Compensation is strong, particularly when the role carries regulatory examination responsibility or is tied to licensing decisions.", "title": "Compliance Manager", "energizing": [{"body": "Finding the gap between what the business is doing and what the regulation actually requires is root-cause analytical work at the center of your HOW orientation.", "label": "Mapping where current business practices create regulatory exposure"}, {"body": "Building compliance infrastructure for a product that didn't exist before requires the kind of first-principles HOW thinking that produces durable work.", "label": "Designing the control architecture for a new product launch"}, {"body": "Your WHY secondary positions you to make compliance a strategic input rather than a reactive filter — unusual value in a startup environment.", "label": "Connecting regulatory requirements to strategic decisions the business hasn't made yet"}], "strategies": [{"body": "You design the controls and identify the gaps; someone else owns the deadline management and cross-functional follow-up. This is a structural requirement, not a delegation preference.", "label": "Build a remediation tracking system with a WHAT-oriented operator owning the follow-through"}, {"body": "Your StrengthsFinder Activator gives you a forward-motion instinct that partially compensates for your WHAT tertiary — use it to push your own compliance projects to completion stages.", "label": "Use your Activator theme to set a bias toward action on your own work"}, {"body": "Every compliance finding gets a complete analytical record for the file and a one-page brief for leadership. Build this as a standard practice before the pressure to compress is urgent.", "label": "Develop a two-version documentation habit: full analysis and executive decision brief"}], "challenging": [{"body": "Compliance managers must mobilize other teams to fix things. Generating that momentum with people who have competing priorities is WHAT-tertiary drain.", "label": "Creating urgency for remediation work with the product and engineering teams"}, {"body": "Growth-stage founders view compliance as friction. Communicating risk with enough brevity and conviction to actually change behavior requires active compression of your analytical depth.", "label": "Presenting regulatory findings to founders who want to move"}]}], "nextSteps": ["Before your next interview, write two sentences on what specifically is broken in how that company handles analytical decision-making — and why fixing it matters. If you can't write them, the role isn't giving you a real problem to own.", "Identify one person in your network who is energized by project management and organizational momentum work. That relationship is worth more to your early career than any technical skill you could develop right now.", "When evaluating offers, weight the quality of the problem and the autonomy over the analytical approach over the brand of the company. You will outperform in environments that give you something genuinely complex to investigate.", "Find a startup finance role where the analytical function is visibly underdeveloped — not one where you inherit a clean system. Your HOW orientation produces the most value, and earns the most compensation, when the infrastructure needs to be built from scratch."], "watchFors": ["Deploying work before it feels fully validated", "Momentum pressure overriding depth that protects the team", "Communication density losing fast-moving startup audiences", "Rallying team energy when the problem is still forming"], "energizers": ["Diagnosing what's actually broken in a financial system", "Building a team with the right analytical depth", "Autonomy to define how rigorous work gets done", "Connecting complex findings to decisions that matter", "Designing processes that prevent errors before they happen"], "environmentNote": "High-growth financial services environments give your profile genuine autonomy and meaningful problems — but they also create relentless deployment pressure. The signal to look for is whether a company distinguishes between speed and sloppiness. If the culture rewards moving fast as an end in itself, your quality standard will be in constant conflict with organizational expectations. The right startup for your profile moves with urgency but values getting it right over shipping first.\\n\\nIn interviews, ask specifically how the team handles situations where analysis suggests a decision needs to change. The answer reveals whether your depth will be treated as an asset or a drag."}	\N
ed2dec1e-24b4-428f-8478-26401bc22d08	2026-07-01 18:45:29.978817+00	WHAT-WHY	Senior / Executive (12+ years)	Management	Utilities	High-growth / Startup	autonomy	Primary consideration	DiSC: Di | StrengthsFinder: Empathy, Intellection, Woo, Learner, Strategic	{"roles": [{"fit": "Utilities is undergoing its most significant transformation in a century, and the companies winning are the ones that can identify the right partnerships, enter new markets, and move before competitors recognize the opportunity. That is precisely where your WHAT-WHY orientation becomes a structural advantage: you are wired to see a compelling destination and mobilize people around it before the path is fully mapped.\\n\\nAt the executive level in a high-growth utilities environment, this role rewards the profile that can hold a clear goal, build external relationships with conviction, and make fast decisions under ambiguity. Your StrengthsFinder Woo and Empathy themes mean you build trust quickly and read the room accurately, giving your WHAT-WHY drive a relational intelligence that makes you unusually effective in high-stakes partnership conversations.", "title": "Vice President of Business Development", "energizing": [{"body": "Identifying and closing transformational partnerships energizes your primary WHAT orientation. The goal is clear, the stakes are real, and momentum is yours to create.", "label": "Pursuing high-value partnership deals"}, {"body": "Entering an underdeveloped market segment in energy transition or distributed infrastructure plays directly to your WHY secondary, which thrives when the destination is meaningful.", "label": "Opening new market opportunities"}, {"body": "Constructing a team, a playbook, and a pipeline from near-zero gives you the full mobilizing arc your profile is built for at executive scale.", "label": "Building the business development function"}, {"body": "Your Woo and Empathy themes amplify the WHAT-WHY profile's natural conviction in external settings, making you a compelling face of the organization.", "label": "Representing the organization externally"}], "strategies": [{"body": "The person who builds your CRM architecture, stage-gate discipline, and diligence checklists is not a nice-to-have. Scope this role before you fill any other position.", "label": "Hire a HOW-primary Director of BD Operations on day one"}, {"body": "Your Intellection StrengthsFinder theme gives you more strategic depth than a typical WHAT-WHY. Use it to build a small set of leading indicators you can track without drowning in granular metrics.", "label": "Define three milestone markers that signal deal health"}, {"body": "You read counterpart dynamics unusually well. Deliberately slow down in the final stages of high-stakes negotiations to use that read before your WHAT drive pushes to close.", "label": "Use your Empathy theme as a negotiation asset"}, {"body": "Make it their agenda, not yours. This is the structural signal that process health is as valued as deal volume.", "label": "Establish a standing monthly check-in with your most HOW-oriented direct report"}], "challenging": [{"body": "Your HOW tertiary means the operational scaffolding behind a deal pipeline, structured tracking, stage gates, and systematic follow-through, will not build itself. You will need to hire or partner for this explicitly.", "label": "Designing repeatable BD processes"}, {"body": "Late-stage deal mechanics require the precision your profile finds draining. Without a strong HOW-oriented counterpart in the room, this is where deals develop silent gaps.", "label": "Sustained attention to contract and diligence detail"}, {"body": "At this level, HOW-oriented team members may experience your milestone-to-milestone navigation as leaving connective tissue undone. That friction is structural, not a motivation problem.", "label": "Managing a team with diverse execution styles"}]}, {"fit": "The CCO role in a high-growth utilities company, particularly one navigating energy transition, sits at the intersection of commercial strategy and organizational mobilization. You are responsible for building the revenue architecture and the team culture that executes against it. That dual demand, direction-setting and people-rallying, is where the WHAT-WHY profile operates with the least friction and the most leverage.\\n\\nAt this compensation level and seniority, the role also rewards the executive who can make consequential bets quickly. Your Strategic StrengthsFinder theme complements your WHY secondary to give you a sharper pattern-recognition capability than a pure WHAT-WHY, making the directional calls you will face in an evolving utilities market more grounded than instinct alone.", "title": "Chief Commercial Officer", "energizing": [{"body": "Setting the revenue direction for the organization is the clearest expression of your primary WHAT combined with your WHY's need for a destination that matters.", "label": "Owning the full commercial strategy"}, {"body": "Recruiting, energizing, and leading a sales and business development organization is the management expression your profile is structurally built for at this level.", "label": "Building a high-performing commercial team"}, {"body": "High-stakes, fast-moving commercial decisions with visible organizational impact energize your primary orientation. These are the moments your profile is designed for.", "label": "Leading pricing and go-to-market decisions"}, {"body": "Your Woo and Empathy themes make you a compelling internal advocate. Translating commercial reality into language that moves the executive team is a natural expression of both.", "label": "Representing commercial priorities in the C-suite"}], "strategies": [{"body": "The VP of Revenue Operations or Sales Operations role is your most critical hire. This person builds the execution architecture your WHAT-WHY naturally skips over.", "label": "Structure your direct reports to include a strong HOW-primary VP"}, {"body": "Your Strategic StrengthsFinder theme means you can identify a leading indicator that matters. One number you own keeps you from drowning in dashboards while staying genuinely accountable.", "label": "Define your personal metric: one number that tells you the commercial engine is healthy"}, {"body": "The Learner theme in your StrengthsFinder profile gives your WHAT-WHY profile an unusual appetite for mastery. Channel it into utility market structure, regulatory dynamics, and energy transition economics before your first 90 days are complete.", "label": "Use your Learner theme to build utilities-specific market depth"}, {"body": "Your natural pace will create tension with HOW-primary peers. An explicit decision-rights agreement reduces the friction before it becomes political.", "label": "Set a clear decision-rights framework with your C-suite peers in the first 60 days"}], "challenging": [{"body": "The systems, forecasting models, and operational cadences that make a commercial function reliable are HOW-primary work. Without a strong VP of Revenue Operations, this will be your most persistent gap.", "label": "Revenue operations infrastructure"}, {"body": "Granular revenue reconciliation and detailed financial modeling in board decks require sustained HOW engagement. Partner with finance to own this layer rather than attempting to build it yourself.", "label": "Board-level financial reporting"}, {"body": "Your profile is energized by forward momentum. Sustained performance management conversations that require process, documentation, and patience drain the WHAT-WHY at this level disproportionately.", "label": "Managing underperforming team members over time"}]}, {"fit": "In a high-growth utilities environment, VP of Operations is rarely a pure HOW role. It is a transformation leadership role: standing up new processes, building teams that didn't exist, and driving the operational changes that make a scaling energy company actually function. The parts of this role that involve mobilizing people, setting operational direction, and leading through ambiguity are genuine fits for your WHAT-WHY profile.\\n\\nThe honest watch-for at this level is that the role's core accountability, operational precision and system reliability, is HOW-primary work. You can lead this function effectively if you build a strong HOW-oriented leadership team beneath you, but the gap between your natural mode and the role's deepest demands is real and should be treated as a structural design challenge from day one.", "title": "Vice President of Operations", "energizing": [{"body": "Transforming an underperforming function, building new capability from the ground up, and creating visible operational momentum energize your primary orientation in ways steady-state management does not.", "label": "Leading operational transformation initiatives"}, {"body": "The team-building dimension of this role is where your Woo and Empathy themes combine with your WHAT-WHY profile to make you an unusually effective people leader.", "label": "Building and developing the operations leadership team"}, {"body": "When the organization needs a function that moves fast and brings other departments with it, your WHAT-WHY mobilizing capability is a direct organizational asset.", "label": "Driving cross-functional alignment on operational priorities"}], "strategies": [{"body": "Make this a pre-condition of your acceptance if possible. You need operational depth directly beneath you on day one, not six months in.", "label": "Hire a HOW-primary Director of Operations before accepting the role"}, {"body": "In your first 90 days, anchor your leadership narrative around what you are building and changing. This positions you correctly and sets expectations that align with your profile's natural contribution.", "label": "Frame your leadership value explicitly as transformation, not steady-state oversight"}, {"body": "The rhythm keeps you connected to operational health. Delegating the preparation keeps HOW-primary work owned by HOW-primary people.", "label": "Build a quarterly operational review cadence and delegate the meeting preparation"}], "challenging": [{"body": "SOPs, workflow documentation, and system architecture are the core deliverables of an ops function, and they are HOW-primary work. Delegate ownership of these artifacts explicitly and early.", "label": "Owning granular operational process design"}, {"body": "Utilities operate in heavily regulated environments. Compliance infrastructure requires sustained precision that your tertiary HOW finds draining. A dedicated compliance lead is a structural requirement, not a budget question.", "label": "Regulatory compliance and audit-readiness"}, {"body": "Once the change is made and momentum shifts to steady-state management, the role demands the HOW-orientation work your profile finds least energizing. This is the point where role transitions often serve WHAT-WHY leaders well.", "label": "Sustaining operational discipline after the transformation phase"}]}, {"fit": "A General Manager role in a high-growth utilities company, particularly one standing up a new business unit, regional operation, or emerging energy product line, is among the highest-fit environments for a senior WHAT-WHY leader. You own the P&L, the team, the commercial relationships, and the operational performance of a defined business. The combination of autonomy, accountability, and the requirement to mobilize an organization around a clear goal is exactly where your profile operates at its best.\\n\\nYour Strategic and Learner StrengthsFinder themes give you more analytical depth than most WHAT-WHY leaders, making you better equipped to hold your own in the numbers conversations that come with full P&L ownership. The critical design question is how you staff and structure your direct leadership team to cover execution complexity.", "title": "General Manager", "energizing": [{"body": "Owning outcomes, not just activities, is the highest expression of your primary WHAT orientation. The accountability and autonomy of a GM role are structurally energizing.", "label": "Full P&L and organizational ownership"}, {"body": "Greenfield organizational builds, distributed energy, grid services, renewable integration, play directly to your WHY secondary's need for a destination that matters beyond revenue alone.", "label": "Building a new business unit in an emerging segment"}, {"body": "The organizational mobilization required in a high-growth environment is the management expression your WHAT-WHY profile is built for.", "label": "Leading a multi-functional team through rapid scaling"}, {"body": "Your Woo, Empathy, and WHAT-WHY conviction make you a compelling external voice for the business with partners, regulators, and customers alike.", "label": "Representing the business to external stakeholders"}], "strategies": [{"body": "You need at least one strong HOW-primary leader in your direct reports. This is the most consequential hiring decision you will make, and it should be your first.", "label": "Design your leadership team as a cognitive complement, not a mirror"}, {"body": "Your WHY secondary means you need a compelling destination before your energy fully ignites. Articulating a clear 12-month ambition statement also aligns your team and sets the accountability frame.", "label": "Define what winning looks like for your business unit in the first 30 days"}, {"body": "A GM with genuine intellectual depth on where the utilities market is heading commands more internal credibility and external authority than one leading on momentum alone.", "label": "Use your Intellection and Strategic themes to build a point of view on energy transition"}, {"body": "The review keeps you accountable. The delegation keeps HOW work owned by the right person.", "label": "Build a structured quarterly business review and delegate its preparation to your HOW-primary direct report"}], "challenging": [{"body": "Processes, systems, and documentation that make the business reliable rather than just fast are HOW-primary work. Staff for this explicitly in your leadership team design.", "label": "Building the operational infrastructure of the business unit"}, {"body": "P&L ownership requires more HOW engagement than your profile finds energizing. A strong finance business partner embedded in your team is a structural requirement.", "label": "Granular financial modeling and budget management"}, {"body": "Utilities regulatory environments reward patience, documentation, and process precision, all HOW-primary demands that will drain your energy if you attempt to own them personally.", "label": "Navigating regulatory and compliance complexity"}]}, {"fit": "Energy transition is the defining strategic priority in utilities right now, and organizations are creating senior roles to lead it that did not exist five years ago. A Managing Director of Energy Transition is responsible for setting the direction, building the team, and driving the organizational change required to move a legacy utilities company into new business models, distributed energy, electrification, and grid modernization. This is transformation leadership, and transformation leadership is the highest-fit category of work for a WHAT-WHY executive.\\n\\nYour WHY secondary is particularly valuable here: this is a role where the why, decarbonization, energy security, long-term resilience, is both real and genuinely motivating. Your ability to connect commercial urgency to a purpose that matters gives you a leadership quality in this space that purely commercially-driven executives cannot replicate.", "title": "Managing Director, Energy Transition", "energizing": [{"body": "Defining what the company's energy transition ambition is and what it demands energizes both your primary WHAT and your WHY secondary simultaneously.", "label": "Setting the organizational vision for energy transition"}, {"body": "Mobilizing engineering, commercial, regulatory, and operations functions around a shared transformation agenda is the organizational challenge your profile is built to lead.", "label": "Leading cross-functional transformation teams"}, {"body": "Your Woo and Empathy themes make you unusually effective in the relationship-intensive ecosystem of energy transition: developers, OEMs, regulators, and financiers all require different registers.", "label": "Building external partnerships with technology providers and developers"}, {"body": "High-stakes narrative work, where you must make a complex transformation feel inevitable and urgent, is the clearest expression of your WHAT-WHY profile at executive level.", "label": "Representing energy transition strategy to the board and investors"}], "strategies": [{"body": "The transformation governance architecture, milestones, dependencies, reporting cadences, must be owned by someone whose primary orientation is HOW. This is your most important structural hire.", "label": "Hire a HOW-primary VP of Program Delivery before standing up your function"}, {"body": "Your Intellection and Strategic themes give you the depth to build a point of view that is both intellectually rigorous and organizationally galvanizing. This document becomes the alignment tool for every internal and external conversation.", "label": "Build a compelling energy transition narrative in the first 60 days"}, {"body": "You do not need to be the technical expert, but specific depth in battery storage economics, grid interconnection, or electrification load modeling will give you authority in rooms where your commercial profile alone would not.", "label": "Use your Learner theme to build genuine technical fluency in two or three key areas"}, {"body": "In transformation roles, decision ownership is chronically ambiguous. A clear map prevents the organizational friction that slows the WHAT-WHY leader's preferred pace.", "label": "Create an explicit decision-rights map for technical versus commercial versus strategic decisions"}], "challenging": [{"body": "Deep engineering and financial precision work is HOW-primary. You need technical advisors or a HOW-primary VP of Technology on your leadership team for this layer.", "label": "Technical due diligence on energy assets and technologies"}, {"body": "The tracking, reporting, and governance cadences that keep multi-year programs accountable are HOW-primary work. Without a strong program director, these become invisible gaps.", "label": "Program governance across multi-year transformation initiatives"}, {"body": "HOW-primary colleagues who have built the current operational systems will resist change that disrupts them. This friction is structural and requires more patience and process than your WHAT-WHY profile finds natural.", "label": "Managing organizational resistance to transformation"}]}, {"fit": "In a high-growth utilities context, VP of Customer Experience is increasingly a commercial and transformation role, not a service delivery role. You are responsible for defining the customer strategy, building the capabilities that deliver it, and driving the organizational change required to move a traditionally product-centric utility toward a customer-centric model. The transformational dimension of this role is a genuine fit for your WHAT-WHY profile at this level.\\n\\nYour Empathy and Woo StrengthsFinder themes are directly relevant here in a way that amplifies your WHAT-WHY profile: you are wired to read what customers and teams actually need, and your primary WHAT orientation gives you the drive to do something about it. At the executive level, this combination makes you a more credible customer advocate than most leaders who hold this title.", "title": "Vice President of Customer Experience", "energizing": [{"body": "Setting the customer experience vision and making the case for it organizationally is where your WHAT-WHY profile, combined with your Empathy and Strategic themes, operates with the most clarity and energy.", "label": "Defining the customer strategy for a transforming utility"}, {"body": "Mobilizing a traditionally engineering-first organization around the customer is a WHAT-WHY transformation leadership challenge. Few leaders are better suited to it.", "label": "Leading organizational culture change toward customer-centricity"}, {"body": "Recruiting and developing a high-performing CX team in a high-growth environment gives your profile the people-building challenge it finds most energizing at the executive level.", "label": "Building and leading a customer experience leadership team"}], "strategies": [{"body": "The moment you inherit the service queue rather than leading the strategy, the role inverts. Establish your transformation mandate in your first 30 days, including what you own and what you delegate.", "label": "Frame your role explicitly as CX transformation, not service management"}, {"body": "Your Strategic theme means you will use good customer data well. The key is not drowning in its collection and maintenance. Structure the data infrastructure to be owned and maintained by HOW-oriented team members.", "label": "Build a customer insights loop that your HOW-primary team owns and you consume"}, {"body": "In a utility, the most important customer experience decisions are often made by engineers and operations leaders who don't think in customer terms. Your ability to read and meet those stakeholders where they are is how you move the organization.", "label": "Use your Empathy theme as an internal influence tool, not just an external one"}], "challenging": [{"body": "The systems and data architecture that make customer insights reliable are HOW-primary work. A VP or Director of CX Operations with a strong HOW orientation is a structural requirement for this function.", "label": "CRM and operational data infrastructure"}, {"body": "Operational service infrastructure is granular, repetitive, and precision-oriented, all HOW-primary characteristics. Without a HOW partner owning this layer, it becomes your energy drain.", "label": "Sustained attention to complaint resolution processes and service recovery workflows"}, {"body": "Utilities are held to specific customer protection standards. The documentation, compliance tracking, and audit-readiness this demands is HOW-primary work that your profile finds draining.", "label": "Regulatory customer protection requirements"}]}], "nextSteps": ["Before your next executive conversation or interview, write two sentences on why the specific energy transition challenge this organization is trying to solve matters. If you cannot write them with conviction, that is useful data before you accept the role.", "Map your ideal direct report team on paper: identify the specific HOW-primary role you would hire first, what that person owns, and what you would keep. Bring this to any serious offer conversation as a signal of how you lead.", "Use your Learner theme deliberately: identify one technical domain in utilities, grid interconnection, battery storage economics, or distributed energy regulation, and build genuine fluency in it over the next 90 days. Depth in one area gives your WHAT-WHY leadership style technical credibility it otherwise has to earn over time.", "When evaluating offers, weight organizational mandate over company brand. A well-funded startup with a genuine transformation problem to solve will develop your profile faster and pay you more than a prestigious institution asking you to manage a steady-state function."], "watchFors": ["Handing off execution before the operational infrastructure is in place", "Moving milestone to milestone while process gaps accumulate beneath", "Underestimating how much HOW-orientation work the role demands at scale", "Trusting momentum as a substitute for structural accountability"], "energizers": ["Rallying a team around a high-stakes, purpose-driven mission", "Setting bold direction in markets that reward speed", "Building and leading teams from the ground up", "Translating a compelling goal into visible organizational momentum", "Winning stakeholder buy-in for transformational change"], "environmentNote": "High-growth utilities environments, particularly those scaling new energy products, entering distributed energy markets, or navigating energy transition, create the conditions where your WHAT-WHY profile is most valuable and most tested simultaneously. The pace is right, the mission gives your WHY secondary something real to engage with, and the organizational complexity rewards leaders who can mobilize people under ambiguity. The watch-for in this environment is that high-growth organizations often lack the HOW-primary infrastructure that makes your momentum sustainable. Before evaluating an offer, ask directly: who owns process design, operational governance, and execution architecture? If the answer is unclear, that gap will fall to you.\\n\\nFor compensation as your primary priority, the highest-earning expressions of your profile in utilities are the commercial and P&L-ownership roles, CCO, GM, and Managing Director, where your mobilizing capability translates directly into revenue outcomes that justify executive compensation. Seek equity participation wherever possible: your WHAT-WHY profile performs best when the destination is something you are building, not just managing."}	\N
527bb2c0-65f9-41f2-b4e6-16d1aa9074c1	2026-07-01 18:53:22.12595+00	WHY-HOW	Mid Career (5–12 years)	Individual Contributor	Tech	Established company	work-life balance	Primary consideration	DiSC: CS | StrengthsFinder: Activator, Competition, Discipline, Input, Woo	{"roles": [{"fit": "Staff-level data science in an established tech company is structurally designed for the way you work. The role rewards depth over speed, values people who can frame the problem before solving it, and gives you enough organizational tenure to pursue questions that matter rather than just questions that are urgent. You are not expected to move fast and break things — you are expected to be right.\\n\\nAt this level, your WHY orientation becomes a differentiator. Most data scientists optimize models; you question whether the model is answering the right question. That instinct, paired with HOW-driven rigor, produces the kind of work that changes how a product team or business unit thinks.", "title": "Staff Data Scientist", "fitLabel": "Great Fit", "fitScore": 95, "energizing": [{"body": "Deciding what to measure and why is pure primary-orientation work. You will find yourself most alive in the ambiguous early phase where the question itself is still negotiable.", "label": "Framing the research question"}, {"body": "When no existing model fits, you construct the right one. HOW-driven rigor means your frameworks hold up under scrutiny in ways that speed-built analyses don't.", "label": "Building analytical frameworks from first principles"}, {"body": "Your WHY instinct surfaces the premise everyone accepted without testing. This is genuinely valuable at Staff level, where you have the standing to act on it.", "label": "Identifying flawed assumptions in existing systems"}, {"body": "Problems that take months to properly understand are not frustrating — they are the point. Established tech companies have exactly these problems.", "label": "Long-horizon research with organizational significance"}], "strategies": [{"body": "At project kickoff, agree with your manager on what a shippable output looks like. This gives you a concrete target rather than an internal standard that keeps moving.", "label": "Define 'done enough' before you start"}, {"body": "Find one person who is energized by driving findings into decisions. That relationship is your deployment mechanism — invest in it deliberately.", "label": "Partner with a WHAT-oriented PM or research lead"}, {"body": "Write the full analysis for yourself, then write a separate executive summary for every key stakeholder. Treat translation as a structural step, not an afterthought.", "label": "Build a translation habit for your written outputs"}, {"body": "Proactively surface the questions that matter to the business before they surface to you. Staff-level influence comes from shaping what gets studied, not just answering what gets asked.", "label": "Use your WHY instinct to set research agenda, not just validate it"}], "challenging": [{"body": "Established companies have release cycles, stakeholder timelines, and roadmap deadlines. The work will need to ship before your internal sense of completeness arrives.", "label": "Shipping before it feels complete"}, {"body": "Your thinking will outpace your audience's context. Translating deep analysis into a three-slide summary is a real cost, not a trivial formatting task.", "label": "Communicating findings to non-technical stakeholders"}, {"body": "Producing the insight is not the same as getting it adopted. Moving findings through product, engineering, and leadership requires WHAT-orientation energy you will need to cover structurally.", "label": "Generating organizational momentum around your findings"}]}, {"fit": "At the Principal level in an established tech company, product management shifts from execution velocity to strategic clarity. You are not running sprints — you are deciding what problems are worth solving and building the case for why. That framing is your natural operating mode. The WHY-HOW profile produces the kind of product thinking that is rarest in the field: a person who interrogates the problem deeply enough to know whether the proposed solution is answering the right question.\\n\\nEstablished companies with DiSC CS profiles tend to reward exactly this — thorough, credible thinking over charismatic advocacy. Your StrengthsFinder Input theme amplifies the depth of your research; Discipline keeps you from letting that research sprawl without producing output.", "title": "Principal Product Manager", "fitLabel": "Strong Fit", "fitScore": 89, "energizing": [{"body": "This is the phase most PMs rush through. You are energized by it, which produces better product decisions than speed-optimized alternatives.", "label": "Defining the problem space before solution design begins"}, {"body": "Connecting market insight, user research, and business logic into a coherent argument is a genuine strength area — primary orientation doing real work.", "label": "Building the strategic rationale for a product bet"}, {"body": "Your Input theme and HOW precision combine here. You will gather and organize more signal than most PMs, and produce frameworks that actually hold.", "label": "Deep user and market research synthesis"}, {"body": "When engineering, design, and business goals are in genuine tension, your systems thinking finds paths that simpler thinkers miss.", "label": "Working through complex cross-functional constraints"}], "strategies": [{"body": "Find a technical counterpart who is energized by driving execution. You set the problem and the standard; they drive the team toward the milestone.", "label": "Pair with a WHAT-HOW engineering manager or TPM"}, {"body": "Create a repeatable structure: three weeks of deep research, one week of synthesis, a defined decision date. Your Discipline theme will maintain it; the structure prevents open-ended refinement.", "label": "Establish a personal research-to-decision protocol"}, {"body": "Woo gives you more relational range than a typical CS profile. Use it to get early stakeholder buy-in, then lead with analytical rigor to convert initial interest into real commitment.", "label": "Let your Woo theme open doors, then let your depth close them"}, {"body": "Negotiate with your manager to concentrate your time on pre-roadmap work. This is where your profile creates the most value and incurs the least energy cost.", "label": "Scope your role toward discovery and strategy, not delivery"}], "challenging": [{"body": "Principal PMs are expected to create organizational momentum. This is WHAT-orientation work, and it will cost you energy at a rate the role does not fully acknowledge.", "label": "Driving cross-functional teams toward decisions under ambiguity"}, {"body": "Roadmaps are commitments made under uncertainty. The drive to understand fully before committing will create friction with stakeholders who need dates.", "label": "Committing to a roadmap before the picture feels complete"}, {"body": "At Principal level, a significant portion of the work is relational and political. CS DiSC preference for depth over breadth means this energy cost is real.", "label": "High-volume stakeholder communication and alignment work"}]}, {"fit": "Senior UX Research in established tech is one of the cleanest structural matches for a WHY-HOW mid-career individual contributor. The role is built on a single premise: before we build, we need to understand. That is your operating thesis. You are energized by the phase between sensing something is wrong and knowing what to do about it — which is precisely the phase a UX researcher owns.\\n\\nAt mid-career in an established company, you are expected to lead research initiatives, not just execute studies. That means shaping the questions, not just answering them. Your Activator theme accelerates you past the planning-paralysis risk that sometimes appears in this profile; your Input theme ensures the synthesis is thorough.", "title": "UX Researcher", "fitLabel": "Strong Fit", "fitScore": 86, "energizing": [{"body": "This is the highest-value, most energizing phase of UX work. You are mapping unknown territory, which is exactly where your WHY-HOW orientation produces exceptional output.", "label": "Generative research into problems the product team hasn't named yet"}, {"body": "Taking raw observation and constructing a model that explains user behavior is HOW-driven work at its best. Your Input theme means you have more raw material to work with.", "label": "Synthesizing research into insight frameworks"}, {"body": "When research contradicts what the team assumed, you are the person who says so clearly. This is a WHY instinct with HOW backing — unusually credible.", "label": "Challenging product assumptions with evidence"}, {"body": "You will reframe the research brief before accepting it. In established companies with mature research practices, this is respected, not resisted.", "label": "Designing research that answers the question that matters, not the question asked"}], "strategies": [{"body": "Find a PM or design lead who is energized by driving insights into decisions. You produce the intelligence; they create the organizational momentum.", "label": "Establish a research advocacy partner in product or design"}, {"body": "Write the full report for yourself and deep stakeholders. Build a separate one-page summary for every deliverable. Treat these as two different work products, not one abbreviated.", "label": "Create a tiered output format for every study"}, {"body": "Set hard deadlines for each research phase before you start. Your Activator theme will get you moving; Discipline will keep you from over-refining before synthesis.", "label": "Use your Discipline theme to timebox research phases"}, {"body": "Proactively bring research questions to product leadership before projects are scoped. This is where your WHY orientation creates the most leverage.", "label": "Position yourself as the team's question-setter, not just question-answerer"}], "challenging": [{"body": "Research influence without authority is momentum work. Getting findings adopted by skeptical PMs or executives requires WHAT-orientation energy that drains you.", "label": "Driving product teams to act on findings"}, {"body": "Agile product environments will push for faster, lighter research. Moving before the picture feels complete is a structural friction point, not a preference.", "label": "Compressing research timelines to match sprint cycles"}, {"body": "Your synthesis will be thorough. The audience will want three bullets. That translation gap is real and recurring in this role.", "label": "Making findings accessible to low-context stakeholders"}]}, {"fit": "Senior data analysis in established tech is a strong structural match for a WHY-HOW mid-career IC, with one important caveat: the role's ceiling matters significantly. In companies where analysts are embedded in product or strategy functions and expected to shape decisions — not just answer them — this profile thrives. In organizations where analysis means pulling dashboards and answering ticket-based requests, the WHY orientation will go underused and the role will feel small.\\n\\nYour HOW precision produces analysis that holds up. Your WHY instinct ensures you question whether the metric being measured actually reflects the thing that matters. That combination is rare and valuable in data-mature tech companies.", "title": "Data Analyst", "fitLabel": "Good Fit", "fitScore": 82, "energizing": [{"body": "When a number looks wrong and no one knows why, you are energized. This is WHY plus HOW at full strength — investigating until the system reveals itself.", "label": "Root cause analysis on metrics that don't make sense"}, {"body": "Constructing a model that actually fits the data, rather than a model that is expedient, is HOW-driven work that produces genuine satisfaction.", "label": "Building analytical models that explain complex behavior"}, {"body": "Most analysts accept the metric as given. You ask whether it captures what the team believes it captures. This is your most distinctive contribution.", "label": "Questioning what a metric is actually measuring"}], "strategies": [{"body": "The functional home of your analyst role determines whether WHY orientation is an asset. Strategy-embedded roles give you the problem-framing mandate your profile needs.", "label": "Seek roles embedded in strategy or product, not BI or reporting teams"}, {"body": "Every analysis should end with a clear 'therefore' — one recommendation, framed as a decision the stakeholder can make. This is structurally uncomfortable but organizationally essential.", "label": "Build a pattern for translating findings into decisions"}, {"body": "You are energized by producing the best analysis in the room. In data-mature tech companies, that standard is visible and respected.", "label": "Use your Competition StrengthsFinder theme to set a quality bar others benchmark against"}], "challenging": [{"body": "Ticket-based work that requires speed and breadth rather than depth and rigor will drain you quickly. Environment selection matters significantly here.", "label": "High-volume, low-depth analytical requests"}, {"body": "Your HOW instinct will resist overstating confidence. Translating honest analytical uncertainty into actionable recommendations is a recurring tension.", "label": "Communicating uncertainty to stakeholders who want certainty"}, {"body": "Producing the correct analysis is not the same as getting the organization to change behavior based on it. The latter requires WHAT energy you will need to source externally.", "label": "Driving organizational action on your findings"}]}, {"fit": "Technical Program Management is a conditional fit for a WHY-HOW mid-career IC — conditional on the scope and nature of the role. In established tech companies, senior TPMs who own complex, multi-year infrastructure or platform programs are doing something genuinely different from execution coordinators: they are building the architecture of how large technical work gets done. That problem-design and systems-thinking layer is where your profile produces real value.\\n\\nThe risk is clear: program management has a significant WHAT orientation demand. Driving cross-functional teams, managing stakeholder cadences, and maintaining forward momentum are core to the role. Your Discipline StrengthsFinder theme partially offsets this, but it does not eliminate the energy cost.", "title": "Technical Program Manager", "fitLabel": "Good Fit", "fitScore": 77, "energizing": [{"body": "Mapping dependencies, sequencing work streams, and building the structural logic of a complex program is HOW-driven systems thinking at scale.", "label": "Designing the program architecture before execution begins"}, {"body": "Your pattern-recognition across technical and organizational systems surfaces problems that milestone-focused PMs miss. This is genuinely valuable in large programs.", "label": "Identifying systemic risks before they become blockers"}, {"body": "Creating structures that prevent the same class of problem from recurring is HOW-orientation at its most satisfying.", "label": "Building program frameworks that encode institutional learning"}], "strategies": [{"body": "Push for a role definition where your deliverable is the program structure and risk model, with a project coordinator or APM handling the coordination overhead.", "label": "Negotiate scope toward program design and risk architecture, away from coordination"}, {"body": "Design the update cadence, the status format, and the escalation protocol once — then let the system run. Systems are energizing; maintaining them is not.", "label": "Use your Discipline theme to build coordination systems rather than doing coordination"}, {"body": "The team momentum you find draining is energizing for a WHAT partner. Structure this as a formal working relationship, not an informal ask.", "label": "Find a WHAT-oriented technical lead or delivery manager as a standing partner"}], "challenging": [{"body": "TPM influence is almost entirely through relationship and energy, not authority. Sustained momentum-creation will drain you in a way the role's core demands do not acknowledge.", "label": "Driving organizational momentum across teams you don't control"}, {"body": "Your HOW instinct will resist oversimplification of complex program realities. Executive audiences want signal, not system maps.", "label": "Communicating program status to executives in simplified terms"}, {"body": "Status updates, alignment meetings, and stakeholder check-ins are structurally draining for this profile and are unavoidable at scale.", "label": "Managing the coordination overhead of large multi-team programs"}]}, {"fit": "Solutions Architecture in an established tech company is a genuine fit for a WHY-HOW IC, with a specific version of the role in mind: the strategic pre-sales or enterprise architecture track, not the implementation-delivery track. When the core work is understanding a customer's technical environment deeply, diagnosing what is actually wrong, and designing a solution architecture that holds — that is your operating mode.\\n\\nThe challenge is that Solutions Architecture has a meaningful client-facing, relationship-management, and momentum-driving layer. Your Woo StrengthsFinder theme gives you more range here than a typical WHY-HOW profile, but the sustained WHAT demands of pipeline management and customer success tracking will cost energy over time.", "title": "Solutions Architect", "fitLabel": "Good Fit", "fitScore": 74, "energizing": [{"body": "Understanding a customer's architecture well enough to see what they cannot see themselves is WHY-HOW work at full strength.", "label": "Deep technical discovery on complex customer environments"}, {"body": "Your WHY instinct reframes the brief. In enterprise architecture, the difference between the stated problem and the actual problem is often significant.", "label": "Designing architectures that solve the real problem, not the stated one"}, {"body": "Translating architectural thinking into a rigorous technical rationale combines your HOW precision with your WHY clarity in a way that is genuinely energizing.", "label": "Building the technical case for a solution"}], "strategies": [{"body": "In established tech companies, the best SA roles pair a technical architect with a commercial owner. You own the solution design; they own the deal momentum.", "label": "Target roles with a dedicated sales or customer success partner"}, {"body": "Woo gets you into the room; HOW rigor keeps you there. This sequence is more effective than leading with technical depth to stakeholders who haven't yet trusted you.", "label": "Use your Woo theme to establish early customer rapport, then let your depth build credibility"}, {"body": "Long-cycle, high-complexity accounts reward your depth. High-volume, transactional environments will optimize you out of your natural mode.", "label": "Seek enterprise or platform architecture tracks over transactional sales engineering"}], "challenging": [{"body": "The commercial layer of a solutions role — maintaining deal momentum, managing follow-ups, coordinating across accounts — is WHAT-orientation work that will drain you steadily.", "label": "Pipeline management and sales cycle coordination"}, {"body": "Customer stakeholders range from CTO to procurement. Calibrating depth and detail in real time across that range is demanding for a CS DiSC profile.", "label": "Adapting communication depth to technically varied audiences"}]}], "nextSteps": ["For your next role conversation or application, identify specifically whether the role's core output is insight and design, or execution and coordination — your profile creates maximum value in the former and will be consistently drained by the latter.", "Map your current or target team for a WHAT-oriented counterpart: someone energized by driving decisions into action. If that person doesn't exist in your immediate team, identify them one level out and invest in that relationship before you need it.", "Before evaluating any offer, ask a specific question in the interview: 'How does this team typically move from a completed analysis or recommendation to an organizational decision?' The answer will tell you whether your work will have impact or sit in a folder.", "Given your Competition StrengthsFinder theme, identify the quality benchmark in your target field — the analyst, researcher, or architect whose work sets the standard — and use it as a concrete calibration point for your own output goals."], "watchFors": ["Refining past the point where shipping would create more value", "Momentum gaps when no WHAT partner is in place", "Communication density that outpaces the audience's context", "Undervaluing work that isn't yet complete"], "energizers": ["Diagnosing complex systems no one has fully mapped", "Building frameworks that explain why something keeps failing", "Deep research with real organizational stakes", "Connecting architectural thinking to strategic direction", "Producing work precise enough to be definitively right"], "environmentNote": "Established tech companies are a genuine structural fit for your profile. They have the stability to let deep work develop over months, the organizational maturity to value rigor over speed, and the role specialization to let you stay in your primary orientation without being pulled into coordination overhead. The risk in these environments is bureaucratic drag — layers of process that slow down the deployment of your work without improving it. Watch for roles where the stakeholder approval chain is so long that your output loses relevance before it reaches a decision.\\n\\nGiven your values around work-life balance, established companies are the right call. The always-on pressure of high-growth environments would conflict directly with the recovery time your WHY-HOW profile needs after sustained deep work. Sustainable output for this profile requires protected time — and established companies are more likely to structurally provide it than to demand perpetual urgency."}	\N
768bb94b-cf99-4203-9774-9f7568cdb366	2026-07-01 18:53:52.564111+00	WHY-HOW	Mid Career (5–12 years)	Individual Contributor	Tech	Established company	work-life balance	Primary consideration	DiSC: CS | StrengthsFinder: Activator, Competition, Discipline, Input, Woo	{"roles": [{"fit": "At the staff level, data science in an established tech company rewards exactly what you are wired for: deep, original thinking about hard problems where surface-level analysis produces wrong answers. The role demands that you understand the system before you touch it, and the output is only as good as the rigor behind it.\\n\\nWith your CS DiSC profile and Discipline and Input StrengthsFinder themes reinforcing your WHY-HOW orientation, you will find established company structures give you the institutional resources and data infrastructure to pursue problems at the depth they deserve, without startup chaos constantly interrupting deep work.", "title": "Staff Data Scientist", "fitLabel": "Great Fit", "fitScore": 95, "energizing": [{"body": "When a model is underperforming or a metric is behaving unexpectedly, you are energized by tracing it back to the actual cause — not the proximate one.", "label": "Root Cause Analysis on Hard Problems"}, {"body": "Building the methodology that others will use to answer a category of questions draws directly on your HOW orientation and your Discipline theme.", "label": "Designing Rigorous Analytical Frameworks"}, {"body": "You will light up when an analysis reframes the business question itself — when the finding changes what the organization is asking, not just how it answers.", "label": "Connecting Data Findings to Strategic Questions"}, {"body": "Your Input theme combines with WHY-HOW's love of comprehensive understanding — synthesizing research across domains to ground your work is genuinely energizing, not overhead.", "label": "Deep Literature and Domain Synthesis"}], "strategies": [{"body": "Find the product manager or engineering lead who will own shipping your work. Make that relationship explicit — their momentum orientation is what gets your analysis into production.", "label": "Identify Your Deployment Partner Early"}, {"body": "Define what 80% confidence looks like for each project before you begin. This is a structural constraint, not a compromise — it protects your time and your work-life balance.", "label": "Set a 'Complete Enough' Threshold Before You Start"}, {"body": "Create a standing format: one paragraph for executives, the full analysis for technical peers. Writing both is faster than rewriting one, and it stops you from defaulting to depth when breadth is needed.", "label": "Build a Two-Layer Communication Template"}, {"body": "At an established company, block your three highest-focus hours each morning before the meeting culture begins. Your best work happens in uninterrupted depth — protect it structurally, not aspirationally.", "label": "Guard Deep Work Time Contractually"}], "challenging": [{"body": "Established companies have release cycles and stakeholder timelines that will not wait for the analysis to feel fully satisfying. This tension is structural, not situational.", "label": "Shipping Before It Feels Complete"}, {"body": "Your explanations will often be more thorough than your audience needs. Your Woo theme helps you connect, but your WHY-HOW wiring will still pull toward completeness over clarity.", "label": "Translating Complexity for Non-Technical Stakeholders"}, {"body": "Product reviews, roadmap meetings, and stakeholder alignment sessions will pull you from deep work regularly and drain energy that would otherwise go into the actual problem.", "label": "Cross-Functional Coordination Overhead"}]}, {"fit": "Principal PMs at established tech companies are expected to define the product direction for a major surface or capability area — not just manage delivery. That distinction matters enormously for your profile. The role rewards your WHY-HOW instinct to understand the full system before committing to a path, and at the principal level, the depth of your thinking is the product.\\n\\nYour Activator and Competition StrengthsFinder themes add a useful edge: once you have conviction on a direction, you can move with genuine urgency. The risk is the coordination tax — principal PMs carry significant cross-functional overhead that will drain you if not actively managed.", "title": "Principal Product Manager", "fitLabel": "Strong Fit", "fitScore": 88, "energizing": [{"body": "You are energized by the investigative phase — understanding user behavior, system constraints, and strategic context before any roadmap is written.", "label": "Defining the Problem Before the Solution"}, {"body": "Connecting a deeply researched product thesis to company direction draws on both your WHY and HOW orientations simultaneously — rare and genuinely energizing work.", "label": "Building the Strategic Narrative"}, {"body": "When you identify a product pattern that keeps producing bad outcomes, redesigning the underlying system — not patching the symptom — is exactly what your HOW orientation is built for.", "label": "Designing Systems That Prevent Recurring Failures"}], "strategies": [{"body": "In an established company, this resource is usually available. Structurally offloading meeting coordination and status communication protects the deep thinking time that makes you valuable at this level.", "label": "Delegate Stakeholder Coordination to a Program Manager"}, {"body": "Build explicit prioritization criteria before each planning cycle. This converts a draining judgment call into a structured process your HOW orientation will actually engage with.", "label": "Use Your Discipline Theme to Create Decision Frameworks"}, {"body": "Your instinct is to refine the strategy; find a technical partner who is energized by shipping. Their urgency and your rigor are genuinely complementary.", "label": "Partner With an Engineering Lead Who Owns Deployment Momentum"}], "challenging": [{"body": "Principal PMs influence without managing, which requires sustained rallying energy your WHAT-tertiary orientation does not naturally produce.", "label": "Driving Organizational Momentum Without Direct Authority"}, {"body": "The coordination overhead at this level is significant. Without structural protection of your deep work time, the role becomes primarily administrative.", "label": "Meeting Volume and Stakeholder Management"}, {"body": "You will be asked to make roadmap calls before you feel the picture is complete. This is a permanent feature of the role, not a temporary condition.", "label": "Prioritization Under Incomplete Information"}]}, {"fit": "UX research at an established tech company is one of the few IC roles where going deep is the job, not a deviation from it. You are paid to understand the full picture of how users think, what they actually do, and why the gap between the two exists — and to translate that into insight the organization can act on. Your WHY-HOW wiring maps directly to the investigative and synthesis phases of this work.\\n\\nYour CS DiSC profile means you will naturally build the kind of calm, trust-based research relationships that produce honest participant responses. The challenge is the output side: research that stays inside your head or inside a dense document does not reach the people who need it.", "title": "UX Researcher", "fitLabel": "Good Fit", "fitScore": 84, "energizing": [{"body": "Deciding what to measure, how to measure it, and what methodology actually answers the question is deeply energizing — this is pure WHY-HOW problem framing.", "label": "Designing Research Studies From First Principles"}, {"body": "The moment when scattered observations resolve into a coherent mental model of why users do what they do is exactly what your HOW orientation lives for.", "label": "Finding the Pattern Beneath User Behavior"}, {"body": "When your research reframes the question the team was asking, you are operating at the intersection of your WHY and HOW orientations — the highest-value output you can produce.", "label": "Challenging Product Assumptions With Evidence"}], "strategies": [{"body": "Create a reusable format that forces you to produce the three-bullet summary before you write the full report. The summary goes to the product team; the full report is available on request.", "label": "Build a Standing Research-to-Insight Translation Template"}, {"body": "Your Input theme will pull you to gather everything available. Constrain each study to one answerable question before you begin — this produces faster delivery without sacrificing rigor.", "label": "Scope Each Study to One Central Question"}, {"body": "Not all research warrants the same depth. Establish explicitly with your product partner which studies are high-stakes and deserve full rigor, and which need a faster, leaner approach.", "label": "Negotiate Timelines Based on Decision Stakes"}], "challenging": [{"body": "You will want to present the full picture; product teams need three bullets they can act on. The translation is structural work your profile finds genuinely draining.", "label": "Distilling Findings Into Actionable Recommendations"}, {"body": "Research cycles at established tech companies are often compressed to match sprint cadences. You will regularly feel pushed to share findings before they feel complete.", "label": "Pace of Delivery in Agile Environments"}]}, {"fit": "Solutions architects at established tech companies sit at the intersection of deep technical understanding and strategic client or internal problem framing — exactly the space your WHY-HOW profile is built to occupy. The role demands that you understand both the system and the purpose it is meant to serve, and that you can translate between them with precision.\\n\\nYour Discipline and Input themes mean you naturally accumulate the technical breadth this role requires and build the structured thinking that makes architectural recommendations defensible. The friction point is client-facing communication pace: the role often requires translating complex architecture into accessible terms under time pressure.", "title": "Solutions Architect", "fitLabel": "Good Fit", "fitScore": 81, "energizing": [{"body": "Understanding how all components interact — and where the architectural risks live — is the core of this role and directly energizing for your HOW orientation.", "label": "Mapping Complex Technical Systems End-to-End"}, {"body": "When a system is producing bad outcomes and nobody has properly named why, your WHY-HOW profile thrives on tracing the failure back to its structural root.", "label": "Diagnosing Why an Existing Architecture Is Failing"}, {"body": "Translating a business or product requirement into an architecture that will hold under scale draws equally on your WHY and HOW orientations.", "label": "Designing Scalable Technical Solutions From Requirements"}], "strategies": [{"body": "Document the reasoning behind every major architectural recommendation. This externalizes your thinking, protects your decisions, and gives stakeholders the depth they want on their own time.", "label": "Create Architecture Decision Records as a Default Practice"}, {"body": "At an established company, define what is in and out of scope architecturally before deep analysis begins. This limits the pull of your Input theme toward unlimited breadth.", "label": "Set Explicit Scope Boundaries Per Engagement"}, {"body": "Build a habit of preparing a one-page summary and a full technical document for every recommendation. The summary answers the immediate question; the document handles follow-up depth.", "label": "Develop a Tiered Communication Structure"}], "challenging": [{"body": "Stakeholders and clients often want the answer before you feel the analysis is complete. This is a permanent feature of client-facing technical roles.", "label": "Presenting Recommendations Under Time Pressure"}, {"body": "Solutions architects are often pulled across several engagements simultaneously. Depth across parallel tracks is genuinely harder than depth on one problem at a time.", "label": "Managing Multiple Concurrent Workstreams"}]}, {"fit": "Management consulting in the tech sector rewards the combination of strategic framing and analytical depth that your WHY-HOW profile produces. The diagnostic phases of consulting — defining the problem, mapping the system, identifying the real root cause — are genuinely energizing for you, and your Discipline theme means your work product will be structurally rigorous in a field where that matters.\\n\\nThe conditional element here is environment. This role is flagged as Good rather than Strong Fit for mid-career IC in an established company because consulting carries significant coordination overhead, client-facing communication pressure, and a pace that will compete with your natural mode. An internal strategy or research function within a large tech company is a more favorable expression of this work for your profile.", "title": "Management Consultant", "fitLabel": "Good Fit", "fitScore": 78, "energizing": [{"body": "The phase before the solution — understanding what is actually wrong and why — is where your WHY-HOW wiring produces its highest-quality output.", "label": "Problem Definition and Diagnostic Framing"}, {"body": "Structuring ambiguous client problems into a diagnostic framework that others can follow draws directly on your HOW orientation and your Discipline theme.", "label": "Building Analytical Frameworks That Organize Complex Problems"}, {"body": "Your Input theme and HOW orientation combine to produce the kind of cross-domain synthesis that creates genuine insight differentiation in consulting work.", "label": "Research Synthesis Across Industry and Technical Domains"}], "strategies": [{"body": "An internal strategy consultant or research lead role at a large tech company gives you the same analytical work with significantly less coordination overhead and a more sustainable pace.", "label": "Target Internal Strategy or Research Roles Over External Consulting"}, {"body": "Within any engagement, position yourself as the person who defines the problem and builds the analytical framework. Find a WHAT-oriented partner to own the client momentum and delivery management.", "label": "Negotiate to Own the Diagnostic and Synthesis Phases"}, {"body": "Your Competition StrengthsFinder theme responds to benchmarks. Set an explicit quality standard for each deliverable and use that standard — not a feeling of completeness — as your 'done' signal.", "label": "Use Your Competition Theme to Enforce Quality Thresholds"}], "challenging": [{"body": "Consulting requires frequent, rapid communication of incomplete thinking to clients and teams. This pace is structurally at odds with your need to understand before committing.", "label": "Client-Facing Communication Pace and Volume"}, {"body": "Established consulting practices are meeting- and travel-heavy. Protected deep work time is rare, and the coordination overhead will drain energy you need for the analytical work.", "label": "Staffing Model and Limited Deep Work Time"}, {"body": "Project timelines in consulting are externally imposed. You will regularly be asked to present conclusions before the analysis feels complete to you — this is the baseline condition, not the exception.", "label": "Delivering Recommendations Under Fixed Deadlines"}]}, {"fit": "Data engineering at an established tech company is precision-intensive, systems-oriented work that your HOW orientation is genuinely suited to. Building the pipelines and infrastructure that make data reliable and accessible requires exactly the kind of end-to-end systems thinking you find energizing — understanding how every component interacts and what happens when any one of them fails.\\n\\nThe fit is Good rather than Strong because the role is lower on WHY-orientation demand than your profile's primary orientation warrants. The strategic framing that energizes you most — connecting systems design to the purpose it serves — is secondary in pure data engineering. If the role includes scope to influence data strategy and architecture direction, the fit improves meaningfully.", "title": "Data Engineer", "fitLabel": "Good Fit", "fitScore": 74, "energizing": [{"body": "Building pipelines that hold up when volume and complexity increase draws directly on your HOW orientation's need to understand the full system before committing to a design.", "label": "Designing Data Infrastructure That Is Reliable Under Scale"}, {"body": "Tracing a data anomaly back through a pipeline to its origin is the kind of methodical, depth-requiring problem your profile is built for.", "label": "Debugging Complex Data Quality Issues"}, {"body": "Moving from reactive fixes to structural redesign — building the system that makes the failure impossible — is where your WHY-HOW wiring produces its most satisfying output.", "label": "Architecting Systems That Prevent Future Failures"}], "strategies": [{"body": "At an established company, push to be included in discussions about what the data infrastructure is meant to enable strategically. This connects your WHY orientation to the technical work and makes the role more sustainable.", "label": "Scope Into Data Architecture and Strategy Conversations"}, {"body": "Build alerting and automation for routine pipeline health monitoring early. This removes the repetitive maintenance work that will drain you and creates space for the architectural problems that energize you.", "label": "Automate Monitoring to Protect Deep Work Time"}, {"body": "At an established tech company, some teams treat data infrastructure as a strategic asset; others treat it as plumbing. Join the former — the difference in how your work is scoped and valued is significant.", "label": "Target Teams Where Data Infrastructure Is Strategically Central"}], "challenging": [{"body": "Once a pipeline is well-designed and running, the ongoing monitoring and maintenance work is repetitive in a way that does not engage your WHY orientation.", "label": "Routine Maintenance and Monitoring Work"}, {"body": "Pure data engineering roles often execute against requirements without involvement in the strategic framing of what the data infrastructure is meant to enable — a structural drain for your primary orientation.", "label": "Limited Strategic Context for Technical Decisions"}]}], "nextSteps": ["For each role you are considering, identify one specific person in that role at an established tech company and ask them one question: how much of your week is deep, uninterrupted analytical work versus coordination and communication? The answer will tell you more than any job description.", "Write two sentences on why the specific problem domain you would be working in matters to you — not to the company, to you. If you cannot write them for a role you are evaluating, that is important data about whether your WHY orientation will sustain you through the harder stretches.", "Map your current or most recent team for WHAT-orientation presence. If you do not have a colleague who is energized by deployment, momentum, and shipping, finding that relationship — formally or informally — is the single highest-leverage structural move you can make right now.", "Before your next compensation negotiation, research the market rate for staff-level IC roles in your target function at established tech companies. Your Competition StrengthsFinder theme responds to benchmarks — knowing the number gives you a concrete target and makes the negotiation conversation significantly easier for your CS DiSC profile."], "watchFors": ["Refining past the point where shipping is overdue", "Communication density that loses stakeholders mid-explanation", "Momentum stalling without a WHAT partner to force deployment", "Taking on coordination overhead that drains without adding value"], "energizers": ["Diagnosing complex systems no one has fully mapped", "Connecting strategic purpose to precise technical architecture", "Deep research that reframes how a problem is understood", "Synthesizing ambiguous data into clear, defensible insight", "Designing solutions rigorous enough to hold up under scrutiny"], "environmentNote": "Established tech companies offer the resources, data infrastructure, and problem depth that a WHY-HOW profile at mid-career genuinely benefits from. The risk in this environment is bureaucratic overhead and meeting culture that erodes the deep work time your best output depends on. Look for teams where IC output is measured by impact and depth of contribution — not visibility or responsiveness. Flat communication norms and asynchronous work culture are positive signals.\\n\\nFor your work-life balance priority, established companies offer more structural protection than startups — predictable scope, defined roles, and access to dedicated partners for the coordination work that drains you. The watch-for is scope creep into program management or stakeholder liaison work that is not in your job description but lands on the most thorough person available. Establish boundaries on that work early."}	\N
ee782a57-3b9f-4221-8d1f-3c152d2fb79a	2026-07-01 18:53:54.410505+00	WHY-HOW	Mid Career (5–12 years)	Individual Contributor	Tech	Established company	work-life balance	Primary consideration	DiSC: CS | StrengthsFinder: Activator, Competition, Discipline, Input, Woo	{"roles": [{"fit": "Staff Data Scientists at established tech companies are paid to go deep on problems that resist easy answers, which is exactly where your WHY-HOW orientation generates its most exceptional output. The role rewards understanding over speed, and at the staff level, you are expected to define the problem before solving it.\\n\\nIn an established company, this role also offers the structural stability your values orientation requires. You will have scope, protected time for deep work, and compensation that reflects technical seniority, without the chaos of a startup environment undermining your work-life balance.", "title": "Staff Data Scientist", "fitLabel": "Strong Fit", "fitScore": 95, "energizing": [{"body": "Defining what question is actually worth answering draws directly on your WHY orientation. This is where you are most energized and most differentiated.", "label": "Problem framing and research design"}, {"body": "Your HOW orientation drives you to understand the full picture before drawing conclusions, producing insights that surface-level analysis misses entirely.", "label": "Deep exploratory analysis on ambiguous datasets"}, {"body": "Designing systems that encode your thinking for others to reuse is deeply satisfying for this profile and creates lasting organizational leverage.", "label": "Building reusable analytical frameworks"}, {"body": "You are energized by finding the flaw everyone else accepted. At staff level, you have the credibility to act on it.", "label": "Challenging faulty assumptions in existing models"}], "strategies": [{"body": "Find one person on your team who is energized by deployment and progress. Let them own the delivery cadence while you own the analytical depth.", "label": "Partner explicitly with a WHAT-oriented PM or tech lead"}, {"body": "Before each project, write one sentence on what 'done' looks like. This creates a natural stopping point and protects you from endless refinement cycles.", "label": "Define your own 'complete enough' threshold before starting"}, {"body": "A reusable structure for translating complex analysis into executive-ready summaries reduces the energy cost of communication without compromising rigor.", "label": "Build a standing one-pager template for communicating findings"}, {"body": "At established companies, teams vary enormously. Prioritize roles where implementation is handled by a dedicated partner, not by you.", "label": "Target teams with embedded engineering or analytics partners"}], "challenging": [{"body": "Established tech companies still move fast. You will face recurring pressure to release before your analysis feels complete, which is a genuine drain.", "label": "Stakeholder pressure to ship incrementally"}, {"body": "Your thinking is dense and rigorous. Translating it for product managers or executives requires a translation layer that costs you energy.", "label": "Cross-functional communication to non-technical partners"}, {"body": "Tracking milestones and managing delivery schedules draws on your tertiary WHAT orientation. Without a partner or system, this creates real friction.", "label": "Maintaining project timelines and delivery commitments"}]}, {"fit": "Principal UX Researchers in established tech companies are charged with understanding human behavior at a systems level, a deeply energizing challenge for a WHY-HOW profile. You are expected to investigate why users behave the way they do and how the underlying system shapes that behavior, which maps precisely to your primary and secondary orientations.\\n\\nAt the principal level in a large tech company, compensation is competitive and the role carries real influence without requiring you to manage a team. Your Discipline and Input StrengthsFinder themes reinforce the rigor and knowledge synthesis this role demands.", "title": "Principal UX Researcher", "fitLabel": "Strong Fit", "fitScore": 91, "energizing": [{"body": "Building a research architecture that answers questions over time draws on both your WHY and HOW orientations simultaneously, generating sustained engagement.", "label": "Designing longitudinal research programs from scratch"}, {"body": "Your HOW orientation produces the kind of thorough synthesis that transforms scattered data into actionable organizational understanding.", "label": "Synthesizing qualitative and quantitative findings into insight frameworks"}, {"body": "You are energized by surfacing what others have accepted as true. Principal-level credibility gives you the platform to act on this instinct.", "label": "Challenging product decisions grounded in flawed assumptions"}, {"body": "When no existing method fits the question, your WHY-HOW orientation is at its best, designing the approach before solving the problem.", "label": "Developing research methodologies for novel problem spaces"}], "strategies": [{"body": "Connecting your research calendar to the product roadmap makes your work visible and protects time for depth without appearing misaligned from delivery.", "label": "Establish a research roadmap tied to product milestones"}, {"body": "One strong WHAT-oriented PM who trusts your work can carry your findings into decision rooms where you would otherwise need to create momentum yourself.", "label": "Identify a product manager who values depth as a translation partner"}, {"body": "Your interpersonal warmth creates natural trust in research relationships. Use it upstream, in recruiting participants and building stakeholder credibility, to protect deep work downstream.", "label": "Use your Woo and CS DiSC profile selectively for research buy-in"}], "challenging": [{"body": "Established tech companies expect research to convert to decisions quickly. Bridging from insight to action draws on your tertiary WHAT orientation.", "label": "Moving research through to product impact at speed"}, {"body": "Product managers and engineers wired for momentum will occasionally treat deep research as a delay. Managing that dynamic is a recurring energy cost.", "label": "Evangelizing research value to WHAT-dominant stakeholders"}, {"body": "Your instinct is to research completely. Fitting that instinct into two-week cycles without losing depth requires deliberate structural management.", "label": "Scoping projects to fit sprint cycles"}]}, {"fit": "Staff Product Managers at established tech companies are expected to define the right problems, not just execute on them, which suits your WHY-HOW orientation at this career stage. You have the experience to recognize when a product direction is structurally wrong, and the seniority to say so credibly.\\n\\nThe challenge is real: this role demands sustained momentum, stakeholder alignment, and delivery oversight, all WHAT-orientation work. In an established company, the structural support around you, dedicated engineering, design, and data partners, can absorb much of that load if you build the right team relationships deliberately.", "title": "Staff Product Manager", "fitLabel": "Strong Fit", "fitScore": 86, "energizing": [{"body": "Understanding why a problem exists and how the system produces it is where your WHY-HOW orientation generates the product insight others miss.", "label": "Deep customer and market problem diagnosis"}, {"body": "Connecting user insight to technical architecture to business model draws on both your orientations and produces strategy that is both ambitious and executable.", "label": "Building product strategy grounded in systemic understanding"}, {"body": "You are energized by finding the flaw in a plan before it ships. At staff level, this is a valued function, not an obstacle.", "label": "Challenging roadmap assumptions before they become commitments"}], "strategies": [{"body": "In established companies, this pairing is often available. Make it explicit and structural, not occasional, so delivery momentum is never your responsibility to generate.", "label": "Pair with a program or project manager for delivery cadence"}, {"body": "A lightweight written framework for when deep analysis is warranted versus when you move with current information protects your energy for the problems that deserve it.", "label": "Use your Discipline theme to build a decision-framework habit"}, {"body": "In stakeholder communication, train yourself to open with the conclusion. Your natural mode is to build the full picture first, but WHAT-oriented listeners disengage before you arrive at the point.", "label": "Lead with the answer, then the system"}, {"body": "In established companies, choose teams working on technically or behaviorally complex problems. Routine product work will drain you faster than complex work with structural support around it.", "label": "Target product domains with high intrinsic complexity"}], "challenging": [{"body": "Keeping five engineering tracks moving simultaneously draws heavily on your tertiary WHAT orientation. Without a strong program manager alongside you, this is a persistent drain.", "label": "Managing delivery momentum across multiple workstreams"}, {"body": "Engineers wired for action need clear, confident next steps. Your instinct to explain the full system before the answer can create friction in sprint planning.", "label": "Communicating priorities to WHAT-dominant engineering teams"}, {"body": "Not every product decision warrants deep analysis. Calibrating your depth investment to the stakes of a decision is a recurring judgment call that costs energy.", "label": "Accepting 'good enough' on lower-stakes features"}]}, {"fit": "Senior Data Analysts in established tech companies spend the majority of their time in work that is directly energizing for a WHY-HOW profile: diagnosing what is actually happening in a system, why it is happening, and how the underlying mechanics produce the observed outcome. This role rewards depth over speed, which matches your natural mode.\\n\\nThe compensation ceiling is the primary friction with your stated priority. In established tech, senior analyst compensation is solid but typically below staff or principal IC tracks. The role is a strong energy fit, but requires an honest assessment of whether the compensation band meets your threshold.", "title": "Senior Data Analyst", "fitLabel": "Good Fit", "fitScore": 82, "energizing": [{"body": "Finding the structural explanation for something that looks wrong in the data is deeply energizing for your profile, and this is a core senior analyst responsibility.", "label": "Root cause analysis on anomalous business metrics"}, {"body": "Designing systems that encode your analytical thinking for others draws on your HOW orientation and creates lasting value without increasing your coordination load.", "label": "Building self-serve analytical infrastructure for less technical teams"}, {"body": "Your Input StrengthsFinder theme and HOW orientation combine to produce the kind of thorough synthesis that turns disparate signals into clear organizational insight.", "label": "Synthesizing multi-source data into coherent narratives"}], "strategies": [{"body": "Categorize requests as immediate, standard, or deep-dive. Communicate the tier upfront so stakeholders calibrate expectations before you begin, not after.", "label": "Establish a tiered response framework for incoming requests"}, {"body": "A reusable dashboard, documented methodology, or shared framework transforms invisible analytical work into something the organization can point to and credit.", "label": "Build a visible output artifact for every deep analysis"}, {"body": "In established tech, senior analyst and staff analyst titles carry meaningfully different pay ranges. Clarify the leveling trajectory in your first interview conversation.", "label": "Map compensation bands before accepting a role"}], "challenging": [{"body": "Ad hoc requests from WHAT-dominant business partners expect answers in hours, not the depth-first analysis your orientation produces naturally.", "label": "Pressure to produce fast turnaround analyses for business requests"}, {"body": "Established companies reward visible output. Analytical depth that prevents problems is invisible; you will need to actively communicate the value of work others don't see.", "label": "Advocating for your own work in visibility-driven organizations"}]}, {"fit": "Management Consulting at an established firm is a conditional but real fit for a mid-career WHY-HOW profile. The work demands exactly what energizes you: diagnosing why something is broken, understanding the full system before proposing a solution, and producing insight of genuine quality. The compensation at established consulting firms in tech-adjacent practices is strong.\\n\\nThe condition is pace and travel. Consulting rewards momentum, client responsiveness, and rapid context-switching, all WHAT-orientation demands. Your CS DiSC profile and work-life balance priority are direct tension points with the traditional consulting model. This fit depends heavily on practice area and firm culture.", "title": "Management Consultant", "fitLabel": "Good Fit", "fitScore": 78, "energizing": [{"body": "Client engagements that reward deep diagnosis over fast prescription are where your WHY-HOW orientation produces its most distinctive consulting output.", "label": "Diagnosing organizational and operational problems from first principles"}, {"body": "Producing the analytical structure that changes a client's mental model is deeply energizing and a recognized premium deliverable in established consulting.", "label": "Building frameworks that reframe how clients understand their situation"}, {"body": "Developing deep domain expertise within a tech-adjacent practice draws on your Input theme and HOW orientation in a way that compounds over a consulting career.", "label": "Research synthesis and subject matter development in a defined practice area"}], "strategies": [{"body": "Smaller firms with narrower domain focus offer more protected deep work, less travel, and more predictable hours than full-service strategy firms.", "label": "Target boutique or specialized consulting firms in tech sectors explicitly"}, {"body": "Many established firms have internal practice development or research roles that pay consulting rates with significantly more depth and fewer client-facing pace demands.", "label": "Position for research or knowledge management tracks within a firm"}, {"body": "Getting a project moving quickly at the start creates goodwill and schedule slack you can use to protect depth-oriented work later in the engagement.", "label": "Use your Activator theme to create early momentum on engagements"}], "challenging": [{"body": "Consulting clients expect responsive, confident output on short timelines. The tension between that expectation and your depth-first mode is a structural and persistent drain.", "label": "Client-facing pace and rapid deliverable turnaround"}, {"body": "Established firms vary, but client service models create irregular hours. Your stated priority and CS DiSC profile are in direct tension with the standard consulting rhythm.", "label": "Work-life balance within traditional consulting structures"}, {"body": "Workshop facilitation and executive presentation demand WHAT-orientation momentum generation. Your Woo theme helps, but this work remains a consistent energy cost.", "label": "Rallying client stakeholders and managing room energy"}]}, {"fit": "Technical Program Managers in established tech companies coordinate complex multi-team initiatives and are often compensated at senior IC levels, which meets your compensation priority. The role has a real WHY-HOW footprint: understanding how complex technical systems interconnect and diagnosing where cross-functional dependencies will break before they do.\\n\\nThe honest challenge is that a large portion of the role is WHAT-orientation work: driving timelines, creating momentum, managing status, and rallying teams. In an established company with clear systems and predictable scope, this is more manageable than in a startup, but it remains a genuine and daily energy cost for your profile.", "title": "Technical Program Manager", "fitLabel": "Good Fit", "fitScore": 73, "energizing": [{"body": "Understanding how all parts of a large system interact before execution begins draws directly on your HOW orientation and is where TPMs create their most lasting value.", "label": "Mapping complex technical dependencies before program kickoff"}, {"body": "Your instinct to find the flaw before it surfaces produces the kind of early-warning analysis that established companies specifically hire senior TPMs to deliver.", "label": "Diagnosing program risks others have not yet identified"}], "strategies": [{"body": "Position yourself as the person who owns the pre-mortems, the dependency maps, and the structural risk analysis. This is where your profile adds disproportionate value in a TPM role.", "label": "Claim the risk and dependency diagnosis function explicitly"}, {"body": "A well-structured dashboard, automated reporting, or consistent meeting rhythm converts the most draining part of the role into a system you maintain rather than work you generate.", "label": "Build a system for status management rather than doing it manually"}, {"body": "A TPM coordinating infrastructure platform work is a fundamentally different energy experience than one coordinating marketing tech integrations. Match the domain complexity to your orientation.", "label": "Evaluate roles by the complexity of the technical domain"}], "challenging": [{"body": "Keeping ten engineering teams moving toward a shared milestone is primarily WHAT-orientation work. Without natural energy for momentum, this is a daily drain at scale.", "label": "Sustained delivery momentum management across many teams"}, {"body": "TPM roles in established companies carry significant meeting and status-update load. This work is not incidental to the role, it is central to it, and it is draining for your profile.", "label": "Administrative reporting and status communication overhead"}, {"body": "TPMs influence without ownership. For a profile energized by deep understanding and systemic mastery, operating in facilitative mode without full analytical ownership creates a persistent engagement ceiling.", "label": "Operating without deep domain ownership"}]}], "nextSteps": ["Before your next interview, write one sentence on what specific problem the team is trying to solve and why it is unsolved. If you cannot write it after researching the role, ask it as your first question.", "Map your current role's weekly activities against WHY, WHAT, and HOW work. If HOW work is below 50% of your week, that gap is worth naming before your next role search.", "Identify one WHAT-oriented colleague in your network, someone energized by momentum and deployment, and have a direct conversation about what a working partnership could look like. This relationship is your most important structural gap.", "When evaluating offers, ask the hiring manager what the last three major decisions on the team were and who drove them. The answer will tell you more about whether depth is valued than any job description will."], "watchFors": ["Refining past the point of diminishing returns", "Momentum gaps when no WHAT partner is present", "Communication density overwhelming less technical stakeholders", "Underestimating organizational pressure to ship faster"], "energizers": ["Diagnosing complex systems no one has fully mapped", "Connecting purpose to deep structural understanding", "Designing frameworks that make complexity legible", "Synthesizing research into insights that reframe decisions", "Solving problems others have declared unsolvable"], "environmentNote": "Established tech companies are a strong environmental match for your profile. They offer the structural stability, defined scope, and compensation infrastructure that both your values and compensation priority require. The friction to watch for is pace pressure that exists even in established environments: quarterly planning cycles, roadmap commitments, and product velocity expectations can create recurring urgency that conflicts with your depth-first orientation. Look specifically for teams that distinguish between exploration and execution phases, and that protect the former.\\n\\nGiven your CS DiSC profile, you will do your best work in environments with low political noise and high intellectual rigor. Large established tech companies vary enormously on this dimension. In interviews, ask directly about how decisions get made and how disagreement is handled. Your instinct to challenge assumptions is valuable; whether it is welcomed depends on the specific team culture, not the company brand."}	\N
ebc1e8b2-476c-4cba-b3da-d335f3c571d7	2026-07-01 18:53:57.07324+00	WHY-HOW	Mid Career (5–12 years)	Individual Contributor	Tech	Established company	work-life balance	Primary consideration	DiSC: CS | StrengthsFinder: Activator, Competition, Discipline, Input, Woo	{"roles": [{"fit": "At the staff level in an established tech company, the core output is no longer models — it is insight that reshapes how the organization understands itself. Your WHY-HOW wiring maps directly to this: you are energized by the intersection of a hard question and a complex system, and staff data science is built on exactly that combination.\\n\\nEstablished companies offer the stability and depth of data that rewards your mode of working. The work is not about speed; it is about getting it right. Your DiSC CS pattern reinforces a precise, methodical approach that fits the culture of mature data organizations well.", "title": "Staff Data Scientist", "fitLabel": "Strong Fit", "fitScore": 94, "energizing": [{"body": "Tracing why a metric moved — through layers of data, system behavior, and organizational context — is exactly where your primary orientation generates exceptional output.", "label": "Root Cause Analysis at Scale"}, {"body": "Building the methodology others will use to answer a class of questions energizes you far more than running a single analysis.", "label": "Designing Analytical Frameworks"}, {"body": "Your instinct to test what everyone accepts as true is a structural asset in data science — flawed assumptions compound silently until someone with your wiring finds them.", "label": "Surfacing Assumptions in Existing Models"}, {"body": "Pulling together product, behavioral, and operational data into a coherent picture of a problem plays directly to your secondary HOW precision combined with WHY-level framing.", "label": "Cross-Functional Research Synthesis"}], "strategies": [{"body": "At project kickoff, write down one sentence: what would make this analysis good enough to act on? Revisit it when you feel the pull to keep refining.", "label": "Define 'Complete Enough' Before You Start"}, {"body": "Identify one PM or engineering lead who is energized by moving fast and trust their deployment instinct. Let them set the shipping deadline; you set the quality floor.", "label": "Find Your WHAT Partner in Product or Engineering"}, {"body": "Draft two versions of every output: the full analysis for technical reviewers and a one-page summary for stakeholders. The discipline of writing the summary will surface gaps in your own thinking.", "label": "Build a Translation Layer Into Your Deliverables"}, {"body": "When scoping projects with stakeholders, anchor the conversation to which decision this will inform. That framing protects your depth while giving you a natural stopping point.", "label": "Negotiate Scope in Terms of Decisions, Not Work"}], "challenging": [{"body": "Established companies still have roadmap cycles and quarterly timelines. The pressure to present before analysis feels complete will be a recurring friction point.", "label": "Stakeholder Pressure to Ship Faster"}, {"body": "Your natural output is thorough and layered. Getting from your internal understanding to a three-slide summary requires deliberate translation work that will not come naturally.", "label": "Translating Depth Into Executive Communication"}, {"body": "Without a WHAT partner creating external urgency, long research projects can drift into refinement cycles that delay organizational value without clear warning signals.", "label": "Maintaining Momentum on Long-Horizon Projects"}]}, {"fit": "Principal UX research in an established tech company is one of the highest-leverage individual contributor roles for your profile. The core work — understanding why users behave the way they do, building research systems that generate insight at scale, and challenging product assumptions with rigorous evidence — maps almost entirely to your primary and secondary orientations.\\n\\nAt this level, you are not just running studies; you are shaping what questions the organization thinks to ask. Your Woo theme from StrengthsFinder helps you build the cross-functional relationships that get research actually used, while your Discipline theme creates the methodological rigor that makes your work credible.", "title": "Principal UX Researcher", "fitLabel": "Strong Fit", "fitScore": 91, "energizing": [{"body": "When no one knows what the right question is yet, your WHY orientation produces the framing that product and design teams cannot get to on their own.", "label": "Generative Research on Undefined Problem Spaces"}, {"body": "Designing the systems, panels, and methodologies others use to conduct research lets your HOW precision create organizational leverage beyond your own direct output.", "label": "Building Research Operations Infrastructure"}, {"body": "Your instinct to find the flaw in an assumption everyone accepts is structurally valuable in research — and at the principal level, you have the standing to surface it.", "label": "Challenging Product Roadmap Assumptions"}, {"body": "Connecting behavioral patterns across different products or user segments into a unified model of user mental models plays to your deepest cognitive strengths.", "label": "Synthesizing Across Multiple Research Streams"}], "strategies": [{"body": "In your next conversation with your manager, negotiate explicit time allocation. Evaluative sprint work should be handled by mid-level researchers; your leverage is in generative work.", "label": "Protect 60% of Your Time for Foundational Research"}, {"body": "Document every decision a product team made that was informed by your research. This gives you concrete evidence for compensation conversations and protects your scope from being reduced to fast-cycle testing.", "label": "Create a Research Impact Tracker"}, {"body": "Find one product manager who treats your work as essential rather than supplementary. That relationship is your organizational lever — and your WHAT complement for deployment.", "label": "Partner With a PM Who Cites Research in Reviews"}, {"body": "Your Discipline theme will support this: every two weeks, write a one-page synthesis of what your current research is revealing. It forces deployment of thinking before it grows unwieldy.", "label": "Build a Two-Week Synthesis Ritual"}], "challenging": [{"body": "In large established companies, research reports can be thorough and correct and still not influence the roadmap. Getting work used requires organizational navigation that drains you.", "label": "Research That Sits Unread"}, {"body": "Usability testing on a two-week sprint cycle prioritizes speed over depth. This is not where you do your best work, and being assigned to it consistently will erode your energy.", "label": "Rapid Evaluative Research Cycles"}, {"body": "When you need to influence a decision without data — relying purely on presence and persuasion — the absence of your analytical foundation makes the work significantly harder.", "label": "Advocacy Without Analytical Cover"}]}, {"fit": "In an established tech company, senior product management rewards the WHY-HOW profile in a specific way: the most valued PMs at this level are the ones who can define what problem is actually worth solving and then understand the system deeply enough to know if the proposed solution will hold. That is your native mode. Your Activator theme ensures you can translate that clarity into forward motion, which addresses the momentum gap that otherwise limits WHY-HOW types in this role.\\n\\nWork-life balance is genuinely achievable in senior PM roles at established tech companies more than at startups — the environment preference is a meaningful advantage here.", "title": "Senior Product Manager", "fitLabel": "Strong Fit", "fitScore": 86, "energizing": [{"body": "Defining what the team should be working on — before anyone has opened a design file — is the highest-leverage PM work and the work that most energizes your profile.", "label": "Problem Framing and Opportunity Sizing"}, {"body": "Your HOW secondary orientation lets you engage with engineering constraints at a level most PMs cannot, which builds credibility and improves the quality of tradeoff decisions.", "label": "Technical Depth in Product Reviews"}, {"body": "Structured long-form thinking that forces clarity — connecting user needs to technical architecture to business rationale — is where your wiring produces output others find genuinely irreplaceable.", "label": "Writing PRDs and Strategy Documents"}], "strategies": [{"body": "Identify the person on your team who is most energized by execution detail and explicitly make them your operational partner. This is a structural requirement, not a shortcut.", "label": "Delegate Sprint Mechanics to a Strong Tech Lead or APM"}, {"body": "Your StrengthsFinder Activator theme is an asset here — when you feel analysis pulling you into a loop, use it as a forcing function to commit to a direction and test it.", "label": "Use Your Activator Theme Deliberately"}, {"body": "Before any feature prioritization meeting, circulate a one-paragraph problem statement. This protects your energy by keeping the conversation in your primary orientation rather than jumping to execution.", "label": "Anchor Every Roadmap Discussion in Problem Clarity"}, {"body": "Before accepting a PM role, ask who you would be partnering with in engineering and design. A strong WHAT-HOW engineering lead is the single highest-value structural complement for your profile in this role.", "label": "Evaluate Roles by Team Composition"}], "challenging": [{"body": "Daily standups, unblocking engineers, managing ticket backlogs — this is WHAT-HOW work. It is the part of senior PM that will consistently cost you energy.", "label": "Driving Sprint Velocity as a Core Responsibility"}, {"body": "Senior PMs in large companies spend significant time in organizational negotiation. Your DiSC CS pattern means you prefer structured, substantive dialogue — not political maneuvering.", "label": "Stakeholder Alignment Across Many Competing Interests"}, {"body": "Product timelines require decisions under uncertainty. Your instinct to understand fully before committing will create friction with the pace of roadmap cycles.", "label": "Making Calls Before the Picture Feels Complete"}]}, {"fit": "Senior data analyst roles at established tech companies offer the analytical depth and compensation this profile needs, but the ceiling on both influence and pay at this title is real. You will do your best work here, but you may find the organizational weight of the role insufficient within two to three years — the problems are bounded in ways that will start to feel constraining once you have mapped the system.\\n\\nThat said, as a mid-career move into a new domain or a deliberate choice to protect work-life balance while building technical depth, this role has genuine merit. Your Competition theme will push you toward the staff or lead analyst trajectory quickly.", "title": "Senior Data Analyst", "fitLabel": "Good Fit", "fitScore": 83, "energizing": [{"body": "When a stakeholder brings a vague concern and needs someone to figure out what is actually happening, your profile generates the most value of anyone in the analyst pool.", "label": "Exploratory Analysis on Ambiguous Business Questions"}, {"body": "Creating the framework that others will use to answer a class of questions — rather than answering any single question — is where your HOW precision creates lasting organizational leverage.", "label": "Building Reusable Analytical Models"}, {"body": "Reviewing other analysts' work for flawed assumptions and methodological gaps energizes you and builds internal reputation simultaneously.", "label": "Peer Review and Methodology Critique"}], "strategies": [{"body": "In your next performance conversation, name the staff or lead analyst title as your 12-month goal. The compensation and scope jump is significant and maps better to your profile's natural leverage point.", "label": "Make the Staff Analyst Track Your Explicit Target"}, {"body": "Identify every report you own that runs on a schedule and build automation for it. This frees your time for the exploratory work where you actually generate exceptional output.", "label": "Automate Your Recurring Work in the First 90 Days"}, {"body": "Bring your manager one strategic question the team has not properly investigated. Your Activator theme will help you get buy-in; your HOW-WHY wiring will produce the answer.", "label": "Propose One Foundational Research Question Per Quarter"}], "challenging": [{"body": "A significant portion of analyst time in established companies goes to recurring reports. This work will drain you steadily and should be delegated or automated as quickly as possible.", "label": "Repetitive Reporting and Dashboard Maintenance"}, {"body": "At the senior analyst level, you are often handed the question rather than defining it. Your WHY orientation will find this constraining in ways that matter for sustained engagement.", "label": "Limited Influence Over Problem Selection"}]}, {"fit": "Solutions architecture in an established tech company is a strong structural match for your profile when the role is weighted toward pre-sales technical design and system scoping rather than implementation delivery. You are energized by understanding how a complex customer environment works and designing a solution that genuinely fits — and your WHY orientation ensures you push back when a proposed solution addresses the wrong problem.\\n\\nThe challenge is that the role has a strong external-facing component that will tax your DiSC CS pattern. High-volume stakeholder interaction and the need to project confidence under pressure in customer environments will be a real energy cost.", "title": "Solutions Architect", "fitLabel": "Good Fit", "fitScore": 80, "energizing": [{"body": "Mapping a customer's existing architecture to understand what they actually need — versus what they asked for — is exactly the kind of problem your profile was built for.", "label": "Technical Discovery With Complex Enterprise Customers"}, {"body": "Creating the technical blueprint that bridges customer requirements to platform capabilities plays to your HOW depth and your WHY instinct to ensure the solution addresses the real problem.", "label": "Designing Solution Architecture Documents"}, {"body": "Your instinct to ask 'but what happens when X?' before anyone else has is a structural advantage in architecture reviews — and is exactly what customers pay for at this level.", "label": "Evaluating Edge Cases and Integration Risks"}], "strategies": [{"body": "Your DiSC CS pattern means you perform best in customer conversations when you have thought through the architecture space in advance. Build a standard discovery questionnaire that gives you that preparation time.", "label": "Establish a Discovery Template That Lets You Prepare"}, {"body": "Find a WHAT-oriented sales engineer who handles the high-energy demo and relationship-building work. You take the deep technical design conversations — that division of labor protects your energy and improves customer outcomes.", "label": "Partner With a Sales Engineer Who Handles Demos"}, {"body": "Ask your manager to route the most technically complex deals to you and simpler implementations to junior architects. Your value is in problems that reward depth, not volume.", "label": "Negotiate a Caseload That Prioritizes Complexity"}], "challenging": [{"body": "Solutions architects often present to multiple customer stakeholders per week. Your DiSC CS pattern means this is sustainable but not energizing — and volume will erode your energy over time.", "label": "High-Volume Customer-Facing Presentation Work"}, {"body": "The sales organization needs technical answers quickly. Your instinct to fully understand before committing creates friction with deal timelines that are outside your control.", "label": "Balancing Depth Against Sales Cycle Timelines"}]}, {"fit": "Management consulting at an established firm — particularly in technology practice areas — is a conditional fit for your profile. The WHY-HOW orientation produces the kind of insight that distinguishes exceptional consultants: you find the real problem behind the presenting problem, and you build frameworks that hold up under scrutiny. That is exactly what clients pay for.\\n\\nThe conditional element is pace and life balance. Established consulting firms are more sustainable than boutiques, but the model still demands output speed and client management intensity that will conflict with your natural working mode and your stated value of work-life balance. Be honest with yourself about that tradeoff before pursuing this path.", "title": "Management Consultant", "fitLabel": "Good Fit", "fitScore": 76, "energizing": [{"body": "The period between project kickoff and recommendation development — where you are mapping a client's system and finding the real problem — is where your profile generates its highest-value consulting output.", "label": "Diagnostic Phases of Engagements"}, {"body": "Building the analytical approach the team will use to answer the client's question plays directly to your HOW precision and your WHY instinct to find the right framing.", "label": "Framework and Methodology Development"}, {"body": "Tech strategy or organizational effectiveness specializations let you build deep domain knowledge — which rewards your profile far more than generalist delivery rotations.", "label": "Specialist or Subject Matter Expert Tracks"}], "strategies": [{"body": "Within an established consulting firm, the practice area determines your day-to-day work more than the firm brand does. Technology strategy and org effectiveness practices reward depth over throughput.", "label": "Target the Technology Strategy or Systems Practice"}, {"body": "Ask specifically about average hours, travel expectations, and staffing model in interviews. Use your Input and Discipline themes to gather and evaluate that data honestly — not optimistically.", "label": "Be Explicit About the Work-Life Balance Tradeoff Before Accepting"}, {"body": "Your best consulting experience will be on teams where a high-energy WHAT-oriented engagement manager handles client momentum while you own the analytical depth. Ask about team structure before joining a project.", "label": "Find a WHAT-Primary Engagement Manager Partner"}], "challenging": [{"body": "Consulting timelines are set by client expectations, not analytical completeness. You will regularly be asked to finalize recommendations before the picture feels fully clear.", "label": "Client Deliverable Timelines That Outpace Your Analysis"}, {"body": "Even at established firms, consulting requires sustained high-output periods that are incompatible with the balance you have named as a core value. This is not a caveat — it is the defining tradeoff of the role.", "label": "Work-Life Balance Conflict Is Structural, Not Environmental"}]}], "nextSteps": ["Before your next interview or internal conversation about scope, write one sentence describing the hardest unsolved problem in the domain you are targeting. If you cannot write it, you have not found the right role yet.", "Map your current or target team for a WHAT-primary partner — someone energized by deployment and organizational momentum. That relationship is a structural requirement for your profile, not a nice-to-have. If no such person exists on your target team, ask about it directly before accepting an offer.", "Pull your compensation data now: research staff-level IC bands at three to five established tech companies in your target function using Levels.fyi or Glassdoor. Your Competition theme will engage immediately once you have concrete numbers to orient around.", "In your next performance review or goal-setting conversation, explicitly negotiate protected time for deep analytical work — name a percentage. Established companies will absorb your best thinking into reactive work if you do not create a structural boundary around it."], "watchFors": ["Refining past the point where work should ship", "Communication density that loses stakeholders mid-explanation", "Momentum gaps when no WHAT partner is present", "Scope creep driven by genuine intellectual thoroughness"], "energizers": ["Diagnosing complex systems no one has fully mapped", "Building frameworks that explain what others only describe", "Deep research with real organizational stakes", "Connecting purpose to technical architecture", "Problems where surface-level thinking produces wrong answers"], "environmentNote": "Established tech companies are a strong structural match for your profile at this career stage. The depth of data, the organizational memory, and the reduced pressure to ship before thinking — relative to startups — all create conditions where your WHY-HOW wiring can generate its best output. What to watch for in any established company: bureaucratic overhead that creates coordination drag without adding analytical value. Your DiSC CS pattern means you will tolerate process better than most, but status meetings and organizational politics that consume time you could spend thinking will erode your energy steadily and invisibly.\\n\\nWhen evaluating specific companies, look for organizations where individual contributor technical tracks reach staff or principal levels with compensation parity to management. That structure signals the company understands that depth creates organizational value — and it protects your ability to stay in the work you are built for without being forced into management to access competitive compensation."}	\N
5a80dbd8-6a87-44e1-a390-7b3e3730dbc7	2026-07-01 19:01:23.774743+00	WHY-HOW	Senior / Executive (12+ years)	Individual Contributor	finance	Established company	\N	Secondary to mission / fit	DiSC: DC | StrengthsFinder: Ideation, Includer, Restorative, Self-Assurance, Woo	{"roles": [{"fit": "Risk at the senior level in an established financial institution is fundamentally a WHY-HOW role: the work is understanding how a complex system can fail before it does, and the job is making that case clearly enough that the organization acts on it. Your primary orientation supplies the conviction to name risks others are incentivized to minimize; your HOW supplies the systemic rigor to make that case airtight.\\n\\nIn an established firm, this role carries genuine organizational authority. You are not executing a risk framework someone else designed — you are the person accountable for whether the framework is right. Your DC DiSC pattern means you will hold that accountability without equivocating, and your Restorative theme means you are most energized when something is genuinely broken and needs rebuilding.", "title": "Chief Risk Officer", "fitLabel": "Strong Fit", "fitScore": 94, "energizing": [{"body": "Risk frameworks calcify around assumptions no one has pressure-tested in years. This is precisely the kind of problem your WHY-HOW orientation is built for — questioning the premise, then rebuilding it correctly.", "label": "Stress-testing assumptions the firm treats as settled"}, {"body": "Building the system that catches what others miss is deeply energizing for HOW primaries. At CRO level, you own that architecture entirely.", "label": "Designing the analytical architecture behind risk models"}, {"body": "Your Self-Assurance and DC DiSC pattern mean you can deliver an unwelcome finding to a senior room without hedging it into irrelevance. That is rare and valuable at this level.", "label": "Presenting findings that require the organization to change course"}, {"body": "The intersection of why a regulation is changing and how it maps to specific firm exposure is a systems-thinking problem that will hold your attention across a full career.", "label": "Connecting regulatory signals to internal exposure before others do"}], "strategies": [{"body": "A WHAT-oriented Deputy CRO or Chief of Staff turns your deep analysis into organizational action. Without this partner, your best work risks living in documents rather than decisions.", "label": "Hire a deputy who is wired for deployment and momentum"}, {"body": "Identify one person whose job is to receive your full analysis and produce the two-page version. This is not simplification — it is the structural bridge your HOW orientation needs.", "label": "Build a standing communication translation process for board outputs"}, {"body": "Your WHY orientation means you will be most persuasive when you connect risk findings to what the firm is trying to become — not just what it is trying to avoid.", "label": "Anchor risk agenda items to the firm's purpose and strategic priorities"}, {"body": "Create a fixed quarterly process for surfacing emerging risks before they are visible to the business. This converts your deep diagnostic work into an organizational rhythm others can rely on.", "label": "Establish a structured cadence for proactive risk surfacing"}], "challenging": [{"body": "When nothing is visibly broken, keeping the risk agenda alive inside a WHAT-dominant executive team is a momentum problem your tertiary orientation finds draining. A strong Chief of Staff or deputy becomes essential.", "label": "Sustaining organizational momentum between risk events"}, {"body": "Your Ideation and HOW depth will produce more layers than the board can absorb. The translation gap is structural — it requires a communication partner, not just editing.", "label": "Translating dense analysis into board-level communication"}, {"body": "At CRO level, your findings will block revenue-generating initiatives. The organizational friction this creates is ongoing and real, and your DC profile will want to resolve it through directness rather than navigation.", "label": "Managing the political dimension of saying no at scale"}]}, {"fit": "A Head of Research role at an established financial institution is structured around the exact intersection your profile produces best: forming a view on why something is true, then building the analytical architecture to prove it at a standard the market will respect. The WHY orientation supplies the courage to hold a differentiated thesis; the HOW orientation supplies the rigor to make it defensible under scrutiny. Together, they produce research that moves beyond consensus.\\n\\nAt senior level, the role shifts from producing research to setting the intellectual standard for a team. Your Ideation and Restorative themes mean you are genuinely energized by the quality problem — why is our research not yet as good as it could be — and your DC pattern means you will set a high bar and hold it.", "title": "Head of Research", "fitLabel": "Strong Fit", "fitScore": 91, "energizing": [{"body": "The moment between sensing that consensus is wrong and knowing exactly why is the WHY-HOW sweet spot. Research gives you this problem repeatedly.", "label": "Forming a differentiated thesis on a market or sector"}, {"body": "Designing the methodology behind the research — not just the output — is where HOW primaries do their most energizing work.", "label": "Building the analytical framework that stress-tests the team's conclusions"}, {"body": "Your Ideation theme and WHY orientation combine to make you genuinely good at finding the research question others have normalized past. That is the highest-value contribution at this level.", "label": "Identifying the question the market has not yet asked"}], "strategies": [{"body": "Find someone wired for WHAT-HOW execution to manage the output pipeline. Your job is the quality standard and the thesis — not the publication schedule.", "label": "Pair yourself with a Research Director who owns production cadence"}, {"body": "Create a structured forcing function that requires the team to state a clear thesis before deep analysis begins. This converts your WHY instinct into an organizational practice.", "label": "Institutionalize a thesis review process that forces early commitment"}, {"body": "Your StrengthsFinder profile gives you unusual relational range for a deep-research orientation. Use it deliberately to ensure your research agenda has internal champions outside the research team.", "label": "Use your Woo and Includer themes to build client and internal credibility"}], "challenging": [{"body": "Research heads face constant pressure to publish more, faster. Your HOW orientation will resist shipping work that isn't complete, creating ongoing tension with production schedules.", "label": "Managing publication cadence and output velocity expectations"}, {"body": "Team momentum is a WHAT problem. Without a strong research director beneath you managing day-to-day output rhythms, this will be a persistent energy drain.", "label": "Keeping junior analysts motivated and moving without micromanaging"}, {"body": "The density of your analysis will frequently exceed what portfolio managers, clients, or executives can absorb. The translation gap is structural and requires a dedicated communication layer.", "label": "Communicating complex findings accessibly to non-research stakeholders"}]}, {"fit": "A Principal-level individual contributor strategy role inside an established financial institution is one of the few IC structures that keeps a WHY-HOW at full cognitive engagement without requiring them to manage organizational momentum. The work is diagnosis and framework: understanding why the firm's strategic position is what it is, where the structural vulnerabilities are, and what a better path looks like. At Principal level, you are the person accountable for the quality of the thinking — not the execution of the answer.\\n\\nThe IC structure matters here. Without a team to lead, you can go deep without the organizational overhead of managing momentum and morale — the WHAT work that drains your tertiary orientation most. Your DC DiSC profile and Self-Assurance theme mean you will hold and defend a difficult strategic view in senior rooms, which is exactly what this role requires.", "title": "Principal, Strategy", "fitLabel": "Strong Fit", "fitScore": 88, "energizing": [{"body": "The question of why the firm is where it is — not just where it is — is a WHY-HOW problem that generates genuine engagement across a sustained project.", "label": "Diagnosing structural problems in the firm's competitive position"}, {"body": "Constructing the framework that makes a complex strategic argument coherent and defensible is HOW-primary work at its most energizing.", "label": "Building the analytical case for a strategic recommendation"}, {"body": "Your WHY orientation makes you the person most likely to surface a faulty premise before it drives two years of investment. At Principal level, that instinct has organizational standing.", "label": "Challenging strategic assumptions before they become embedded in planning cycles"}], "strategies": [{"body": "Before committing energy to a strategy project, get clarity on what decision it is intended to inform and who will act on it. Undefined mandates are an energy trap for WHY-HOW profiles.", "label": "Negotiate explicit problem ownership at the start of each engagement"}, {"body": "Identify one COO or divisional head who trusts your analysis and will carry recommendations into execution. That relationship is the bridge between your thinking and organizational change.", "label": "Build a deployment partnership with a senior operational leader"}, {"body": "You are most energized when fixing something real. Positioning your strategy contribution around diagnosing dysfunction — rather than generating options — will keep your engagement high and your output differentiated.", "label": "Use your Restorative theme to frame strategy work around what is broken"}], "challenging": [{"body": "The deployment gap is real at this level. A brilliant strategy document that doesn't change behavior is a failure mode your HOW-tertiary-WHAT profile is structurally vulnerable to.", "label": "Moving recommendations from analysis to organizational adoption"}, {"body": "Strategy roles at established firms can drift into ambiguity about what the function is actually for. Without a clear problem to solve, your WHY orientation will struggle to sustain engagement.", "label": "Operating without a clear problem mandate"}]}, {"fit": "A senior Financial Economist at an established firm — central bank, major asset manager, or large financial institution — is a role built around the WHY-HOW combination at its highest expression: understanding why markets, systems, and policies behave as they do, and building the analytical architecture to explain it rigorously. The work is not execution. It is comprehension and the intellectual courage to commit to a view when the data is genuinely ambiguous.\\n\\nAt senior IC level, the role gives you unusual autonomy over your research agenda, which your WHY orientation needs to stay engaged. Your Ideation theme will generate more hypotheses than you can pursue — the HOW orientation will force the ones you commit to into something defensible. Your DC DiSC profile means you will publish a difficult conclusion without softening it into irrelevance.", "title": "Financial Economist", "fitLabel": "Strong Fit", "fitScore": 85, "energizing": [{"body": "Economic phenomena that don't fit existing models are exactly the problems your WHY-HOW combination is built to engage with across a sustained period.", "label": "Building an explanatory model for something the field has not yet resolved"}, {"body": "The integration problem — connecting forces that other analysts treat separately — is where your systems orientation produces its highest-value output.", "label": "Synthesizing regulatory, behavioral, and structural forces into a coherent framework"}, {"body": "Your Self-Assurance and DC DiSC pattern mean adversarial intellectual engagement is energizing, not threatening. That is a meaningful asset in a role where your conclusions will frequently challenge consensus.", "label": "Presenting a differentiated view to an audience that will push back hard"}], "strategies": [{"body": "Find someone whose job is to receive your full analysis and surface the core argument. This is not ghostwriting — it is the structural translation layer your HOW depth requires to reach the audiences that matter.", "label": "Establish a writing partner or editorial relationship for all major outputs"}, {"body": "Before beginning deep analysis, commit in writing to what conditions would constitute sufficient evidence to publish. This converts the completeness instinct into a boundary rather than an endpoint.", "label": "Define 'complete enough' criteria at the start of each research project"}, {"body": "Your StrengthsFinder profile gives you unusual relational warmth for a deep-research orientation. Use it to ensure your work reaches decision-makers before it is formally published.", "label": "Use your Woo and Includer themes to build informal intellectual networks across the institution"}], "challenging": [{"body": "Your HOW orientation will resist publishing before the analysis feels complete. Institutional deadlines are structural WHAT pressure, and the tension between them and your depth drive is persistent.", "label": "Producing work on institutional publication schedules"}, {"body": "Policy stakeholders need a clear answer, not the full architecture behind it. Translating without losing the integrity of the analysis is a communication challenge your profile faces at every level.", "label": "Communicating findings to policy audiences who need clarity, not completeness"}]}, {"fit": "A Director of FP&A at an established financial institution is a role with a genuine WHY-HOW fit at its core — the work is understanding why financial performance looks the way it does, not just reporting that it does. At senior IC level, your contribution is the diagnostic framework: building the analytical infrastructure that turns financial data into something the business can act on. The HOW orientation is fully engaged by the complexity of multi-entity financial architecture; the WHY orientation is engaged by the question of what the numbers actually mean.\\n\\nThe conditional nature of the fit is real: the role contains meaningful WHAT work — close cycles, recurring deliverables, production pressure — that your tertiary orientation will find draining over time. In an established firm, that production cadence is heavier than in a startup context. The fit is strong when the FP&A function is primarily analytical and advisory; it degrades when it becomes primarily a reporting and cycle management function.", "title": "Director of Financial Planning and Analysis", "fitLabel": "Good Fit", "fitScore": 81, "energizing": [{"body": "The analytical detective work of understanding why a number moved — not just that it moved — is where your WHY-HOW orientation does its best financial work.", "label": "Diagnosing the structural drivers behind a performance variance"}, {"body": "Designing the framework that organizes multi-entity financial complexity into something coherent is HOW-primary work that will hold your engagement across a sustained build.", "label": "Building the financial model architecture that makes complexity legible"}, {"body": "The translation from financial analysis to strategic implication is a WHY-HOW move. Your DC DiSC profile means you will deliver the uncomfortable implication directly.", "label": "Advising senior leadership on what the financial data actually implies"}], "strategies": [{"body": "Your FP&A structure only works if someone else owns close management and recurring reporting. That is not a nice-to-have — it is the structural requirement that makes the role sustainable for your profile.", "label": "Hire a Senior Manager who owns the production cycle entirely"}, {"body": "Use your DC profile and Self-Assurance to advocate internally for a broader mandate. FP&A functions that are primarily analytical and advisory are a stronger fit for your profile than those that are primarily reporting functions.", "label": "Reposition the FP&A function as a strategic advisory capability"}, {"body": "Maintain three to four active diagnostic questions the team is investigating outside the production cycle. This keeps your WHY-HOW orientation engaged during periods when the routine work dominates.", "label": "Build a rolling analytical agenda independent of the close calendar"}], "challenging": [{"body": "Monthly close, board package production, and recurring deliverables are structural WHAT work. This is the part of the FP&A role that will drain your energy most consistently.", "label": "Owning the production cadence of the close and reporting cycle"}, {"body": "FP&A teams face constant pressure to produce more, faster. Protecting the analytical quality your profile requires while meeting production expectations requires a strong operational deputy.", "label": "Managing the team's output velocity without losing analytical depth"}, {"body": "When the analytical work is routine and the close is just a close, your WHY-HOW orientation will disengage. Established firms have more of these periods than startups.", "label": "Sustaining engagement during low-complexity reporting periods"}]}, {"fit": "An Organizational Effectiveness Consultant embedded in or serving an established financial institution is a role where your WHY-HOW orientation produces genuinely distinctive work: you are diagnosing why organizations produce the outcomes they do — not just what the outcomes are — and building frameworks that explain the structural causes. The financial services context means the problems are high-stakes and complex, which is the condition your profile requires to sustain engagement.\\n\\nThe conditional element is deployment. Consulting engagements produce recommendations; implementation is someone else's problem. For a WHY-HOW, this can be energizing — you hand off before the WHAT drain kicks in — or it can become frustrating when recommendations don't get implemented and the diagnostic cycle repeats without resolution. Your Restorative theme will want to see the fix actually land.", "title": "Organizational Effectiveness Consultant", "fitLabel": "Good Fit", "fitScore": 78, "energizing": [{"body": "The root cause analysis behind organizational underperformance is a systems-thinking problem that your WHY-HOW orientation will find genuinely engaging across a full engagement.", "label": "Diagnosing why a financial organization's structure produces dysfunction"}, {"body": "Designing the analytical model that explains what no one has been able to name is HOW-primary work at its most satisfying.", "label": "Building the diagnostic framework that makes invisible dysfunction visible"}, {"body": "Your DC DiSC profile and Self-Assurance mean you can hold an unwelcome organizational finding in a senior room without retreating from it. That is the core value of this role.", "label": "Presenting a structural diagnosis to senior leadership under conditions of organizational resistance"}], "strategies": [{"body": "The engagement management layer — keeping the client moving, managing timelines, maintaining momentum — must be covered by a structural partner. Trying to own it yourself will drain your energy and degrade your analytical output.", "label": "Partner with a WHAT-oriented project manager on every engagement"}, {"body": "Develop a reusable template that converts your full diagnostic architecture into a two-page leadership narrative. Build this once and use it across every engagement rather than translating fresh each time.", "label": "Build a standard communication framework for translating diagnostic output"}, {"body": "Your combination of WHY-HOW orientation and finance context knowledge is a rare and specific credential. Positioning around financial services organizational design — rather than general OE consulting — gives you a differentiated market position and problems complex enough to hold your attention.", "label": "Specialize in financial services organizational problems specifically"}], "challenging": [{"body": "Keeping a client organization moving through an engagement — status updates, stakeholder management, maintaining urgency — is structural WHAT work that your tertiary orientation finds draining.", "label": "Managing client engagement momentum between diagnostic phases"}, {"body": "The communication density problem is acute in this role. Clients need a clear change story, not the full diagnostic architecture. That translation requires a deliberate structural solution.", "label": "Translating dense organizational analysis into simple change narratives"}]}], "nextSteps": ["Before your next role conversation or interview, write one sentence on what financial problem — specific, not abstract — you most want to spend the next chapter working on. If you cannot write it, that is useful diagnostic data about whether the opportunity is right for your profile.", "Map your current or target role against one question: what percentage of my week is spent on analytical diagnosis versus production and coordination? If the honest answer is less than fifty percent diagnosis, identify whether that ratio is changeable or structural.", "Identify one person in your current network who is energized by the deployment and momentum work you find draining — someone wired for WHAT execution who completes your blind spot. That relationship is worth more right now than any technical credential you could add.", "When evaluating specific opportunities, weight the quality and complexity of the problem over the brand of the institution. Your profile will outperform in environments where the analytical problem is genuinely hard and your findings carry organizational weight — regardless of whether the firm's name is the most recognizable on the list."], "watchFors": ["Refining past the point where the work should ship", "Communication density that loses the room before the insight lands", "Momentum gaps when no structural WHAT partner is in place", "Underestimating how much organizational context must travel with the analysis"], "energizers": ["Diagnosing why a financial system is broken at the root", "Building frameworks that explain what no model currently captures", "Questioning the premise behind a widely accepted market thesis", "Connecting regulatory, behavioral, and structural forces into a coherent picture", "Producing analysis that changes what decision-makers believe is possible"], "environmentNote": "Established financial institutions are a strong environmental match for your profile in ways that startup and high-growth environments are not. The problems are genuinely complex and reward deep understanding over speed. The organizational structures give senior ICs real standing. The compensation is sufficient without requiring you to prioritize it. Watch for one specific risk in this environment: established firms can also calcify around process and reporting in ways that convert a diagnostic role into a production role over time. The signal to watch for is when your calendar fills with standing meetings and recurring deliverables rather than analytical problems. That shift is structural, not temporary, and requires an active response — either renegotiating scope or moving to a role with a cleaner analytical mandate.\\n\\nGiven your DC DiSC pattern and your preference for established environments, pay attention to whether the firm's leadership culture rewards directness or manages it. Established financial institutions vary significantly on this dimension. You will do your best work — and be most effective in senior rooms — in organizations where a difficult finding delivered clearly is valued, not softened on its way up."}	\N
aa59872d-b94b-4a05-86bd-06ec696eab42	2026-07-02 03:16:59.961202+00	WHY-HOW	Student / Pre-Career	Individual Contributor	chemical engineering	\N	growth	Secondary to mission / fit	DiSC: Si | StrengthsFinder: Activator, Adaptability, Consistency, Includer, Restorative	{"roles": [{"fit": "Process engineering is built on exactly the question you find most energizing: why does this system behave the way it does, and how can it be made to behave better? The core work, diagnosing inefficiencies, redesigning unit operations, and validating improvements against real process data, rewards the kind of deep, purpose-anchored thinking that defines your cognitive orientation.\\n\\nAs you enter this field, you will find that the best process engineers are not just technically fluent, they are genuinely curious about the system as a whole. Your instinct to understand before acting is a structural advantage here, not a liability.", "title": "Process Engineer", "fitLabel": "Strong Fit", "fitScore": 93, "energizing": [{"body": "Tracing a process deviation back to its origin rewards your WHY-HOW wiring directly. You will find this work genuinely absorbing rather than routine.", "label": "Root Cause Analysis"}, {"body": "Building and stress-testing a process model before physical implementation is deep HOW work anchored in a clear WHY. This is where you will do your best thinking.", "label": "Process Modeling and Simulation"}, {"body": "Structuring a rigorous experimental plan to isolate variables and test assumptions suits your precision orientation. The Restorative theme in your StrengthsFinder profile amplifies this naturally.", "label": "Design of Experiments"}, {"body": "Translating a fully understood process into a reliable, repeatable procedure is satisfying work for a WHY-HOW. You care that it is done correctly, not just quickly.", "label": "Technical Documentation and SOPs"}], "strategies": [{"body": "Before each analysis, write one sentence describing what a good-enough answer looks like. This gives you a stopping condition your perfectionism can respect.", "label": "Define 'Complete Enough' Before You Start"}, {"body": "Identify a colleague or mentor energized by implementation and momentum. Let them push your insights into action while you maintain analytical depth.", "label": "Find Your WHAT Partner Early"}, {"body": "Develop a habit of leading with the conclusion and impact, then offering the full technical rationale for those who want it. Your DiSC Si profile means you are already attentive to your audience, use that deliberately.", "label": "Build a Two-Layer Communication Template"}, {"body": "Seek placements where you touch an actual system, not just observe one. Environments that give junior engineers a defined problem to solve will develop your strengths fastest.", "label": "Look for Internships with Real Process Ownership"}], "challenging": [{"body": "Production timelines will push for decisions before your analysis feels complete. This tension is real and will not disappear with experience.", "label": "Pressure to Move Before You Feel Ready"}, {"body": "Frequent check-ins and progress reports pull you away from the deep work where you generate the most value. This coordination overhead is a genuine drain.", "label": "Cross-Functional Status Updates"}, {"body": "The depth of your thinking often exceeds what a plant manager or operations lead needs in the moment. Translating without losing precision is a persistent challenge.", "label": "Communicating Findings to Non-Engineers"}]}, {"fit": "Research science is one of the few environments that structurally protects the kind of thinking you do best. The explicit mandate is to understand something deeply before claiming you know how to act on it. Your WHY-HOW orientation, the need to hold both purpose and mechanism simultaneously, is not just tolerated here, it is the core professional value.\\n\\nAs a chemical engineering student, you are entering with strong preparation for materials science, catalysis, reaction engineering, or process chemistry research. You will find that the lab is one of the few places where your instinct to pursue completeness is rewarded rather than managed.", "title": "Research Scientist", "fitLabel": "Strong Fit", "fitScore": 90, "energizing": [{"body": "Constructing a well-formed hypothesis and the experiment to test it is deeply energizing WHY-HOW work. Your Restorative StrengthsFinder theme makes problem-framing particularly natural.", "label": "Hypothesis Design and Experimental Rigor"}, {"body": "Mapping what is known, what is contested, and what is genuinely unknown in a research area suits your orientation toward comprehensive understanding before action.", "label": "Literature Synthesis"}, {"body": "Running successive experiments, each informed by the last, is the kind of depth-driven iteration that energizes rather than depletes you.", "label": "Iterative Experimental Refinement"}], "strategies": [{"body": "Find an advisor or PI who will hold you to publication and presentation milestones. Externalized deadlines are your most effective antidote to endless refinement.", "label": "Use Your Advisor as a Momentum Partner"}, {"body": "After each experiment, write a one-page plain-language summary before allowing yourself to return to the data. This builds the communication muscle your profile needs.", "label": "Practice the One-Page Summary Habit"}, {"body": "Your values prioritize mission and growth. Research with a visible real-world application, clean energy, drug delivery, sustainable materials, will give your WHY orientation something to anchor to.", "label": "Seek Research with a Clear Application Context"}], "challenging": [{"body": "Academic and industrial research both push toward output on a timeline. The pressure to publish or present before you feel finished is a structural friction point for your profile.", "label": "Publishing and Deployment Pressure"}, {"body": "Presenting findings to non-specialists, or defending work to a committee, requires a translation effort that does not come effortlessly to a HOW-primary thinker.", "label": "Communicating to Cross-Disciplinary Audiences"}]}, {"fit": "Process safety is fundamentally about asking the question most people are too optimistic or too busy to ask: what could go wrong here, and have we actually proven it cannot? That question is native to your cognitive orientation. Your WHY-HOW wiring makes you structurally suited to the kind of exhaustive, consequence-aware analysis that process safety demands.\\n\\nYou are entering a field where thoroughness is not just valued, it is legally and ethically required. The tension between deep analysis and operational timelines exists here as in other engineering roles, but the stakes that justify your pace are far more visible.", "title": "Process Safety Engineer", "fitLabel": "Strong Fit", "fitScore": 87, "energizing": [{"body": "Systematically mapping failure modes across a complex system is energizing HOW work with a clear and serious WHY. This is a rare combination for your profile.", "label": "Hazard Identification and HAZOP Facilitation"}, {"body": "Building a rigorous probabilistic model of failure scenarios suits your depth orientation and rewards comprehensive thinking over speed.", "label": "Fault Tree and Event Tree Analysis"}, {"body": "Understanding why a regulation exists, not just what it requires, is the kind of purpose-anchored precision work your profile finds genuinely engaging.", "label": "Regulatory Research and Standards Interpretation"}], "strategies": [{"body": "Your WHY orientation gives you an instinct for what actually matters. Lead with consequence when communicating risk, it is more persuasive than technical probability alone.", "label": "Anchor Your Analysis in Consequence, Not Just Probability"}, {"body": "A senior PSE who has learned to work with operational pressure without compromising rigor is the most valuable relationship you can build early. Ask specifically how they make that call.", "label": "Find a Mentor Who Has Navigated the Timeline Tension"}, {"body": "Your StrengthsFinder Includer theme gives you a genuine instinct for bringing people in. Use it to build credibility with operations teams before a safety dispute, not during one.", "label": "Use Your Includer Theme to Build Cross-Functional Trust"}], "challenging": [{"body": "Operations and production teams will push for safety sign-off before your analysis feels complete. Holding that boundary professionally is a real challenge for someone early in their career.", "label": "Organizational Pressure to Approve and Move On"}, {"body": "Translating a probabilistic risk analysis into language that influences a plant manager's decision is genuinely hard for HOW-primary thinkers.", "label": "Communicating Risk to Non-Technical Stakeholders"}]}, {"fit": "Environmental engineering connects the technical rigor of chemical engineering to problems that carry genuine systemic consequence: contamination, resource depletion, regulatory compliance, and long-term ecological impact. For a WHY-HOW with values centered on mission and growth, this field offers a rare alignment between technical depth and work that clearly matters beyond the organization.\\n\\nYou will find the diagnostic and systems-thinking aspects of this work energizing. The challenge will be pace, specifically the gap between the depth of analysis you want to produce and the timelines that consulting engagements or regulatory deadlines impose.", "title": "Environmental Engineer", "fitLabel": "Good Fit", "fitScore": 83, "energizing": [{"body": "Mapping how a contaminant moves through soil and groundwater systems is complex, systems-level HOW work anchored in a meaningful WHY.", "label": "Site Characterization and Contaminant Fate Analysis"}, {"body": "Designing a solution to a specific contamination problem, one that must account for site geology, regulatory requirements, and long-term monitoring, is deeply satisfying work for your profile.", "label": "Remediation Design"}, {"body": "Evaluating a proposed project's full environmental footprint before it proceeds is exactly the kind of 'understand before acting' work your WHY-HOW orientation is built for.", "label": "Environmental Impact Assessment"}], "strategies": [{"body": "Some environmental engineering roles are heavily report-writing and compliance-checking. Look explicitly for roles with real investigative or design components.", "label": "Choose Your First Role Based on Depth of Technical Work"}, {"body": "Your StrengthsFinder Consistency theme gives you a natural instinct for fair, repeatable processes. Channel it into a structured personal framework for moving from analysis to recommendation.", "label": "Use Your Consistency Theme to Build Reliable Analytical Habits"}, {"body": "Your compensation priority is mission over pay. Signal that clearly. Firms doing meaningful remediation or sustainability work will value that orientation and give you more of the work you find energizing.", "label": "Connect Explicitly to the Mission in Your Interviews"}], "challenging": [{"body": "Environmental consulting firms bill in hours, which means your instinct to go deeper than required will create genuine tension with project economics early in your career.", "label": "Consulting Pace and Billing Pressure"}, {"body": "Environmental regulations often require professional judgment where you want certainty. Tolerating incomplete regulatory clarity before moving to a recommendation is a real friction point.", "label": "Regulatory Ambiguity"}, {"body": "Translating a complex site assessment into a clear client recommendation, on their timeline, requires the translation skill your profile must work to build deliberately.", "label": "Client Communication and Expectation Management"}]}, {"fit": "Data analysis in a chemical engineering context, whether in manufacturing quality control, R&D, or supply chain, is increasingly central to how engineering decisions get made. Your WHY-HOW orientation suits the investigative core of this work: understanding what the data is actually telling you, not just reporting it.\\n\\nThe conditional nature of this fit is about environment. In a role where analysis is valued for depth and insight, you will thrive. In a role that prioritizes high-volume reporting and dashboard maintenance over real investigation, you will find the work depleting over time.", "title": "Data Analyst", "fitLabel": "Good Fit", "fitScore": 79, "energizing": [{"body": "Investigating a dataset without a predetermined conclusion, looking for what is actually there, is energizing WHY-HOW work that your Restorative theme amplifies.", "label": "Exploratory Data Analysis"}, {"body": "Building a model and then rigorously testing its assumptions against new data is the kind of depth-plus-purpose cycle your profile finds genuinely satisfying.", "label": "Statistical Modeling and Validation"}, {"body": "Using process data to trace a quality or yield problem back to its source is directly energizing for your cognitive orientation.", "label": "Root Cause Investigation Through Data"}], "strategies": [{"body": "Ask specifically what percentage of a typical week involves original analysis versus maintaining existing reports. That ratio will tell you more about fit than the job title.", "label": "In Interviews, Ask About the Ratio of Investigation to Reporting"}, {"body": "Find a colleague who finds it energizing to take your analysis and turn it into action. That partnership will get your work implemented rather than refined indefinitely.", "label": "Pair with Someone Energized by Deployment"}, {"body": "Your StrengthsFinder Adaptability theme gives you a genuine capacity to flex to different team needs. Use it to embed with engineering, operations, and quality teams, building the context that makes your analysis more precise.", "label": "Use Your Adaptability Theme to Stay Useful Across Teams"}], "challenging": [{"body": "High-volume, repeating report generation is a drain for a WHY-HOW. If this becomes the majority of the role, your energy will suffer.", "label": "Routine Reporting and Dashboard Maintenance"}, {"body": "Translating a nuanced statistical finding into a clear operational recommendation is a translation challenge your profile must build deliberately rather than assume will come naturally.", "label": "Communicating Findings to Non-Analytical Stakeholders"}]}, {"fit": "UX research is an unconventional path from chemical engineering, but it is worth surfacing because the cognitive demands map to your profile in ways that are not obvious from the title. The core work is investigation: understanding why people behave the way they do, what they actually need versus what they say they need, and how a system can be redesigned to serve them more completely.\\n\\nThe conditional nature of this fit is industry context. UX research in engineering software, scientific tools, or complex technical systems would leverage your chemical engineering background and your WHY-HOW depth. General consumer UX at a fast-moving company would likely move too quickly for your natural pace.", "title": "UX Researcher", "fitLabel": "Good Fit", "fitScore": 74, "energizing": [{"body": "Structuring an interview protocol or usability study to answer a specific research question is methodologically rigorous work that suits your HOW precision.", "label": "Qualitative Research Design"}, {"body": "Moving from raw interview data to a coherent, defensible insight about user behavior is the kind of depth work your WHY-HOW profile finds genuinely absorbing.", "label": "Synthesis and Insight Generation"}, {"body": "Studying how engineers or scientists use a technical tool brings your domain knowledge directly into play, a rare and valuable combination in UX research.", "label": "Research for Complex Technical Products"}], "strategies": [{"body": "Your chemical engineering background is a genuine differentiator in domains where most UX researchers lack domain fluency. Lead with that in your applications.", "label": "Target Research Roles in Engineering or Scientific Software Companies"}, {"body": "Your most important partnership in a product organization is with a PM who trusts research enough to let it slow a decision down. Evaluate that in your interviews.", "label": "Find a Product Manager Who Values Depth"}, {"body": "Your warmth and attentiveness to others, reinforced by both your DiSC Si profile and your Includer theme, will make research participants genuinely comfortable. That is a real and underrated research skill.", "label": "Use Your Includer and Si DiSC Profile as an Interviewing Asset"}], "challenging": [{"body": "Agile product teams often want research findings in days, not weeks. The pressure to compress your analysis before it feels complete is a real and ongoing friction.", "label": "Fast Product Cycles and Research Compression"}, {"body": "In organizations that prioritize building over learning, making the case for more research time requires a persuasive momentum your profile does not naturally generate.", "label": "Advocating for Research Value to Product Teams"}]}], "nextSteps": ["Before your next informational interview or career fair conversation, write one sentence on why the specific problem this organization is working on matters to you. If you cannot write it, that is useful data about fit.", "Identify one person in your network, a professor, a senior student, an intern alumni, who is energized by moving quickly and shipping. That relationship is structurally more important to your career than any additional technical skill you could develop right now.", "When evaluating internship offers, ask what the ratio of investigation to routine execution looks like in a typical week. The answer will tell you more about whether you will grow than the company brand will.", "Review your StrengthsFinder Restorative and Consistency themes alongside your WHY-HOW profile and identify one type of problem, a specific class of engineering or research challenge, that sits at that intersection. That is your most defensible early-career differentiator."], "watchFors": ["Refining analysis past the point of useful action", "Difficulty committing to a path before the picture feels complete", "Underestimating how much momentum others need from you", "Dense technical communication that loses non-specialist audiences"], "energizers": ["Investigating why a system fails before proposing a fix", "Designing processes with rigor and underlying purpose", "Synthesizing complex technical data into meaningful insight", "Building frameworks that hold up under deep scrutiny", "Connecting molecular-level detail to real-world impact"], "environmentNote": "The signal to look for in any role is whether depth is valued or merely tolerated. In environments that structurally reward thoroughness, your WHY-HOW orientation will produce work of unusual quality. In environments where speed and volume are the primary metrics, you will consistently feel pressure to release work before it is ready, and that friction will not resolve with experience.\\n\\nGiven that your compensation priority is mission and growth over pay, weight your early-career decisions toward organizations where you can see the direct connection between your technical work and a real-world outcome. That visibility will sustain your energy through the steep learning curve of the first two years in a way that compensation alone will not."}	\N
7a13b29f-5376-478e-86c7-8ea2fb930951	2026-07-06 13:58:55.020192+00	WHAT-WHY	Student / Pre-Career	Individual Contributor	pschology	\N	\N	Primary consideration	DiSC: iS | StrengthsFinder: Deliberative, Developer, Maximizer, Relator, Woo	{"roles": [{"fit": "Recruiting is built around the two things that energize you most: moving toward a clear goal and connecting with people in ways that matter. Every search has a destination, every conversation is discovery, and the work rewards your instinct to read what someone needs and meet them there.\\n\\nYour DiSC iS profile and Woo theme mean you will build candidate and hiring manager relationships faster than most. Your Relator and Developer themes add depth, keeping those relationships from feeling transactional. In psychology, you are already learning the frameworks that make you better at this than peers who are not.", "title": "Recruiter", "fitLabel": "Great Fit", "fitScore": 95, "energizing": [{"body": "Uncovering what a candidate actually wants, not just what their resume says, is exactly the kind of goal-oriented conversation your primary orientation is built for.", "label": "Candidate Discovery Conversations"}, {"body": "Each search has a finish line. The drive from intake to close, milestone by milestone, is genuinely energizing for a WHAT-WHY.", "label": "Moving Searches to Offer"}, {"body": "Your Relator and iS combination means you will earn credibility with stakeholders quickly and maintain it in a way that opens doors other recruiters cannot.", "label": "Building Hiring Manager Trust"}, {"body": "Your Developer theme means watching someone land a role they are excited about will feel like a genuine win, not just a closed metric.", "label": "Coaching Candidates Through the Process"}], "strategies": [{"body": "Identify the colleague or coordinator who loves keeping systems clean. That relationship is not optional. It lets you stay in the work that energizes you.", "label": "Find a HOW Partner Early"}, {"body": "Break each search into visible checkpoints. Hitting them will sustain your energy across what can otherwise feel like a long, ambiguous process.", "label": "Set Personal Milestones Per Search"}, {"body": "Frame your academic work in behavioral interviewing, motivation, and assessment literacy when evaluating early opportunities. It is a real edge most peers do not have.", "label": "Use Your Psychology Background as a Differentiator"}, {"body": "In internship and early-role interviews, ask this directly. Environments that answer in outcomes are your environments. Environments that answer in process are a warning.", "label": "Ask What Success Looks Like in 90 Days"}], "challenging": [{"body": "Keeping systems updated and process notes current is HOW work. It will feel like friction against the pace you want to move at.", "label": "ATS and Process Documentation"}, {"body": "When searches multiply, the connective tissue between them, tracking dependencies, managing competing priorities, becomes genuinely draining for this profile.", "label": "High-Volume Requisition Load"}, {"body": "When a hiring manager stalls and momentum stops, you will feel it acutely. The waiting is harder for WHAT-WHY than for most.", "label": "Slow-Moving Hiring Decisions"}]}, {"fit": "An SDR role is essentially a goal-pursuit engine with a people-skills requirement, which maps almost exactly to how you are wired. The work is structured around clear targets, short feedback loops, and constant human connection. Your Woo theme and iS profile mean the cold outreach that drains most early-career professionals will feel more like a puzzle you enjoy solving.\\n\\nYour WHY secondary orientation adds something most SDRs lack: you will naturally qualify whether a prospect's problem is real and whether your solution actually serves it. That instinct protects you from chasing deals that were never going to close.", "title": "Sales Development Representative", "fitLabel": "Great Fit", "fitScore": 91, "energizing": [{"body": "Quota is a finish line. Your primary orientation runs on visible progress toward a clear goal, and SDR metrics deliver that every single week.", "label": "Hitting and Beating a Weekly Target"}, {"body": "Discovery is where your psychology background, Developer theme, and WHAT-WHY wiring converge. You will be better at this than peers who treat it as a script.", "label": "Figuring Out What a Prospect Actually Needs"}, {"body": "Creating something from a cold list into a warm conversation is the kind of momentum-building activity this profile finds genuinely energizing.", "label": "Building Pipeline From Nothing"}], "strategies": [{"body": "Contain the CRM logging to a fixed time. Do not let it bleed into your prospecting hours, where you do your best work.", "label": "Block a Daily 15-Minute Admin Window"}, {"body": "Your StrengthsFinder Deliberative theme is unusual for a WHAT-WHY. Use it to slow down enough to qualify prospects well before investing significant energy.", "label": "Use Your Deliberative Theme as a Qualifier"}, {"body": "Your WHY secondary means you will outperform in roles where the product matters to you. Compensation is higher when you are also bought in on the mission.", "label": "Target Companies Solving Problems You Believe In"}], "challenging": [{"body": "This is non-negotiable in sales ops and genuinely draining for WHAT-WHY. It will require a deliberate system, not just intention.", "label": "CRM Hygiene and Activity Logging"}, {"body": "SDR work can go weeks without a tangible win. Without visible milestones, your energy can dip faster than it would for a HOW-type peer.", "label": "Long Stretches Without a Close"}]}, {"fit": "Account management sits at the intersection of relationship depth and goal pursuit, which is exactly the territory WHAT-WHY navigates best. You will be energized by the ongoing rhythm of working toward renewal and expansion goals with clients you have built genuine trust with over time. Your Relator and iS profile mean those relationships will not feel performative to you or to clients.\\n\\nIn a psychology context, roles in healthcare technology, behavioral health platforms, or employee wellness companies would let you apply your academic background directly, which adds both meaning and marketability to your compensation trajectory early in your career.", "title": "Account Manager", "fitLabel": "Strong Fit", "fitScore": 87, "energizing": [{"body": "Renewals and upsells are clear finish lines. Your primary orientation finds genuine energy in pursuing and hitting them with accounts you know well.", "label": "Driving Renewal and Expansion Goals"}, {"body": "Your Relator and Developer themes mean long-term client relationships are not just comfortable, they are where you will do your distinctively best work.", "label": "Serving as a Client's Trusted Advisor"}, {"body": "Proactive outreach that prevents an issue from becoming a complaint is the kind of momentum-with-purpose play that energizes this profile.", "label": "Solving a Client Problem Before They Ask"}], "strategies": [{"body": "Your psychology background is a credibility asset in these categories. Clients trust you faster, and compensation reflects the domain expertise premium.", "label": "Prioritize Companies With Behavioral Health or Wellness Products"}, {"body": "Find the person who loves building the trackers and documentation frameworks you will deprioritize. Lean on them structurally, not just occasionally.", "label": "Partner With a Customer Success Operations Colleague"}, {"body": "Do not wait for a manager to define your milestones. Setting your own visible checkpoints keeps your energy engaged between formal review cycles.", "label": "Set Your Own 30-60-90 Day Account Targets"}], "challenging": [{"body": "Strategic account plans require the kind of structured, detailed HOW thinking that will feel like overhead rather than work to you.", "label": "Account Planning Documentation"}, {"body": "When account volume grows, the interdependencies and detail tracking required to manage them all becomes a real drain on this profile.", "label": "Managing a Large Portfolio Simultaneously"}, {"body": "When a client issue requires coordination across internal teams without a clear owner, the lack of forward momentum will be genuinely frustrating.", "label": "Escalations That Stall"}]}, {"fit": "An HR Generalist role gives you early exposure to the full range of people-related work in an organization, and the most energizing parts of it map well to your profile. Interviewing candidates, onboarding new employees, facilitating conversations between managers and direct reports, and working toward headcount goals are all WHAT-WHY territory. Your psychology background is a genuine advantage here.\\n\\nThe challenge is that HR Generalist roles also carry meaningful HOW load. Benefits administration, compliance tracking, HRIS data entry, and policy documentation are real parts of early-career HR work. This profile can thrive here, but only with clear structural support for the process-heavy side of the role.", "title": "Human Resources Generalist", "fitLabel": "Good Fit", "fitScore": 82, "energizing": [{"body": "Your psychology training and Developer theme make the interview process genuinely interesting to you, not just a procedural step.", "label": "Behavioral Interviewing and Candidate Assessment"}, {"body": "Getting someone oriented and confident in their first weeks is a meaningful, milestone-driven task that fits how you are wired.", "label": "New Employee Onboarding"}, {"body": "Your Relator and iS combination means people will open up to you quickly, making you effective in the one-on-one coaching moments that define good HR.", "label": "Manager and Employee Coaching Conversations"}], "strategies": [{"body": "If a team has a dedicated HR coordinator or ops specialist, the HOW load on you is manageable. If it does not, you are the ops specialist. Know this before you accept.", "label": "Ask About the HR Operations Support Structure Before Accepting"}, {"body": "Volunteer to own behavioral interview design and debrief facilitation early. It is high-value, energizing, and positions you well for advancement.", "label": "Build Your Credibility Through the Interviewing Work"}, {"body": "Convert administrative obligations into a structured timeline so they become discrete, completable tasks rather than ongoing ambient pressure.", "label": "Create a Compliance Calendar With Hard Deadlines"}], "challenging": [{"body": "Tracking enrollment windows, audit requirements, and policy updates is sustained HOW work. It will be the part of the role that consistently drains you.", "label": "Benefits and Compliance Administration"}, {"body": "Accurate and current data entry into HR systems matters and will not feel important to you. This gap needs a mitigation plan from day one.", "label": "HRIS Data Management"}]}, {"fit": "Case management in behavioral health aligns with your WHY secondary orientation more directly than most early-career roles, and the goal-oriented structure of caseload management gives your primary orientation something real to run on. Each client represents a clear objective: connecting them to the right resources, removing barriers, and moving their situation forward. Your Relator and Developer themes will make you exceptional at the trust-building this work requires.\\n\\nThis is a conditional fit. The documentation burden in case management is significant, and the pace of change in clients' situations is often slower than this profile finds comfortable. Compensation in this sector also starts lower, which matters given your stated priority.", "title": "Mental Health Case Manager", "fitLabel": "Good Fit", "fitScore": 78, "energizing": [{"body": "Building a specific, actionable path forward with someone is exactly the kind of goal-pursuit work this profile finds meaningful and energizing.", "label": "Developing a Care Plan With a Client"}, {"body": "Finding and activating the right resource for a specific person's situation is a milestone-driven problem your profile is built to enjoy.", "label": "Connecting Clients to Resources"}, {"body": "Your Developer theme means client progress will be genuinely motivating, not just professionally satisfying.", "label": "Watching Someone Move Forward"}], "strategies": [{"body": "Hospital systems, insurance companies, and managed care organizations hire case managers at meaningfully higher compensation than community nonprofits, with more structural support.", "label": "Target Healthcare System or Managed Care Settings Over Nonprofits"}, {"body": "In your first week, establish a fixed daily window for notes. Do not rely on catching up. The administrative debt compounds faster in case management than in almost any other role.", "label": "Build a Documentation Routine Before You Need One"}, {"body": "Define a visible, specific next step with every active client. Those small finish lines sustain your energy through the stretches where progress is hard to see.", "label": "Use Client Milestones as Your Energy Anchor"}], "challenging": [{"body": "Detailed, consistent documentation is clinically and legally required in this field. It will be a persistent drain and requires a structured daily habit to manage.", "label": "Case Documentation and Progress Notes"}, {"body": "When a client's situation does not move for weeks or months, this profile will feel it as frustration in a way that can affect energy across the full caseload.", "label": "Slow or Stalled Client Progress"}, {"body": "Nonprofit and community mental health settings are meaningful environments but often have compressed salary bands. This tension with your compensation priority should be evaluated carefully.", "label": "Compensation Ceiling in Community Settings"}]}, {"fit": "Market research is a conditional fit for WHAT-WHY, and it is worth including here because a psychology background is a genuine asset in qualitative and consumer research methods. Your ability to read what people mean beneath what they say, built from both your academic training and your Relator and Woo themes, gives you an edge in research design and insight synthesis that pure business majors often lack.\\n\\nThe honest friction is that research roles carry more sustained HOW load than this profile finds energizing. Data collection, analysis, and report writing require the kind of precision-oriented sustained focus that is the tertiary drain for WHAT-WHY. This role works best as a stepping stone or a hybrid role with a clear deliverable and external-facing component.", "title": "Market Research Analyst", "fitLabel": "Good Fit", "fitScore": 74, "energizing": [{"body": "Facilitating conversations to uncover what people actually think and feel is where your psychology training, iS profile, and Relator theme all converge.", "label": "Qualitative Interviews and Focus Groups"}, {"body": "Translating research into a compelling story for a decision-making audience is the kind of goal-with-a-finish-line work this profile does well.", "label": "Presenting Findings to Stakeholders"}, {"body": "When your research directly shapes what a company does next, the link between your work and forward movement is visible and energizing.", "label": "Connecting Consumer Insight to a Business Decision"}], "strategies": [{"body": "Consumer insights, user research, and ethnographic research roles skew toward the HOW load you can tolerate. Pure data analytics roles do not.", "label": "Target Roles That Emphasize Qualitative Over Quantitative Work"}, {"body": "In any team, identify the person who finds data cleaning satisfying. Offering to own the stakeholder presentation in exchange for support on analysis is a genuine trade, not a shortcut.", "label": "Partner With a Quantitative Analyst on Analysis-Heavy Projects"}, {"body": "Market research builds credibility and business fluency that opens doors in product, strategy, and consulting. Evaluate it on that basis, not just on daily energy.", "label": "Frame This Role as a Two-Year Bridge, Not a Destination"}], "challenging": [{"body": "The sustained, detail-intensive work of preparing and analyzing survey data is HOW-dominant work that will drain this profile consistently.", "label": "Quantitative Data Cleaning and Analysis"}, {"body": "Long research reports with extensive methodology sections and caveated findings require exactly the kind of precision attention that is tertiary for WHAT-WHY.", "label": "Report Writing With Granular Detail"}]}], "nextSteps": ["Before your next informational interview, write one sentence on what problem this organization is trying to solve and whether you believe it matters. If you cannot write it, that is useful data about fit.", "Identify one person in your network or program who is energized by detailed process work and documentation. Start building that relationship now. That partnership will matter more in your first role than almost any technical skill.", "When evaluating internship or job offers, ask directly: what does success look like in the first 90 days, and how is it measured? Answers framed in outcomes are your environments. Answers framed in process adherence are a warning.", "Research compensation ranges on Levels.fyi, Glassdoor, and LinkedIn Salary for the roles in this report before your first negotiation. Your WHAT-WHY profile means you will be tempted to accept an offer and start moving. Slow down enough to negotiate. The Deliberative theme in your StrengthsFinder profile is an asset here. Use it."], "watchFors": ["Roles requiring detailed documentation or process ownership", "Environments that reward thoroughness over forward motion", "Granular task tracking mistaken for real progress", "Execution complexity that outpaces your current visibility"], "energizers": ["Rallying others around a compelling shared goal", "Discovery conversations that reveal what someone truly needs", "Moving a stuck situation toward a clear next step", "Roles where your energy visibly changes the room", "Work that connects momentum to meaningful outcomes"], "environmentNote": "The signal to look for in any environment is whether forward momentum is recognized and rewarded. Organizations that celebrate hitting a goal, closing a deal, or moving a client situation forward will match how you are wired. Environments that primarily reward thoroughness, process compliance, or documentation quality will create a persistent mismatch between your energy and what gets recognized.\\n\\nBecause your compensation is a primary consideration, prioritize industries where psychology-adjacent skills command a premium: healthcare technology, talent acquisition, enterprise software, and managed care all pay meaningfully more than nonprofit or public sector roles that draw from the same academic background. The work can still be meaningful in those higher-paying environments. You do not have to choose."}	\N
\.


--
-- Data for Name: client_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_accounts (id, name, slug, notes, restrict_results, created_at, tier) FROM stdin;
2a082267-e1e6-47b7-98bb-20b8915a0db7	Raymond Kearney	raymondckearney-mrcsmit2	Self-serve purchase: cs_test_a18Y2Lh3Bl5kK4ZnCnz3FmfornkgoWhi7b9VcBhydqSOyFvriBDqj29LOR	f	2026-07-09 00:53:27.39023+00	premium
fafc5b22-9492-444d-8b52-13bdb884e267	Ava	avayoungmckula-mre0xthj	Self-serve signup	f	2026-07-09 21:33:57.565479+00	basic
d95df7d1-17a1-4702-9bb6-fe071b3ea207	Troy Nielson	troy-nielson-mrnyr803	Admin invite	f	2026-07-16 20:30:32.321191+00	premium
a9962f52-d3ca-4ce9-817b-f5e4bb281012	Kait	katehollis18-mrp96ada	Self-serve signup	f	2026-07-17 18:09:57.543932+00	premium
6f9fa02f-2aef-4c8a-835d-96f5859b8cef	Test Owner	test-analytics-1784336192085-mrpnp6nm	Self-serve signup	f	2026-07-18 00:56:34.369301+00	basic
0fc540e0-ef6c-4ce1-b856-2306eb0ad7f4	Shanna	shannayee13-mru9nbjp	Self-serve signup	f	2026-07-21 06:22:03.099074+00	basic
122222cc-b996-475e-ba8c-1e3b437a0be0	RAY TEST	raymondckearney-mshmcelt	Self-serve signup	f	2026-08-06 14:36:10.924192+00	basic
9cde52d9-3e70-4947-b375-a30b4e66bdbd	Wade Forst	wadeforst-msm1me4t	Google sign-up	f	2026-08-09 16:54:55.795682+00	basic
017b98da-fcf8-499f-901f-2d30d006db33	Wade	wade-msm1nnxv	Self-serve signup	f	2026-08-09 16:55:55.198593+00	premium
4a71ad09-aa7b-4f27-b69b-e5765163ad64	Linda Mann	linda-mann444-msoyr3ph	Admin invite	f	2026-08-11 17:57:55.255064+00	premium
\.


--
-- Data for Name: client_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_users (id, account_id, email, name, password_hash, role, created_at, last_login_at, provider, provider_id) FROM stdin;
c1d54e2f-3b97-4669-b112-f8437fc8c2be	d95df7d1-17a1-4702-9bb6-fe071b3ea207	troy_nielson@byu.edu	Troy Nielson	d3679809a08b6d2115e699efc42b1285:09efea3f7aa92448e9bdfb163b56ecd0a03f372de2344506b22baedc20f94b607c6741d4cf87ad69cd04b8bf02fdab9fc364ee27f6c7da87a77de5fb4088c0e9	owner	2026-07-16 20:30:32.471811+00	\N	email	\N
0454416c-46eb-4faf-a711-f95d1b69bda2	a9962f52-d3ca-4ce9-817b-f5e4bb281012	katehollis18@gmail.com	Kait	5914ec2a28147e097e7552a5fc78c2a7:d9ef9f890e492cc212d1bdef2fb28d880b131aa49210ee65c32e6b9381c239bd98651d28caef40c7bc5b9009090c62e6d604ec38596c322fae5b7f98f7a2bb45	owner	2026-07-17 18:09:57.708749+00	\N	email	\N
b706e007-8fae-479e-8a3b-afcfe1b8b588	122222cc-b996-475e-ba8c-1e3b437a0be0	raymondckearney@cloud.com	RAY TEST	bf7f16a75f6e9c1dbcebdc6dc85bfc0c:2e4d38dd6e3b5e7f576d6ce8c7f8b383bc1bc52bdaf948bb717c66722f94eb4156e7307f03c3ff6627dad83b32f32bc2dfe295fe6ffc6e7c046a8979d74c0368	owner	2026-08-06 14:36:11.078954+00	\N	email	\N
8beaa79d-7fe6-4dc4-b488-389645c09eb6	6f9fa02f-2aef-4c8a-835d-96f5859b8cef	test-analytics-1784336192085@example.com	Test Owner	114f351298d48412a042d209d33ce19e:b2370e260300e0f04a25f86daef0a6e1498174e20f0767f1549dd13c2b2c8c756fcd4ad0e49865b6c6db4cea61f07b23e55526cea6838fcc0629dd33f2769315	owner	2026-07-18 00:56:34.5345+00	\N	email	\N
e22a4d7e-80b3-458e-aebe-57a5d4b55dd3	fafc5b22-9492-444d-8b52-13bdb884e267	avayoungmckula@gmail.com	Ava	172c841eeda04c912618d1f4d0f2f327:40aebd6aac53684e94631077ae1cf33ce8e40c049ba98f99f35437277a4c1565ee0d14468acd190c476cfe03965b18ed4855c7a2ebae4a99ebf9fa6f2aff2012	member	2026-07-09 21:33:57.69449+00	\N	email	\N
0fcb6701-6ebf-43b2-a97c-c5d472508c0f	2a082267-e1e6-47b7-98bb-20b8915a0db7	raymondckearney@gmail.com	Raymond Kearney	3b8917cc2573be8287f7f0d005c63344:f9dde5c7618d50a1bfd7aea7883fc03b8fa05a7613eb619cdc1257839782b335a18c1a7e6cab9b726a471dcfac6afc3e78d0332288b4e0d36c7668839cd8ac61	owner	2026-07-09 00:53:27.504108+00	2026-08-07 04:14:27.588+00	email	\N
fd175764-e580-49d7-a6c3-ed815de45d6e	017b98da-fcf8-499f-901f-2d30d006db33	wade@wadeforst.com	Wade	ab077491249de2453ae2a0972c0339e6:651a41c9731213e7aaf6b881b373c0e3c0f65f549afa5ab846888535e21740a8c7ebe883addadbef1962deedfed2e5b9ff3bad09c842c336fa1225ef09dd7f6d	owner	2026-08-09 16:55:55.486999+00	\N	email	\N
05e48bb1-c955-419d-acb9-6f57fc7df45f	4a71ad09-aa7b-4f27-b69b-e5765163ad64	linda.mann444@gmail.com	Linda Mann	917e689e6bfa87cd92085148e1d32e34:8001096a26941ade5ce78c2a3693887fa67f3be59adbe8ec382f9b7aeb434cc2df196c4ab173672e822a5d8e9685fc8671f5b3dc1d494ad7e6b29d5ed098b050	owner	2026-08-11 17:57:55.41187+00	\N	email	\N
d25556f2-04e4-4604-92de-5cd8a8d4db70	0fc540e0-ef6c-4ce1-b856-2306eb0ad7f4	shannayee13@gmail.com	Shanna	23aad5a180d90d6444c24f3db6d5f133:11693f250c497e20dc2311046ef4737417c31c3e29bb1f86803cbb2276c30cc1da77d9bfe327a0a8e54a61cab6579c0a91c3b0774d98e53e7577bb7d7bc8adc9	member	2026-07-21 06:22:03.232071+00	\N	email	\N
ff56ad70-4131-44e0-8717-726bc1cbe6fc	2a082267-e1e6-47b7-98bb-20b8915a0db7	raymondckearney@icloud.com	TEST Ray	b12594c9062586fbe3485bb78e330b6b:85d97c5a18dde382b1b3d700074cd1a7addbf28b40ab1ece351eadb40654d30dbf73cae9c7f7602574b44d511875cdbba2f62eb004cb1ab19a676a567053ab55	member	2026-08-11 19:47:38.242173+00	\N	email	\N
\.


--
-- Data for Name: detection_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detection_feedback (id, user_id, created_at, text_hash, own_writing, context, hypothesis_raw, actual_profile, sample_text) FROM stdin;
\.


--
-- Data for Name: fit_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fit_results (id, account_id, user_id, participant_name, profile_type, role, score, demand_split, result_payload, created_at) FROM stdin;
\.


--
-- Data for Name: library_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_items (id, tool_num, collection, title, support_mode, onepager_path, kit_path, created_at, summary, item_type, profile) FROM stdin;
f044b890-d0ca-47e0-a368-99b1b9343c05	2	A	The Pre-Flight Checklist Library	Replace	A/tool-02-onepager.pdf	A/tool-02-kit.pdf	2026-07-09 01:56:27.447893+00	Reusable completeness checklists for the deliverables you produce again and again. Completeness stops depending on memory, the checklist holds the details so you don't have to.	tool	\N
0ff05f36-ba3b-48b6-b2d1-f01530d4d63e	3	A	The Last 10% Protocol	Scaffold	A/tool-03-onepager.pdf	A/tool-03-kit.pdf	2026-07-09 01:56:27.902292+00	A defined closing ritual for any deliverable. The hardest part of finishing becomes a checklist, not a judgment call, run in one pass before anything ships.	tool	\N
841ca58b-a0cb-4779-ad65-02376573ad9e	4	A	The Detail Debt Log	Support	A/tool-04-onepager.pdf	A/tool-04-kit.pdf	2026-07-09 01:56:28.325038+00	A running capture list for details consciously deferred in the moment, reviewed on a fixed weekly rhythm. Deferring stops turning into dropping.	tool	\N
fa869506-b2ee-479f-8407-503113bd737e	5	A	Timeboxed Detail Sprints	Support	A/tool-05-onepager.pdf	A/tool-05-kit.pdf	2026-07-09 01:56:28.741948+00	A method for batching detail work into short, scheduled, high-energy blocks. The drain gets contained to windows you chose, instead of leaking across the whole week.	tool	\N
9069bafd-02f1-45da-aa13-8aa33e3f4796	6	A	The Edge-Case Question Bank	Scaffold	A/tool-06-onepager.pdf	A/tool-06-kit.pdf	2026-07-09 01:56:29.203726+00	A printed set of boundary-testing questions to run against any plan. You borrow the signature question of the HOW orientation as a tool, without needing the instinct behind it.	tool	\N
a12cacd5-6a6f-4d82-ac15-d7c3642d2b3e	7	A	Definition-of-Done Cards	Scaffold	A/tool-07-onepager.pdf	A/tool-07-kit.pdf	2026-07-09 01:56:29.649286+00	A card completed at the start of any piece of work that specifies, objectively, what finished means. Done becomes a fact, not a feeling.	tool	\N
6da8e60b-7767-4dfa-bd65-d978a8bdb261	8	A	The Effort Reality-Check	Scaffold	A/tool-08-onepager.pdf	A/tool-08-kit.pdf	2026-07-09 01:56:30.095809+00	A structured correction for the chronic underestimation of execution effort. The estimate gets built from tasks and history, not from optimism.	tool	\N
9e536084-c1cc-41a9-9f21-e2a3c4f31d77	9	A	The AI Precision Companion	Replace	A/tool-09-onepager.pdf	A/tool-09-kit.pdf	2026-07-09 01:56:30.573635+00	A curated prompt pack for delegating precision work to AI: decomposition, checklists, gap reviews, edge cases. The detail thinking gets generated for you, and you stay the judge.	tool	\N
9559aae6-faa2-46d8-a5fa-7181ed609cfd	10	A	The HOW-Partner Review Protocol	Replace	A/tool-10-onepager.pdf	A/tool-10-kit.pdf	2026-07-09 01:56:31.015196+00	A structured way to request a precision review from a HOW-primary colleague. The right partner completes the work, and the protocol makes asking cheap for you and answering easy for them.	tool	\N
fdba777b-1cf2-41ef-a255-95df3a5740ec	11	B	The Good-Enough Threshold	Scaffold	B/tool-11-onepager.pdf	B/tool-11-kit.pdf	2026-07-09 01:56:31.541375+00	A worksheet that defines the shipping criteria before work begins. Done becomes a pre-commitment, not an in-the-moment fight against the pull of one more improvement.	tool	\N
b41f9c90-7aa4-4661-b073-44341bea23ad	12	B	The Closing Card	Scaffold	B/tool-12-onepager.pdf	B/tool-12-kit.pdf	2026-07-09 01:56:32.002492+00	An end-of-meeting forcing function: one action, one owner, one date, written before anyone leaves. No conversation ends without becoming movement.	tool	\N
94c59343-ff62-43f5-8199-31b881b1752f	15	B	Milestone Backplanning	Scaffold	B/tool-15-onepager.pdf	B/tool-15-kit.pdf	2026-07-09 01:56:33.300371+00	A template that converts a deep understanding of the work into dated milestones, built backward from the end. The system view becomes a schedule.	tool	\N
65d02570-7f55-4acd-84b7-9c7cd3cb8d55	17	B	The Momentum Board	Support	B/tool-17-onepager.pdf	B/tool-17-kit.pdf	2026-07-09 01:56:34.245959+00	A dead-simple visible tracker of movement, three columns, updated weekly. It externalizes the progress sense your wiring doesn't generate internally.	tool	\N
6f5d98eb-96ab-475f-9b40-0a9ab78eb07d	19	B	The 48-Hour Draft Rule	Teach	B/tool-19-onepager.pdf	B/tool-19-kit.pdf	2026-07-09 01:56:35.273112+00	A protocol: any new deliverable produces a shareable rough draft within forty-eight hours. Refinement comes after contact, not before.	tool	\N
b3196c90-415b-440a-8115-4be799c5de17	22	C	The North Star One-Pager	Replace	C/tool-22-onepager.pdf	C/tool-22-kit.pdf	2026-07-09 01:56:36.609454+00	The purpose of a project, captured once, usually extracted from the person who holds it, and kept visible for its whole life. The why never has to be regenerated mid-flight.	tool	\N
6909e002-7d60-4444-a2fa-24ede04c9070	24	C	The So-What Translator	Scaffold	C/tool-24-onepager.pdf	C/tool-24-kit.pdf	2026-07-09 01:56:37.48036+00	A template that converts detailed output into audience meaning. For every section, one completed sentence: "which means that..." The reader gets significance without you having to feel it first.	tool	\N
5c15f7e0-c2c2-4f0c-9ed6-f0782c2b27f0	26	C	The Quarterly Altitude Check	Support	C/tool-26-onepager.pdf	C/tool-26-kit.pdf	2026-07-09 01:56:38.400181+00	A scheduled, structured zoom-out: ninety minutes, four questions, once a quarter. Perspective becomes an appointment instead of an instinct you have to summon.	tool	\N
b35a4ee6-c5d0-4693-9387-4af8709cea2d	28	C	The Narrative Arc Template	Scaffold	C/tool-28-onepager.pdf	C/tool-28-kit.pdf	2026-07-09 01:56:39.347549+00	A five-beat structure that converts detail-rich content into a meaning-led story. The narrative is assembled, not inspired, from material you already have.	tool	\N
9bcde888-b12f-496a-87ec-95967e8c5845	31	D	The Energy Budget Planner	Support	D/tool-31-onepager.pdf	D/tool-31-kit.pdf	2026-07-09 01:56:40.561391+00	A weekly calendar audit that tags work by orientation and rebuilds the schedule around your energy. Tertiary work gets placed at peak hours, in limited doses, with recovery adjacent.	tool	\N
4e47cd75-88a5-4dc8-a7ec-2a1954d7bad1	33	D	The Team Trade Board	Replace	D/tool-33-onepager.pdf	D/tool-33-kit.pdf	2026-07-09 01:56:41.371533+00	A team ritual for openly trading work out of tertiaries and into primaries. Under the energy model, a trade is not a favor exchange, it is a net energy gain on both sides.	tool	\N
4e4cfb49-99ab-4e4a-93d3-2fdcac829d01	36	E	The Three-Question Kickoff	Scaffold	E/tool-36-onepager.pdf	E/tool-36-kit.pdf	2026-07-09 01:56:42.664741+00	A project kickoff protocol requiring the why, the what, and the how each be answered before work starts. Ten minutes that prevents the three classic mid-project stalls.	tool	\N
121dc36c-abba-4c80-a0a9-6f5dcd7a81a3	38	E	The Friction Forecast	Teach	E/tool-38-onepager.pdf	E/tool-38-kit.pdf	2026-07-09 01:56:43.486793+00	A guide to the predictable friction between orientations, readable from the team map. What looks like a personality clash is usually orientation friction, and friction you can forecast, you can design around.	tool	\N
0791f7be-dadf-49ff-b7b8-5b671a8bae3a	40	E	The Mixed-Audience Deck Structure	Scaffold	E/tool-40-onepager.pdf	E/tool-40-kit.pdf	2026-07-09 01:56:44.363148+00	A presentation architecture for rooms that contain all three orientations. Each wiring hears what it needs to say yes, in the order that keeps everyone in the room.	tool	\N
7a446ce6-12fc-4e01-ac45-724a03439a66	43	E	The Team Energy Audit	Support	E/tool-43-onepager.pdf	E/tool-43-kit.pdf	2026-07-09 01:56:45.656278+00	A quarterly team ritual mapping who is spending sustained time in their tertiary, and why. Structural drain becomes a team agenda item instead of a private endurance test.	tool	\N
30fe5414-4f4c-4935-962e-c0cd47b05f77	1	A	Vision-to-Task Decomposition	Scaffold	A/tool-01-onepager.pdf	A/tool-01-kit.pdf	2026-07-09 01:56:26.934294+00	A structured worksheet that walks a goal down four levels, from destination to next physical action. Decomposition runs on structure instead of instinct, so nothing depends on a level of detail thinking that drains you.	tool	\N
04844d86-3234-4b3a-83c6-e60aa5f18b74	13	B	The Decision Deadline Ritual	Support	B/tool-13-onepager.pdf	B/tool-13-kit.pdf	2026-07-09 01:56:32.377482+00	A ritual that timeboxes analysis by setting the decision date in advance. When the date arrives, you decide with the information in hand.	tool	\N
06bd3aac-dab0-4cad-ac2c-8415563b7dbe	14	B	The Version 0.5 Reframe	Teach	B/tool-14-onepager.pdf	B/tool-14-kit.pdf	2026-07-09 01:56:32.779699+00	A mental model and a vocabulary for shipping imperfect work as data collection. The early release becomes a method of understanding, which is the register this wiring can genuinely accept.	tool	\N
c52aa2d7-c416-4f52-adb1-0f81fc6260d1	16	B	The WIP Limit Practice	Teach	B/tool-16-onepager.pdf	B/tool-16-kit.pdf	2026-07-09 01:56:33.780718+00	A hard cap on open threads that forces completion before new exploration. Finishing becomes the price of starting, which is the only currency this drain reliably responds to.	tool	\N
69c68342-64f8-4ba1-9c02-c58156100f0e	18	B	The Progress Broadcast	Scaffold	B/tool-18-onepager.pdf	B/tool-18-kit.pdf	2026-07-09 01:56:34.701597+00	A fill-in weekly update format, four lines, five minutes. Communicating momentum stops being a writing task and becomes a form.	tool	\N
b848ded7-4934-4103-808f-55ed4781563f	20	B	The WHAT-Partner Cadence	Replace	B/tool-20-onepager.pdf	B/tool-20-kit.pdf	2026-07-09 01:56:35.76106+00	A structured pairing with a WHAT-primary who owns pace-setting for a defined piece of work. Momentum becomes someone's energizing job instead of your draining one.	tool	\N
7d647a22-de7d-4853-b942-e02f8f77c259	21	C	The Five-Question Purpose Brief	Scaffold	C/tool-21-onepager.pdf	C/tool-21-kit.pdf	2026-07-09 01:56:36.209962+00	A ten-minute structured brief, completed once before any significant piece of work begins. It generates the purpose thinking that would otherwise cost you real energy, and captures it in a form you can reference for the life of the project instead of regenerating it every time someone asks.	tool	\N
fb05f451-488a-4b80-a3fa-75e0306350b5	23	C	The Problem Reframe Deck	Scaffold	C/tool-23-onepager.pdf	C/tool-23-kit.pdf	2026-07-09 01:56:37.043008+00	A card deck of prompts that pressure-test whether the right problem is being solved. The reframing question gets asked by the cards, so it no longer depends on an instinct that drains you.	tool	\N
4bab161f-2cf8-4f02-98b8-99b1affbcbd7	25	C	The Vision Extraction Interview	Replace	C/tool-25-onepager.pdf	C/tool-25-kit.pdf	2026-07-09 01:56:37.923231+00	A structured interview that pulls the vision out of the person who holds it, before execution begins. Purpose gets borrowed from a primary source instead of generated from a drained one.	tool	\N
88a8b06d-145a-4660-b0e2-eefc7c51cdc8	27	C	The Assumption Audit	Scaffold	C/tool-27-onepager.pdf	C/tool-27-kit.pdf	2026-07-09 01:56:38.816751+00	A checklist that surfaces the unexamined premises baked into a plan, before execution effort is invested in them. The beliefs get listed, tested, and owned on purpose.	tool	\N
94425cec-a9f4-4bb6-9bf3-a5238dd5d84e	29	C	The Opening Line Habit	Teach	C/tool-29-onepager.pdf	C/tool-29-kit.pdf	2026-07-09 01:56:39.765849+00	A micro-practice: every email, deck, and deliverable opens with one sentence of purpose before any content. Small, trainable, and disproportionate in effect.	tool	\N
43136da1-7e72-4dba-82cd-319402eba551	30	C	The Pre-Mortem Protocol	Teach	C/tool-30-onepager.pdf	C/tool-30-kit.pdf	2026-07-09 01:56:40.15136+00	A structured session held before launch: it is twelve months from now, and this failed. Working backward from imagined failure gives systematic thinkers a concrete doorway into strategic thinking.	tool	\N
e89d0170-c159-4f72-977a-3517e6e70b1b	32	D	The Tertiary Triage Decision Tree	Teach	D/tool-32-onepager.pdf	D/tool-32-kit.pdf	2026-07-09 01:56:40.98755+00	A repeatable decision path for any draining task: scaffold it, timebox it, trade it, or automate it. White-knuckling stops being the default strategy.	tool	\N
22deea2c-b770-4f59-b2de-d28520286718	34	D	The Drain Signals Field Guide	Teach	D/tool-34-onepager.pdf	D/tool-34-kit.pdf	2026-07-09 01:56:41.83184+00	A guide to recognizing depletion early, in yourself and in teammates. The signals arrive well before the burnout conversation, for those who know what to look for.	tool	\N
1faaf004-5e49-4736-9357-758bdc0a0fd5	35	E	The Orientation-Balanced Agenda	Scaffold	E/tool-35-onepager.pdf	E/tool-35-kit.pdf	2026-07-09 01:56:42.276969+00	A meeting agenda template with a segment that serves each orientation, in a deliberate order. No orientation spends the whole meeting drained, and each contributes from its energy.	tool	\N
6c2c6caf-cfd6-4d8b-bd4b-fdd4c0d7f726	37	E	The Team MindPrint™ Map	Support	E/tool-37-onepager.pdf	E/tool-37-kit.pdf	2026-07-09 01:56:43.037928+00	A one-page visual of the team's profile composition: where energy concentrates, which orientation is uncovered, and whose role is misloaded. The team's wiring, on one page, in the room.	tool	\N
4058bea7-deb9-4bd7-829b-491332fe60b9	39	E	Decision Rights by Orientation	Scaffold	E/tool-39-onepager.pdf	E/tool-39-kit.pdf	2026-07-09 01:56:43.928067+00	A template that assigns the stages of a decision to the people energized by each stage. Decision load gets matched to cognitive wiring, the way task load already should be.	tool	\N
30442a09-958e-4342-a4ae-a3294f44277e	41	E	Meeting Keeper Cards	Support	E/tool-41-onepager.pdf	E/tool-41-kit.pdf	2026-07-09 01:56:44.79267+00	Three rotating meeting roles, purpose keeper, progress keeper, precision keeper, each with a card of licensed interventions. Every orientation's question gets asked, even when its wiring isn't in the room.	tool	\N
de0c879a-8f4c-4d81-b24c-b62b3a0a8a11	42	E	The Handoff Contract	Scaffold	E/tool-42-onepager.pdf	E/tool-42-kit.pdf	2026-07-09 01:56:45.254234+00	A short template completed at any cross-orientation handoff: what the receiver needs that the sender wouldn't naturally include, made explicit in both directions.	tool	\N
387c8fda-7270-4ef7-adc7-297fc5e4edb5	\N	\N	Communication Field Guide	\N	field-guides/Field_Guide_WHY_WHAT.pdf	\N	2026-07-16 01:35:02.299347+00	\N	field_guide	WHY-WHAT
2192a170-b772-4828-a282-affc42c6875a	\N	\N	Communication Field Guide	\N	field-guides/Field_Guide_WHY_HOW.pdf	\N	2026-07-16 01:35:02.299347+00	\N	field_guide	WHY-HOW
86b0db58-78be-40d6-a031-90ba648338bc	\N	\N	Communication Field Guide	\N	field-guides/Field_Guide_WHAT_WHY.pdf	\N	2026-07-16 01:35:02.299347+00	\N	field_guide	WHAT-WHY
a792c3de-7e06-4f0d-b4c1-c92427739328	\N	\N	Communication Field Guide	\N	field-guides/Field_Guide_WHAT_HOW.pdf	\N	2026-07-16 01:35:02.299347+00	\N	field_guide	WHAT-HOW
c66cfb83-d2e1-45ea-9764-87025908dd4c	\N	\N	Communication Field Guide	\N	field-guides/Field_Guide_HOW_WHY.pdf	\N	2026-07-16 01:35:02.299347+00	\N	field_guide	HOW-WHY
ef643868-0d68-400e-8b11-6c8f724fc06d	\N	\N	Communication Field Guide	\N	field-guides/Field_Guide_HOW_WHAT.pdf	\N	2026-07-16 01:35:02.299347+00	\N	field_guide	HOW-WHAT
\.


--
-- Data for Name: mirror_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mirror_tokens (id, token, label, active, created_at, last_used_at, use_count, daily_count, daily_count_date) FROM stdin;
0b5fcfb5-eb7a-4468-8df2-4a401a838ee1	9c487a3d-2924-4854-a408-3a2000846b0b	Ray's Token	t	2026-08-06 01:04:36.327094+00	\N	0	0	\N
6e072a70-ed76-4274-a4a4-ebc8e6723c94	f949cd90-d0c6-4c01-8461-01a751f34554	Kait	t	2026-07-14 14:07:59.918635+00	2026-08-07 01:13:07.261+00	7	2	2026-08-07
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, email, token, expires_at, used, created_at, user_id) FROM stdin;
2ff21456-e55f-4370-8206-de317f844f2d	\N	be1924b6-00c5-420a-ac0e-5bcfdd9ab460	2026-07-23 20:30:32.653+00	t	2026-07-16 20:30:32.683814+00	c1d54e2f-3b97-4669-b112-f8437fc8c2be
b65ce177-9934-4924-bccc-a48b65faf7d3	\N	1a75f913-dadb-479f-a8e0-9cb8290f666f	2026-08-18 17:57:55.546+00	f	2026-08-11 17:57:55.576717+00	05e48bb1-c955-419d-acb9-6f57fc7df45f
0ecdccbe-81dd-4a60-b818-e8ef76382e64	\N	1a471c54-fd75-4bac-9346-89f0d33f60b3	2026-08-18 19:47:38.28+00	f	2026-08-11 19:47:38.322692+00	ff56ad70-4131-44e0-8717-726bc1cbe6fc
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchases (id, stripe_session_id, stripe_payment_intent, product_type, buyer_name, buyer_email, amount_paid, currency, tokens_generated, engagement_id, created_at, notification_sent, confirmation_sent) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tokens (id, token, name, email, purpose, engagement_id, expires_at, used, used_at, result_payload, created_at, company, role, link_sent_at, account_id, granted_tier, profile_sent_at, created_for_name, created_for_email, granted_tools) FROM stdin;
835211bb-1b69-4982-8c1c-ba08143f3715	9970e4ec-5fb9-4dfb-a7b8-86ba50f3a856	Koko	\N	assessment	Linda Cohort	\N	f	\N	\N	2026-07-07 17:21:54.718309+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens,career_guidance}
4fcca3cf-0cbc-490f-a510-1c49db114d8e	f87b1645-ab2c-4f7e-acdb-95d5db7c9ba2	Ava	avayoungmckula@gmail.com	assessment	Linda Cohort	\N	t	2026-07-09 21:33:57.885+00	\N	2026-07-07 13:48:20.689716+00	\N	\N	\N	fafc5b22-9492-444d-8b52-13bdb884e267	basic	\N	Ava	avayoungmckula@gmail.com	{assessment_tokens,career_guidance}
099d1897-c17d-474c-97e1-33c83292725d	9e0f1093-0701-47e3-a53e-f2b5fb0a371a	Spencer	\N	assessment	Linda Cohort	\N	f	\N	\N	2026-07-07 13:48:20.689716+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens,career_guidance}
87ed5f61-7a1b-4ce8-ae1c-011173cdf9cf	f3c79448-0b50-47db-b1ce-f7ef9fe3374d	Zoe	\N	assessment	Linda Cohort	\N	f	\N	\N	2026-07-07 13:48:20.689716+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens,career_guidance}
39ef3c8c-c385-4f4c-a864-cdcd2705045a	2e74803a-8fe0-443f-b4e1-e1f074506e09	Troy Nielson	troy_nielson@byu.edu	assessment	BYU	\N	t	2026-06-23 17:11:03.41+00	{"type": "why-how"}	2026-06-18 20:56:50.091881+00	BYU	Professor	2026-06-18 20:57:23.23+00	d95df7d1-17a1-4702-9bb6-fe071b3ea207	basic	\N	\N	\N	{assessment_tokens}
58290593-b9df-43ae-9368-cadb126b6bc5	ed683c28-b2b6-46dd-a5a4-fc106504d2a3	Kait	katehollis18@gmail.com	assessment	individual-1784311298349	\N	t	2026-07-17 18:09:57.85+00	\N	2026-07-17 18:01:38.51565+00	\N	\N	2026-07-17 18:01:49.86+00	a9962f52-d3ca-4ce9-817b-f5e4bb281012	basic	\N	Kait	katehollis18@gmail.com	{assessment_tokens,role_analyzer,career_guidance}
07ed40ca-9934-465b-a04d-864d96164c23	5227660b-761c-4b61-b39b-7fff96e3c55c	Stuart Gray	stuart.gray@twenty5.com	assessment	Twenty5 Sample	\N	f	\N	\N	2026-06-02 14:16:48.027455+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens}
9155f921-4873-4569-b078-859cabe3a894	22744341-4c7f-4a2c-9244-6124cff6c2db	Matt LeBaron	matt@pocketbk.com	assessment	Lebaron Networking Dinner June	\N	f	\N	\N	2026-06-04 01:53:13.674993+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens}
13908004-13cd-47a5-b56c-5c489d92f156	b9c0d956-5cfd-48c2-932e-01fb0bd8816b	Anuj	\N	assessment	Lebaron Networking Dinner June	\N	f	\N	\N	2026-06-04 01:53:13.674993+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens}
2fb0fd71-8338-47c4-9496-efa2f2fe7cb9	a64b8d52-49ac-4387-9513-19f46ce9ff69	Mahesh Saladi	msaladi@revivetoday.com	assessment	Lebaron Networking Dinner June	\N	f	\N	\N	2026-06-04 01:53:13.674993+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens}
f1496060-c64f-4d23-9a24-63460613a540	e29597ad-e0bd-4f5d-8c2b-2835f4be193d	Yaro	\N	assessment	Lebaron Networking Dinner June	\N	f	\N	\N	2026-06-04 01:53:13.674993+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens}
3256e2d9-d1f6-4cef-9a76-8d63c6536f1a	7cb3eed1-bc18-4731-bcbb-fc4cf9641c47	Lori	\N	assessment	Lebaron Networking Dinner June	\N	f	\N	\N	2026-06-04 01:53:13.674993+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens}
d017f3b0-d790-4071-ace7-508957176ecf	6da22bd3-97e9-4da9-b38d-7c01e7991ccb	Jen Rivera	\N	assessment	Lebaron Networking Dinner June	\N	t	2026-06-05 16:36:46.949+00	{"type": "how-why"}	2026-06-04 01:53:13.674993+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens}
aa2900ad-b23f-4f8b-8be4-adac73d03d89	3db45529-c058-47d9-b79d-e5de4aef6857	Wade	wade@wadeforst.com	assessment	individual-1786042768812	\N	t	2026-08-09 16:55:55.59+00	\N	2026-08-06 18:59:29.811694+00	\N	\N	2026-08-06 18:59:51.815+00	017b98da-fcf8-499f-901f-2d30d006db33	premium	\N	Wade	wade@wadeforst.com	{assessment_tokens,role_analyzer,career_guidance,jd_analyzer,orientation_translator,companion_match,library_match}
58dbe5b8-6521-4c46-9d19-1024c55c9405	57f9c2dc-2fea-4027-a3e1-15364ad9b53c	Monica Althoff	monica.althoff@gmail.com	assessment	Recruiter	\N	t	2026-06-11 17:10:10.834+00	{"type": "what-how"}	2026-06-08 21:10:06.997867+00	\N	\N	2026-06-08 21:15:26.032+00	\N	basic	\N	\N	\N	{assessment_tokens}
6ed3a3d4-5ebb-4ce3-a78c-913867160e98	cf0894a0-8a6d-412e-9c4d-2767705ba4a6	Kari Erickson	kari@kecoaching.com	assessment	Kari	2026-12-31 00:00:00+00	t	2026-06-22 11:22:10.66+00	{"type": "why-how"}	2026-06-16 14:15:56.666606+00	\N	\N	2026-06-16 14:16:18.287+00	\N	basic	\N	\N	\N	{assessment_tokens}
1e10836d-fdd4-4bac-bee7-ce8da989d9b5	60d5f29c-4aea-4a2d-b727-3cc78b5766f6	Betty Kearney	eebkearney@gmail.com	assessment	Mom	2027-06-12 00:00:00+00	t	2026-06-15 19:13:02.604+00	{"type": "why-how"}	2026-06-13 00:25:58.335603+00	\N	\N	2026-06-13 00:26:46.519+00	\N	basic	\N	\N	\N	{assessment_tokens}
f7ee19dd-c188-4ba6-8193-0354c7fc037e	02e89afe-b265-4613-b3a2-3fd866489f7a	Linda Mann	lmann@cortico-x.com	jd	Linda	\N	f	\N	\N	2026-06-18 02:55:25.890359+00	Cortico-x	Strategic Account Leader	2026-06-18 03:04:53.517+00	\N	basic	\N	\N	\N	{assessment_tokens}
91ff2df5-fa62-4d46-b82e-481c6a5b5665	8a92e80e-8863-4337-aeef-62ef22db7f35	Francesca Philips	francesca@scaling.com	assessment	Scaling	\N	t	2026-06-23 16:20:17.008+00	{"type": "why-what"}	2026-06-18 21:00:45.833267+00	Scaling	Strategist	2026-06-18 21:01:05.758+00	\N	basic	\N	\N	\N	{assessment_tokens}
2926b691-e699-43f9-9bf4-2f76864e2979	11eb426b-f4fe-4a16-8863-12600e861e33	Luia	luia.yen@sweetgreen.com	assessment	Sweetgreen	\N	f	\N	\N	2026-07-16 03:47:57.178197+00	\N	\N	2026-07-16 03:48:35.833+00	\N	basic	\N	\N	\N	{assessment_tokens,role_analyzer,jd_analyzer}
e6fd2769-4c84-4d71-9289-297dfd1a10be	92f5bdb5-bc8f-475c-ab3e-aa050355dce4	ray	raymondckearney@gmail.com	assessment	self-serve-1782532282403	2026-09-25 03:51:22.403+00	f	\N	\N	2026-06-27 03:51:22.818814+00	\N	\N	2026-06-27 03:51:22.895+00	2a082267-e1e6-47b7-98bb-20b8915a0db7	basic	\N	Ray	raymondckearney@gmail.com	{assessment_tokens}
9afcba1b-88d9-4a56-83bf-69ac4c83b93b	ede9fe8e-6266-4820-86d7-86734cf10e57		\N	assessment	pool-a9962f52-1784319112754	\N	f	\N	\N	2026-07-17 20:11:52.838379+00	\N	\N	\N	a9962f52-d3ca-4ce9-817b-f5e4bb281012	basic	\N	\N	\N	{assessment_tokens}
961000e5-5102-4a37-8a30-c9ab906d024a	bfa4c392-7b22-4b3b-8e7b-870b66b613e5		\N	assessment	pool-a9962f52-1784319112754	\N	f	\N	\N	2026-07-17 20:11:52.838379+00	\N	\N	\N	a9962f52-d3ca-4ce9-817b-f5e4bb281012	basic	\N	\N	\N	{assessment_tokens}
d2792d09-d50a-4cd4-ad73-075c58ce25e0	30203382-29b9-4247-a735-654226c24737		\N	assessment	pool-a9962f52-1784319112754	\N	f	\N	\N	2026-07-17 20:11:52.838379+00	\N	\N	\N	a9962f52-d3ca-4ce9-817b-f5e4bb281012	basic	\N	\N	\N	{assessment_tokens}
4203df66-e0ac-49cf-a4ac-91c368cdf962	649e567d-2ce6-48a8-b131-2c85be416eac		\N	assessment	pool-a9962f52-1784319112754	\N	f	\N	\N	2026-07-17 20:11:52.838379+00	\N	\N	\N	a9962f52-d3ca-4ce9-817b-f5e4bb281012	basic	\N	\N	\N	{assessment_tokens}
f1c4e9da-8151-4f6b-97eb-9dcc437ab9e2	89327998-620f-4a01-9d0b-a60ad3fe0569	Shanna Yee	shannayee13@gmail.com	assessment	Complimentary	\N	t	2026-07-21 06:22:03.377+00	\N	2026-06-27 19:27:52.595781+00	\N	\N	2026-06-27 19:29:01.497+00	0fc540e0-ef6c-4ce1-b856-2306eb0ad7f4	basic	\N	Shanna	shannayee13@gmail.com	{assessment_tokens}
c03d1e65-74d8-46fc-bc61-c89ea1249475	4055b29b-a4ab-4d44-ad1d-a83880f577f1	Ray TEST	Raymondckearney@icloud.com	assessment	individual-1786021325857	\N	f	\N	\N	2026-08-06 13:02:06.771297+00	\N	\N	\N	\N	basic	\N	\N	\N	{assessment_tokens,role_analyzer}
ff0b9c69-0216-4af2-ac2d-ab025b5c6ccf	08739a52-a6fa-4ddc-829b-94f120c465e3	Linda	linda.mann444@gmail.com	assessment	Linda Cohort	\N	t	2026-08-11 18:03:55.84+00	\N	2026-08-11 17:50:22.815809+00	Cortico-x	Strategic Account Leader / RevOps leader	\N	4a71ad09-aa7b-4f27-b69b-e5765163ad64	basic	\N	\N	\N	{assessment_tokens}
8eb815cb-e984-4af4-a63f-05c8b431acc9	d6374c3d-c46b-476c-ad51-daa1af8b0a9f	ray	raymondckearney@gmail.com	fit	self-serve-1782531258426	2026-09-25 03:34:18.426+00	f	\N	\N	2026-06-27 03:34:19.003613+00	\N	\N	2026-06-27 03:34:19.1+00	2a082267-e1e6-47b7-98bb-20b8915a0db7	basic	\N	\N	\N	{assessment_tokens}
5e6dcd14-c11e-4a34-8d32-a9db27c10ba9	015a3de1-2087-4a35-8dbd-ee7cdd12e331	ray	raymondckearney@gmail.com	fit	self-serve-1782530357982	2026-09-25 03:19:17.982+00	t	2026-06-27 04:58:03.926+00	{"role": "product manager", "type": "WHY-WHAT", "score": 51, "demandSplit": {"how": 30, "why": 30, "what": 40}}	2026-06-27 03:19:18.681247+00	\N	\N	2026-06-27 03:19:18.827+00	2a082267-e1e6-47b7-98bb-20b8915a0db7	basic	\N	\N	\N	{assessment_tokens}
bac4fd47-4284-4c4f-9071-528b2eed5480	518b7183-85fe-405b-b793-6b48fe39659c	ray	raymondckearney@gmail.com	assessment	self-serve-1782531258426	2026-09-25 03:34:18.426+00	f	\N	\N	2026-06-27 03:34:19.003613+00	\N	\N	2026-06-27 03:34:19.1+00	2a082267-e1e6-47b7-98bb-20b8915a0db7	basic	\N	\N	\N	{assessment_tokens}
bac2fccb-d7a1-4eb2-b920-21970c7c5156	087f6214-5529-41a0-82ef-3fc4919b89b7	ray	raymondckearney@gmail.com	assessment	self-serve-1782530357982	2026-09-25 03:19:17.982+00	t	2026-06-27 03:37:14.808+00	{"type": "why-how"}	2026-06-27 03:19:18.681247+00	\N	\N	2026-06-27 03:19:18.827+00	2a082267-e1e6-47b7-98bb-20b8915a0db7	basic	\N	\N	\N	{assessment_tokens}
edf9eec4-4492-4b3e-96f1-f5a38007f18a	0a8d689d-be88-4030-a96d-5d85a8ad4cb0	Wayne	7waynejohnson@gmail.com	assessment	individual-1784223766716	\N	f	\N	\N	2026-07-16 17:42:47.569505+00	\N	\N	2026-07-16 17:43:07.187+00	\N	premium	\N	\N	\N	{assessment_tokens,role_analyzer,career_guidance,jd_analyzer}
478cb8e0-b6d6-4f81-bfc9-ae591488b7e9	4bbdb837-b7ca-46be-99a5-c44676c4f3e2	Raymondckearney@icloud.com	raymondckearney@icloud.com	assessment	TEST	\N	f	\N	\N	2026-08-05 02:13:38.046646+00	\N	\N	2026-08-05 02:14:16.809+00	\N	basic	\N	Ray	raymondckearney@icloud.com	{assessment_tokens}
fe1d8a47-a7a2-4d70-963b-9382a4729e12	697e4fef-1354-475b-a571-44fc6bd2f53d	Al Zayac	Al.Zayac@voya.com	assessment	Voya	\N	f	\N	\N	2026-08-05 18:41:46.953895+00	\N	\N	2026-08-05 18:45:13.42+00	\N	premium	\N	\N	\N	{assessment_tokens,role_analyzer,jd_analyzer,companion_match,library_match,career_guidance,orientation_translator}
10119a5a-5305-4e1d-9cbb-f134a1a94944	ad9b8bbb-2d02-4b5a-a4ef-5e1f93c0e276	Ray Vercel Preview Test	raymondckearney@icloud.com	assessment	ray-native-quiz-preview-test	\N	t	2026-08-06 14:36:11.174+00	\N	2026-08-06 14:20:06.611737+00	Curio	CEO	\N	122222cc-b996-475e-ba8c-1e3b437a0be0	basic	\N	RAY TEST	raymondckearney@icloud.com	{assessment_tokens}
\.


--
-- Data for Name: tool_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool_sessions (id, account_id, user_id, tool, mode, profile, tokens_input, tokens_output, created_at) FROM stdin;
c4583b2f-39a7-4c47-b2e4-e6d31dc83ae6	d95df7d1-17a1-4702-9bb6-fe071b3ea207	c1d54e2f-3b97-4669-b112-f8437fc8c2be	translator	translate	WHY-HOW	2073	379	2026-07-17 16:45:08.668484+00
50a71102-d681-4cda-8ecc-b29aa92fdee5	2a082267-e1e6-47b7-98bb-20b8915a0db7	0fcb6701-6ebf-43b2-a97c-c5d472508c0f	translator	translate	WHY-WHAT	2155	296	2026-07-29 15:29:34.857235+00
8a23199f-9d17-4e15-8486-7de4081bf446	2a082267-e1e6-47b7-98bb-20b8915a0db7	0fcb6701-6ebf-43b2-a97c-c5d472508c0f	translator	translate	WHY-WHAT	2134	293	2026-08-07 04:15:19.439722+00
\.


--
-- Data for Name: writing_samples; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.writing_samples (id, mirror_token_id, sample_text, mirror_output, consented, created_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-05-29 22:09:42
20211116045059	2026-05-29 22:09:42
20211116050929	2026-05-29 22:09:42
20211116051442	2026-05-29 22:09:42
20211116212300	2026-05-29 22:09:42
20211116213355	2026-05-29 22:09:42
20211116213934	2026-05-29 22:09:42
20211116214523	2026-05-29 22:09:42
20211122062447	2026-05-29 22:09:42
20211124070109	2026-05-29 22:09:42
20211202204204	2026-05-29 22:09:42
20211202204605	2026-05-29 22:09:42
20211210212804	2026-05-29 22:09:42
20211228014915	2026-05-29 22:09:42
20220107221237	2026-05-29 22:09:42
20220228202821	2026-05-29 22:09:42
20220312004840	2026-05-29 22:09:42
20220603231003	2026-05-29 22:09:42
20220603232444	2026-05-29 22:09:42
20220615214548	2026-05-29 22:09:43
20220712093339	2026-05-29 22:09:43
20220908172859	2026-05-29 22:09:43
20220916233421	2026-05-29 22:09:43
20230119133233	2026-05-29 22:09:43
20230128025114	2026-05-29 22:09:43
20230128025212	2026-05-29 22:09:43
20230227211149	2026-05-29 22:09:43
20230228184745	2026-05-29 22:09:43
20230308225145	2026-05-29 22:09:43
20230328144023	2026-05-29 22:09:43
20231018144023	2026-05-29 22:09:43
20231204144023	2026-05-29 22:09:43
20231204144024	2026-05-29 22:09:43
20231204144025	2026-05-29 22:09:43
20240108234812	2026-05-29 22:09:43
20240109165339	2026-05-29 22:09:43
20240227174441	2026-05-29 22:09:43
20240311171622	2026-05-29 22:09:43
20240321100241	2026-05-29 22:09:43
20240401105812	2026-05-29 22:09:43
20240418121054	2026-05-29 22:09:43
20240523004032	2026-05-29 22:09:43
20240618124746	2026-05-29 22:09:43
20240801235015	2026-05-29 22:09:43
20240805133720	2026-05-29 22:09:43
20240827160934	2026-05-29 22:09:43
20240919163303	2026-05-29 22:09:43
20240919163305	2026-05-29 22:09:43
20241019105805	2026-05-29 22:09:43
20241030150047	2026-05-29 22:09:43
20241108114728	2026-05-29 22:09:43
20241121104152	2026-05-29 22:09:43
20241130184212	2026-05-29 22:09:43
20241220035512	2026-05-29 22:09:43
20241220123912	2026-05-29 22:09:43
20241224161212	2026-05-29 22:09:43
20250107150512	2026-05-29 22:09:43
20250110162412	2026-05-29 22:09:43
20250123174212	2026-05-29 22:09:43
20250128220012	2026-05-29 22:09:43
20250506224012	2026-05-29 22:09:43
20250523164012	2026-05-29 22:09:43
20250714121412	2026-05-29 22:09:43
20250905041441	2026-05-29 22:09:43
20251103001201	2026-05-29 22:09:43
20251120212548	2026-05-29 22:09:43
20251120215549	2026-05-29 22:09:43
20260218120000	2026-05-29 22:09:43
20260326120000	2026-05-29 22:09:43
20260514120000	2026-07-06 00:07:39
20260527120000	2026-07-06 00:07:39
20260528120000	2026-07-06 00:07:39
20260603120000	2026-07-06 00:07:39
20260605120000	2026-07-06 00:07:39
20260606110000	2026-07-06 00:07:39
20260616120000	2026-07-06 00:07:39
20260624120000	2026-07-06 00:07:39
20260626120000	2026-07-06 00:07:39
20260706120000	2026-07-09 01:35:59
20260707120000	2026-08-05 01:20:22
20260709120000	2026-08-05 01:20:22
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter, selected_columns) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
library	library	\N	2026-07-09 01:29:45.579052+00	2026-07-09 01:29:45.579052+00	f	f	\N	\N	\N	STANDARD
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-05-29 22:09:35.729913
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-05-29 22:09:35.765062
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-05-29 22:09:35.767586
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-05-29 22:09:35.787767
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-05-29 22:09:35.799118
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-05-29 22:09:35.802088
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-05-29 22:09:35.805356
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-05-29 22:09:35.808624
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-05-29 22:09:35.811379
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-05-29 22:09:35.814289
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-05-29 22:09:35.817387
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-05-29 22:09:35.821591
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-05-29 22:09:35.824789
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-05-29 22:09:35.827821
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-05-29 22:09:35.830964
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-05-29 22:09:35.85575
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-05-29 22:09:35.858744
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-05-29 22:09:35.861677
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-05-29 22:09:35.864412
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-05-29 22:09:35.869204
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-05-29 22:09:35.872764
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-05-29 22:09:35.87728
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-05-29 22:09:35.891041
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-05-29 22:09:35.898938
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-05-29 22:09:35.90202
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-05-29 22:09:35.904808
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-05-29 22:09:35.909494
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-05-29 22:09:35.911997
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-05-29 22:09:35.914546
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-05-29 22:09:35.91848
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-05-29 22:09:35.921265
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-05-29 22:09:35.923867
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-05-29 22:09:35.926581
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-05-29 22:09:35.929566
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-05-29 22:09:35.932521
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-05-29 22:09:35.935433
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-05-29 22:09:35.939518
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-05-29 22:09:35.942047
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-05-29 22:09:35.945349
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-05-29 22:09:35.956212
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-05-29 22:09:35.95897
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-05-29 22:09:35.96262
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-05-29 22:09:35.9651
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-05-29 22:09:35.967542
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-05-29 22:09:35.97019
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-05-29 22:09:35.973654
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-05-29 22:09:35.982264
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-05-29 22:09:35.985308
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-05-29 22:09:35.988132
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-05-29 22:09:36.001441
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-05-29 22:09:36.004561
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-05-29 22:09:36.907089
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-05-29 22:09:36.908503
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-05-29 22:09:36.915945
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-05-29 22:09:36.917831
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-05-29 22:09:36.919165
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-05-29 22:09:36.922919
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-05-29 22:09:36.926769
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-05-29 22:09:36.929877
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-29 22:09:36.933155
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-29 22:09:36.936162
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
43c25a91-24b6-48c0-9af2-3b96f5200b8e	library	A/tool-02-onepager.pdf	\N	2026-07-09 01:56:27.36573+00	2026-07-10 15:58:21.796502+00	2026-07-09 01:56:27.36573+00	{"eTag": "\\"73b45a5855dfab4134e34659b33ed40a\\"", "size": 68998, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:22.000Z", "contentLength": 68998, "httpStatusCode": 200}	55c6c509-1716-49a5-bd9a-f73d3c4a25e6	\N	{}
7b20543f-082b-453a-a1ed-43d5b3f669ed	library	A/tool-04-kit.pdf	\N	2026-07-09 01:56:28.054001+00	2026-07-10 15:58:22.778482+00	2026-07-09 01:56:28.054001+00	{"eTag": "\\"153ad2cc0465c176bc5c22a3f272a041\\"", "size": 33464, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:23.000Z", "contentLength": 33464, "httpStatusCode": 200}	7242fadb-9e34-4642-8f56-57ac6cf26c39	\N	{}
b6b2711d-b5ec-4ae5-947f-4ce2e1d6db17	library	A/tool-05-onepager.pdf	\N	2026-07-09 01:56:28.663949+00	2026-07-10 15:58:23.528071+00	2026-07-09 01:56:28.663949+00	{"eTag": "\\"9fe699a5e24af10094291aee874efae3\\"", "size": 70479, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:24.000Z", "contentLength": 70479, "httpStatusCode": 200}	6c75fcfa-b58b-41b6-9222-f67f0a5268a8	\N	{}
5beaa545-6ce6-4515-b224-f061d102ac07	library	A/tool-03-kit.pdf	\N	2026-07-09 01:56:27.590617+00	2026-07-10 15:58:22.17602+00	2026-07-09 01:56:27.590617+00	{"eTag": "\\"ef88e7dd0494e72c88ddc91db44e8e83\\"", "size": 42682, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:23.000Z", "contentLength": 42682, "httpStatusCode": 200}	4682fd83-ebe0-459f-81af-db44e8ebc335	\N	{}
862efc22-3407-4c55-8c79-2e45b5428fbf	library	A/tool-04-onepager.pdf	\N	2026-07-09 01:56:28.236162+00	2026-07-10 15:58:22.999721+00	2026-07-09 01:56:28.236162+00	{"eTag": "\\"cd5743ef96b1d0c23fc17375dec3a278\\"", "size": 71613, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:23.000Z", "contentLength": 71613, "httpStatusCode": 200}	d311a048-2cc3-43d3-9b32-b0dde3e8c2ee	\N	{}
9ffeb9d8-bf62-4e75-8544-48e23421bfe8	library	A/tool-06-kit.pdf	\N	2026-07-09 01:56:28.92139+00	2026-07-10 15:58:23.899319+00	2026-07-09 01:56:28.92139+00	{"eTag": "\\"038f5764bd393b01c17f3ef564de135f\\"", "size": 36665, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:24.000Z", "contentLength": 36665, "httpStatusCode": 200}	642f16d2-b0bc-4ce3-b9ad-5d186495e153	\N	{}
9bf6bbda-1ef1-4f50-8043-05cde937b517	library	A/tool-01-kit.pdf	\N	2026-07-09 01:56:26.538462+00	2026-07-10 15:58:20.32711+00	2026-07-09 01:56:26.538462+00	{"eTag": "\\"4a36b9bf30f51c3ff002435f440f4d16\\"", "size": 48410, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:21.000Z", "contentLength": 48410, "httpStatusCode": 200}	df585cb8-859b-43eb-8d68-348da81e8dee	\N	{}
ca3fd86c-654b-48e5-b52f-bcdb5af3d952	library	A/tool-05-kit.pdf	\N	2026-07-09 01:56:28.473182+00	2026-07-10 15:58:23.283066+00	2026-07-09 01:56:28.473182+00	{"eTag": "\\"4ba375121a4f211ea34781e530fd1f1e\\"", "size": 35258, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:24.000Z", "contentLength": 35258, "httpStatusCode": 200}	54d405e6-e3c7-4bda-b9d9-d5e73899538d	\N	{}
64aa837c-94b7-4367-81d6-90cebd01d030	library	test.txt	\N	2026-07-10 15:57:49.726422+00	2026-07-10 15:57:49.726422+00	2026-07-10 15:57:49.726422+00	{"eTag": "\\"098f6bcd4621d373cade4e832627b4f6\\"", "size": 4, "mimetype": "application/x-www-form-urlencoded", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:57:50.000Z", "contentLength": 4, "httpStatusCode": 200}	b12423b2-99c9-43cc-8bf4-eeed7b0c94ac	\N	{}
13c1372d-be3b-4d42-8347-f08edf7c46a5	library	A/tool-01-onepager.pdf	\N	2026-07-09 01:56:26.772601+00	2026-07-10 15:58:21.129804+00	2026-07-09 01:56:26.772601+00	{"eTag": "\\"dc45c4cd3e862e12e0cfad2cfdc29584\\"", "size": 70398, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:22.000Z", "contentLength": 70398, "httpStatusCode": 200}	5dcc8d4d-ee7d-409b-abe2-9c9ed06539b1	\N	{}
a87cdc80-82e0-48f5-aa37-d1d43f6ec3fb	library	A/tool-03-onepager.pdf	\N	2026-07-09 01:56:27.822236+00	2026-07-10 15:58:22.411935+00	2026-07-09 01:56:27.822236+00	{"eTag": "\\"f0a9af0358bee80be3626a374244e3e8\\"", "size": 72005, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:23.000Z", "contentLength": 72005, "httpStatusCode": 200}	bec64d87-686c-48e9-8cad-31ed880e51f3	\N	{}
b7e811f4-3389-4799-a196-9406cb96bfaa	library	A/tool-02-kit.pdf	\N	2026-07-09 01:56:27.114776+00	2026-07-10 15:58:21.54531+00	2026-07-09 01:56:27.114776+00	{"eTag": "\\"e7ad8fe0b2c4e7be3de4bd6dc68806cf\\"", "size": 45045, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:22.000Z", "contentLength": 45045, "httpStatusCode": 200}	c65ce5e0-6d54-4504-92e2-ddeb7b8841fe	\N	{}
14c7abca-6752-4f0c-99aa-7324e41220e9	library	A/tool-08-kit.pdf	\N	2026-07-09 01:56:29.834281+00	2026-07-10 15:58:25.285263+00	2026-07-09 01:56:29.834281+00	{"eTag": "\\"0247158cd3659ca66bb11a9ab9ac29a0\\"", "size": 44979, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:26.000Z", "contentLength": 44979, "httpStatusCode": 200}	e9bcc06f-40da-4151-8025-d7e278f411a2	\N	{}
6f80a692-34f9-4ce4-9f86-654873f4a539	library	A/tool-09-onepager.pdf	\N	2026-07-09 01:56:30.486889+00	2026-07-10 15:58:26.462386+00	2026-07-09 01:56:30.486889+00	{"eTag": "\\"c40dfbd18f47092df4ea9f47549bf739\\"", "size": 73003, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:27.000Z", "contentLength": 73003, "httpStatusCode": 200}	d025a8a8-d521-4aad-a68e-6f09e2bb2c97	\N	{}
cbc75027-4e79-4331-9956-5222438e46da	library	B/tool-11-kit.pdf	\N	2026-07-09 01:56:31.178772+00	2026-07-10 15:58:27.620415+00	2026-07-09 01:56:31.178772+00	{"eTag": "\\"3977f1278a7504eaa7dc22131eb8d2c2\\"", "size": 37621, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:28.000Z", "contentLength": 37621, "httpStatusCode": 200}	04fb3669-a7c8-4d2a-9df5-1498457f1488	\N	{}
8534fefb-a6ca-411d-9330-9aa7e2c79def	library	A/tool-08-onepager.pdf	\N	2026-07-09 01:56:30.008624+00	2026-07-10 15:58:25.604969+00	2026-07-09 01:56:30.008624+00	{"eTag": "\\"201b6b1018551589aed511d63e710719\\"", "size": 72096, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:26.000Z", "contentLength": 72096, "httpStatusCode": 200}	e746abac-8e0e-4e3f-ae36-9963c401084d	\N	{}
60ffc844-f3dd-45ea-bcfc-be5d9e25a6c5	library	A/tool-10-kit.pdf	\N	2026-07-09 01:56:30.764988+00	2026-07-10 15:58:26.825547+00	2026-07-09 01:56:30.764988+00	{"eTag": "\\"107f60cd5b1c5432ed49c6b3116e2a0f\\"", "size": 45585, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:27.000Z", "contentLength": 45585, "httpStatusCode": 200}	f6e5fff6-58bc-4909-8e23-7f00622f504f	\N	{}
2efe3cd5-9982-4bba-b16d-ca80b4ab014a	library	field-guides/Field_Guide_WHY_WHAT.pdf	\N	2026-07-14 14:48:54.487185+00	2026-07-16 01:35:23.277951+00	2026-07-14 14:48:54.487185+00	{"eTag": "\\"ab9da7bb1b8f7d255aa3795e1dcd0e87\\"", "size": 64404, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-16T01:35:24.000Z", "contentLength": 64404, "httpStatusCode": 200}	6075b2bc-9c31-432f-8a89-4740601c6075	\N	{}
f4a8a6d1-a809-411b-8925-d61f5d4ea22d	library	B/tool-11-onepager.pdf	\N	2026-07-09 01:56:31.445635+00	2026-07-10 15:58:27.897565+00	2026-07-09 01:56:31.445635+00	{"eTag": "\\"a7dbbb573deb31eb838287f303723ed0\\"", "size": 73862, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:28.000Z", "contentLength": 73862, "httpStatusCode": 200}	4a24af04-3fcf-4d7e-80f9-e120e9fab309	\N	{}
2e0a42c9-07ab-4fe5-b73e-5afdf47fa991	library	A/tool-06-onepager.pdf	\N	2026-07-09 01:56:29.121037+00	2026-07-10 15:58:24.175557+00	2026-07-09 01:56:29.121037+00	{"eTag": "\\"cbaef548e25ed77420d62b232df6cdbc\\"", "size": 69705, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:25.000Z", "contentLength": 69705, "httpStatusCode": 200}	19a94c30-c20a-4547-b6ce-fce25b82c7b3	\N	{}
450918f9-1ccb-4306-9a96-2797ea60c610	library	B/tool-12-kit.pdf	\N	2026-07-09 01:56:31.675106+00	2026-07-10 15:58:28.235273+00	2026-07-09 01:56:31.675106+00	{"eTag": "\\"4e71d7735cd7e40493740dffa7121f9d\\"", "size": 62629, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:29.000Z", "contentLength": 62629, "httpStatusCode": 200}	7e5627ef-99f6-4b15-b750-1a83e756d86f	\N	{}
ac908752-f002-462e-b4d5-7f5768004d29	library	A/tool-10-onepager.pdf	\N	2026-07-09 01:56:30.939472+00	2026-07-10 15:58:27.106873+00	2026-07-09 01:56:30.939472+00	{"eTag": "\\"ea88db60db991ed4d2a6e576aa7a8904\\"", "size": 72112, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:28.000Z", "contentLength": 72112, "httpStatusCode": 200}	f38f20a3-a0ad-4a9a-ae97-1f0befedeada	\N	{}
2035f268-460d-45e2-84a8-d19597a0e947	library	A/tool-07-kit.pdf	\N	2026-07-09 01:56:29.353475+00	2026-07-10 15:58:24.620588+00	2026-07-09 01:56:29.353475+00	{"eTag": "\\"efa677e7d7f52b4a71487779869bf582\\"", "size": 37474, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:25.000Z", "contentLength": 37474, "httpStatusCode": 200}	bf45714f-1edb-4c4c-bc6b-58836c32db6a	\N	{}
81e2f7d2-9f38-45a5-978a-fc00a6b28498	library	A/tool-09-kit.pdf	\N	2026-07-09 01:56:30.28989+00	2026-07-10 15:58:26.156061+00	2026-07-09 01:56:30.28989+00	{"eTag": "\\"721e8f0d10d0d8b7b2d17f333458ecbf\\"", "size": 38204, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:27.000Z", "contentLength": 38204, "httpStatusCode": 200}	b0e9d5f6-4d43-4a37-9417-c4d6176f6761	\N	{}
d8d7c128-10fb-4f80-8066-43bd44aa7787	library	A/tool-07-onepager.pdf	\N	2026-07-09 01:56:29.568593+00	2026-07-10 15:58:24.994655+00	2026-07-09 01:56:29.568593+00	{"eTag": "\\"5c301d0b7e2a4177257a818be0e44cdd\\"", "size": 71541, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:25.000Z", "contentLength": 71541, "httpStatusCode": 200}	9cfcce9a-6815-48fb-977f-ab2c6a3cff29	\N	{}
d4a4ab78-bfad-4755-87e3-9d0e3be803f9	library	field-guides/Field_Guide_WHY_HOW.pdf	\N	2026-07-16 01:35:23.771927+00	2026-07-16 01:35:23.771927+00	2026-07-16 01:35:23.771927+00	{"eTag": "\\"2a38347788260aa6312445d267b43e1a\\"", "size": 64371, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-16T01:35:24.000Z", "contentLength": 64371, "httpStatusCode": 200}	b9bed9ce-edef-474a-a01c-7ca5ee1ce39e	\N	{}
ed35e5d9-2f9b-4519-b414-c30a99fbe7b9	library	B/tool-14-kit.pdf	\N	2026-07-09 01:56:32.517707+00	2026-07-10 15:58:30.288097+00	2026-07-09 01:56:32.517707+00	{"eTag": "\\"4f2338ff9a543ff4a506f017181b1091\\"", "size": 35240, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:30.000Z", "contentLength": 35240, "httpStatusCode": 200}	cfb79aed-c5e6-420d-a7ab-7057aed13a63	\N	{}
04dd4c03-6542-4e54-8e1b-2dff00e7fec0	library	B/tool-15-onepager.pdf	\N	2026-07-09 01:56:33.208239+00	2026-07-10 15:58:31.535892+00	2026-07-09 01:56:33.208239+00	{"eTag": "\\"0bbb030fe36217694c0e72a78a25b000\\"", "size": 74315, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:32.000Z", "contentLength": 74315, "httpStatusCode": 200}	dac9a5c9-e9d5-4970-a2e5-c2d52d90bca0	\N	{}
7364a521-34dd-4933-8edd-8f18d49e26c4	library	B/tool-17-kit.pdf	\N	2026-07-09 01:56:33.945923+00	2026-07-10 15:58:32.845602+00	2026-07-09 01:56:33.945923+00	{"eTag": "\\"148f59cee2751c82a5cf2924149302a2\\"", "size": 82842, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:33.000Z", "contentLength": 82842, "httpStatusCode": 200}	d55953b3-3f94-4902-93af-dc07c046bf01	\N	{}
ec8f2c87-f9bf-4753-b0dd-12c2de48c156	library	B/tool-14-onepager.pdf	\N	2026-07-09 01:56:32.692085+00	2026-07-10 15:58:30.93184+00	2026-07-09 01:56:32.692085+00	{"eTag": "\\"5c93fd8133ef4ad0d2db5fbfe505f76e\\"", "size": 69921, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:31.000Z", "contentLength": 69921, "httpStatusCode": 200}	17fd3c6a-3798-4ac4-9f7c-0579464511a3	\N	{}
65524532-069c-4305-8438-ad494517fd33	library	B/tool-16-kit.pdf	\N	2026-07-09 01:56:33.438556+00	2026-07-10 15:58:31.865074+00	2026-07-09 01:56:33.438556+00	{"eTag": "\\"a4ff6c00adf66da8799f6863ba289f0c\\"", "size": 80071, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:32.000Z", "contentLength": 80071, "httpStatusCode": 200}	192e6f36-4d66-4742-9657-559a5bb10972	\N	{}
153c9715-dc0f-4f1f-8051-2dd3f8864a15	library	field-guides/Field_Guide_WHAT_WHY.pdf	\N	2026-07-16 01:35:24.076378+00	2026-07-16 01:35:24.076378+00	2026-07-16 01:35:24.076378+00	{"eTag": "\\"5cde5b8c09e093804435920c52d04923\\"", "size": 66017, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-16T01:35:25.000Z", "contentLength": 66017, "httpStatusCode": 200}	bc2002d2-2f5d-423e-9315-df0052fbf035	\N	{}
1d68f09a-4d51-437b-b4f8-0eb844ebf568	library	B/tool-17-onepager.pdf	\N	2026-07-09 01:56:34.138309+00	2026-07-10 15:58:33.366582+00	2026-07-09 01:56:34.138309+00	{"eTag": "\\"ee9d0c8c1142cf242f421d9404b1cde0\\"", "size": 73743, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:34.000Z", "contentLength": 73743, "httpStatusCode": 200}	dfa001ec-85c6-4e5e-8cf2-c7c0d24359e6	\N	{}
825b9377-826d-42d0-ab66-bea2d0f11578	library	B/tool-12-onepager.pdf	\N	2026-07-09 01:56:31.875652+00	2026-07-10 15:58:28.466137+00	2026-07-09 01:56:31.875652+00	{"eTag": "\\"324db3484ec0a282cd0b3c31196afaf1\\"", "size": 70823, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:29.000Z", "contentLength": 70823, "httpStatusCode": 200}	abe4a3de-29b1-466e-a367-3ea19f700f85	\N	{}
a7363a20-5e44-4ba4-88d4-9f820aa71c21	library	B/tool-18-kit.pdf	\N	2026-07-09 01:56:34.378871+00	2026-07-10 15:58:33.749182+00	2026-07-09 01:56:34.378871+00	{"eTag": "\\"c0fee1860532e2422ae3a9cd90ff7a1a\\"", "size": 34724, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:34.000Z", "contentLength": 34724, "httpStatusCode": 200}	f6bf2845-53bd-4311-b4c9-a1d561be6289	\N	{}
84c3c965-11a6-424d-9938-6e79ce0df4e0	library	field-guides/Field_Guide_WHAT_HOW.pdf	\N	2026-07-16 01:35:24.360163+00	2026-07-16 01:35:24.360163+00	2026-07-16 01:35:24.360163+00	{"eTag": "\\"1d7a483e08411736cc419ff8c0c53951\\"", "size": 66207, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-16T01:35:25.000Z", "contentLength": 66207, "httpStatusCode": 200}	d1a6bfc4-d96a-4724-a453-58227372242b	\N	{}
b0b38d27-f99c-472c-8cb8-b0dcebf3b4ec	library	B/tool-16-onepager.pdf	\N	2026-07-09 01:56:33.669107+00	2026-07-10 15:58:32.405765+00	2026-07-09 01:56:33.669107+00	{"eTag": "\\"7cb936c42e934249031532c3cd09dc8f\\"", "size": 72688, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:33.000Z", "contentLength": 72688, "httpStatusCode": 200}	9bbf1dfd-f6b1-4b95-ba98-265ab4e51213	\N	{}
5d81911e-8a80-4ca8-99e1-5cceed5af133	library	B/tool-13-kit.pdf	\N	2026-07-09 01:56:32.135435+00	2026-07-10 15:58:28.784944+00	2026-07-09 01:56:32.135435+00	{"eTag": "\\"50188f3b03bcc3def96631e433efa8e2\\"", "size": 44696, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:29.000Z", "contentLength": 44696, "httpStatusCode": 200}	11be08f8-d38b-4de0-bf30-28b499b7b5cc	\N	{}
4aa72fdf-8107-4874-a06b-04c6648d7d0a	library	B/tool-15-kit.pdf	\N	2026-07-09 01:56:32.980368+00	2026-07-10 15:58:31.259022+00	2026-07-09 01:56:32.980368+00	{"eTag": "\\"b5b3460f97a97a621d8298151d7f47c7\\"", "size": 46726, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:32.000Z", "contentLength": 46726, "httpStatusCode": 200}	b3a90d99-13b9-4ffe-a16d-7ebec8419bb7	\N	{}
96f4daf1-94ca-4201-9ac9-1c2f97744c29	library	B/tool-13-onepager.pdf	\N	2026-07-09 01:56:32.292575+00	2026-07-10 15:58:29.047153+00	2026-07-09 01:56:32.292575+00	{"eTag": "\\"1ba2197e2d7e15614d2be8c373647636\\"", "size": 73162, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:29.000Z", "contentLength": 73162, "httpStatusCode": 200}	ec86950b-89f9-4e0b-a38d-da0e482b7ff8	\N	{}
f9198a8b-4e6f-4694-8ef4-0b8eafc6b3a5	library	B/tool-19-kit.pdf	\N	2026-07-09 01:56:34.83994+00	2026-07-10 15:58:34.294481+00	2026-07-09 01:56:34.83994+00	{"eTag": "\\"92333406b70b00bc9ea923c291455a20\\"", "size": 36062, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:35.000Z", "contentLength": 36062, "httpStatusCode": 200}	ee574194-347e-4210-becf-6175d43e26ed	\N	{}
e630ef87-fe8e-4e2f-bf10-e1395e152eef	library	C/tool-21-kit.pdf	\N	2026-07-09 01:56:35.882826+00	2026-07-10 15:58:35.380856+00	2026-07-09 01:56:35.882826+00	{"eTag": "\\"dcf870619244a6c462f1b9eccbe6c5b8\\"", "size": 65171, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:36.000Z", "contentLength": 65171, "httpStatusCode": 200}	234951bb-b0b6-4da7-b23c-6eb54d6f288e	\N	{}
1aabe30a-f180-4e02-bda0-f33a721bcc4f	library	C/tool-23-kit.pdf	\N	2026-07-09 01:56:36.75504+00	2026-07-10 15:58:36.588503+00	2026-07-09 01:56:36.75504+00	{"eTag": "\\"ebfc7aa31447a982d2bbafdba9d9ea68\\"", "size": 46804, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:37.000Z", "contentLength": 46804, "httpStatusCode": 200}	4a21c8cb-473e-4844-933c-1bac0578ab22	\N	{}
3bd57cac-83bd-483c-b454-85796c994b9c	library	C/tool-21-onepager.pdf	\N	2026-07-09 01:56:36.129728+00	2026-07-10 15:58:35.631184+00	2026-07-09 01:56:36.129728+00	{"eTag": "\\"fb8ab202d971716a6d48b9de647781e3\\"", "size": 72599, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:36.000Z", "contentLength": 72599, "httpStatusCode": 200}	102cd6b3-6e7b-45d2-8c97-df57d941089f	\N	{}
8e0600d3-76a4-4d2f-b0b1-871c2e99d355	library	C/tool-23-onepager.pdf	\N	2026-07-09 01:56:36.953565+00	2026-07-10 15:58:36.793092+00	2026-07-09 01:56:36.953565+00	{"eTag": "\\"296ea9527174fb0e19c0f1f41ab79b4a\\"", "size": 69623, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:37.000Z", "contentLength": 69623, "httpStatusCode": 200}	3d9904ee-a0d2-48ce-8ff6-287956734994	\N	{}
5f4a70e9-4b18-417f-abde-93ad55d623e1	library	field-guides/Field_Guide_HOW_WHY.pdf	\N	2026-07-16 01:35:24.72499+00	2026-07-16 01:35:24.72499+00	2026-07-16 01:35:24.72499+00	{"eTag": "\\"5ec6a1bda2306cecb5427846f948c20f\\"", "size": 63343, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-16T01:35:25.000Z", "contentLength": 63343, "httpStatusCode": 200}	7107e9cf-f418-4bce-ac9f-6a3ebdd41bd5	\N	{}
6e9aa5d2-56b3-45f8-864a-aa37c89f1e90	library	C/tool-22-kit.pdf	\N	2026-07-09 01:56:36.353718+00	2026-07-10 15:58:35.888835+00	2026-07-09 01:56:36.353718+00	{"eTag": "\\"350dd029648b890080aa53dad20bc9fd\\"", "size": 38489, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:36.000Z", "contentLength": 38489, "httpStatusCode": 200}	3eb5438e-aaf6-463b-a239-fbdbe565140c	\N	{}
880b6d19-8fd8-4bcc-b1d8-08f68d67053e	library	field-guides/Field_Guide_HOW_WHAT.pdf	\N	2026-07-16 01:35:25.036739+00	2026-07-16 01:35:25.036739+00	2026-07-16 01:35:25.036739+00	{"eTag": "\\"4520bb435addc11493bdea8ab8040c6b\\"", "size": 63348, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-16T01:35:25.000Z", "contentLength": 63348, "httpStatusCode": 200}	cbe6ac60-ac2e-40f0-977e-78c28b028b82	\N	{}
452d1e98-de19-40e0-a505-ed0524ea5ff0	library	B/tool-19-onepager.pdf	\N	2026-07-09 01:56:35.115415+00	2026-07-10 15:58:34.538728+00	2026-07-09 01:56:35.115415+00	{"eTag": "\\"9880901f5e74569b50d326959006a2c3\\"", "size": 73727, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:35.000Z", "contentLength": 73727, "httpStatusCode": 200}	1dde7ca9-b1b3-4412-b55c-b4b5a6dc166c	\N	{}
001b6bf0-375f-43a0-acfa-27120bb47e5a	library	B/tool-18-onepager.pdf	\N	2026-07-09 01:56:34.572129+00	2026-07-10 15:58:34.033591+00	2026-07-09 01:56:34.572129+00	{"eTag": "\\"b8abf5e96b5cc8150cc0c6c9d68311b5\\"", "size": 73664, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:34.000Z", "contentLength": 73664, "httpStatusCode": 200}	301b6e5f-1b22-4c0d-bded-710cf8adbe7e	\N	{}
b7b3e709-503e-4db5-80a9-3eba304fec61	library	B/tool-20-kit.pdf	\N	2026-07-09 01:56:35.435643+00	2026-07-10 15:58:34.815797+00	2026-07-09 01:56:35.435643+00	{"eTag": "\\"6daad13d82fe5fdb2d1f4f70fdcd93a9\\"", "size": 43118, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:35.000Z", "contentLength": 43118, "httpStatusCode": 200}	45018a85-07e9-4e01-a69b-d643186645b2	\N	{}
8a9693e6-23cc-4428-b688-5764d59baf44	library	C/tool-22-onepager.pdf	\N	2026-07-09 01:56:36.52238+00	2026-07-10 15:58:36.174745+00	2026-07-09 01:56:36.52238+00	{"eTag": "\\"7fc27699dcdbd167ca8eeccf1a7953a9\\"", "size": 71710, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:37.000Z", "contentLength": 71710, "httpStatusCode": 200}	0c282bb2-7283-43fc-b94a-0d1d3ce69009	\N	{}
495efad5-b2f0-49cb-a7c3-c8da25648b98	library	B/tool-20-onepager.pdf	\N	2026-07-09 01:56:35.676051+00	2026-07-10 15:58:35.04077+00	2026-07-09 01:56:35.676051+00	{"eTag": "\\"a62d97b8020d1288dea16f5f76131435\\"", "size": 74480, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:35.000Z", "contentLength": 74480, "httpStatusCode": 200}	cb54fa5f-0f30-4c3a-8f3f-31b081295961	\N	{}
9b8d7c66-2e12-4c08-b361-56045fdf0aea	library	C/tool-25-onepager.pdf	\N	2026-07-09 01:56:37.841946+00	2026-07-10 15:58:38.005636+00	2026-07-09 01:56:37.841946+00	{"eTag": "\\"2a9229d0a51cfcd0277f16be7490f2b1\\"", "size": 73308, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:38.000Z", "contentLength": 73308, "httpStatusCode": 200}	30c0732e-3bbd-4509-a779-bc5699f57558	\N	{}
30c608ea-c980-48be-bd83-81155f498da3	library	C/tool-27-kit.pdf	\N	2026-07-09 01:56:38.548053+00	2026-07-10 15:58:38.857989+00	2026-07-09 01:56:38.548053+00	{"eTag": "\\"23f8fc38ababa4f091d8b2b4d8a11b33\\"", "size": 41855, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:39.000Z", "contentLength": 41855, "httpStatusCode": 200}	c8ad2e10-e117-48d2-8232-810e9192666a	\N	{}
86439c89-8f32-4af0-99be-bd3656ca98d7	library	C/tool-28-onepager.pdf	\N	2026-07-09 01:56:39.270304+00	2026-07-10 15:58:39.621311+00	2026-07-09 01:56:39.270304+00	{"eTag": "\\"0c45831ecf08f4e96b8bce6f1864ec04\\"", "size": 70623, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:40.000Z", "contentLength": 70623, "httpStatusCode": 200}	1831fd77-8e3b-455f-b20f-bfd3dcdafdde	\N	{}
0cfd510d-0fd1-4af0-9ce8-4f9bc3a74c21	library	C/tool-26-kit.pdf	\N	2026-07-09 01:56:38.101541+00	2026-07-10 15:58:38.271693+00	2026-07-09 01:56:38.101541+00	{"eTag": "\\"ba888b4fd943f53596c1259c94676888\\"", "size": 35810, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:39.000Z", "contentLength": 35810, "httpStatusCode": 200}	4a0e9e43-c231-44a0-a89e-4ba171cc984b	\N	{}
52f6199d-414d-4725-8c89-1e21d9232d55	library	C/tool-27-onepager.pdf	\N	2026-07-09 01:56:38.732937+00	2026-07-10 15:58:39.083882+00	2026-07-09 01:56:38.732937+00	{"eTag": "\\"17c1b2c9712977db2378fad87d821905\\"", "size": 67100, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:40.000Z", "contentLength": 67100, "httpStatusCode": 200}	d83af7f6-a903-4913-8aca-2f2493422125	\N	{}
59291bf6-8281-44fe-9c89-1f86f664c537	library	C/tool-29-kit.pdf	\N	2026-07-09 01:56:39.515898+00	2026-07-10 15:58:39.977272+00	2026-07-09 01:56:39.515898+00	{"eTag": "\\"c1c4390efbc9cb3018610dc6e12faecb\\"", "size": 38864, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:40.000Z", "contentLength": 38864, "httpStatusCode": 200}	e4342cf9-2552-4a90-88f9-2d29b08d5d99	\N	{}
80c92c76-1706-4a2c-b261-c90c4c6c81e8	library	C/tool-24-kit.pdf	\N	2026-07-09 01:56:37.179915+00	2026-07-10 15:58:37.072376+00	2026-07-09 01:56:37.179915+00	{"eTag": "\\"0443318db19699f2566cd8d78c96e271\\"", "size": 35079, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:37.000Z", "contentLength": 35079, "httpStatusCode": 200}	97075c02-90cf-4352-a478-6639d0bf30a5	\N	{}
711a1f21-e3ec-46ac-8246-62254a4bcfbe	library	C/tool-29-onepager.pdf	\N	2026-07-09 01:56:39.688811+00	2026-07-10 15:58:40.263167+00	2026-07-09 01:56:39.688811+00	{"eTag": "\\"6ee46e03f2dc2c9c7700af8af1876eea\\"", "size": 66241, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:41.000Z", "contentLength": 66241, "httpStatusCode": 200}	f235c2b2-ac86-4688-915d-86cf6a7b0121	\N	{}
f6b33f6d-7368-4a2e-ab72-24fe797c373d	library	C/tool-28-kit.pdf	\N	2026-07-09 01:56:39.050865+00	2026-07-10 15:58:39.404373+00	2026-07-09 01:56:39.050865+00	{"eTag": "\\"24bf5ebc68f94dee39d9a3451f1d4b38\\"", "size": 46574, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:40.000Z", "contentLength": 46574, "httpStatusCode": 200}	3544bd59-7e68-4d7b-bd9c-bdb83b164193	\N	{}
88fd8846-2ed2-4b0d-9359-059830349f3e	library	C/tool-24-onepager.pdf	\N	2026-07-09 01:56:37.393863+00	2026-07-10 15:58:37.332535+00	2026-07-09 01:56:37.393863+00	{"eTag": "\\"fc32d7874835e49254af6b1043ba8faa\\"", "size": 71239, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:38.000Z", "contentLength": 71239, "httpStatusCode": 200}	4da5b22e-b2f7-4e02-a04c-4c212a6b0219	\N	{}
8aa555af-e5d8-4357-bba4-d6d33cf23a8e	library	C/tool-26-onepager.pdf	\N	2026-07-09 01:56:38.306228+00	2026-07-10 15:58:38.602735+00	2026-07-09 01:56:38.306228+00	{"eTag": "\\"66b678a320f835543a1a2d9f4544513c\\"", "size": 72789, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:39.000Z", "contentLength": 72789, "httpStatusCode": 200}	6d7e6fe5-5ac2-4fa6-9e43-bd07e4a33e2e	\N	{}
79370349-52a5-43c9-aaab-5d15194ee981	library	C/tool-25-kit.pdf	\N	2026-07-09 01:56:37.675643+00	2026-07-10 15:58:37.725216+00	2026-07-09 01:56:37.675643+00	{"eTag": "\\"d3aba50320cddaa798e6245ec5986c68\\"", "size": 36481, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:38.000Z", "contentLength": 36481, "httpStatusCode": 200}	edafecd8-7976-4df2-8ba7-dd51bd71bd9d	\N	{}
87239069-276b-42ad-96e2-5d51700687f3	library	D/tool-31-onepager.pdf	\N	2026-07-09 01:56:40.47562+00	2026-07-10 15:58:41.289667+00	2026-07-09 01:56:40.47562+00	{"eTag": "\\"00080d56b5190ce31935c5632f9d54d9\\"", "size": 73244, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:42.000Z", "contentLength": 73244, "httpStatusCode": 200}	0ef4c20a-912d-4df1-b667-ac0ba11a0a4c	\N	{}
31d6ec8f-8d35-4d70-b69c-2b42cf0fb2e6	library	D/tool-33-kit.pdf	\N	2026-07-09 01:56:41.100341+00	2026-07-10 15:58:42.070078+00	2026-07-09 01:56:41.100341+00	{"eTag": "\\"8b01b652306580679bc20e17a2bfab82\\"", "size": 56170, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:43.000Z", "contentLength": 56170, "httpStatusCode": 200}	f972a378-76f6-4e19-bfcc-64fa09e71d81	\N	{}
93598069-f633-4653-9fbd-3a84c8d94b1d	library	D/tool-34-onepager.pdf	\N	2026-07-09 01:56:41.752526+00	2026-07-10 15:58:43.001178+00	2026-07-09 01:56:41.752526+00	{"eTag": "\\"b263e8aa39f542721cf676cc931c4d92\\"", "size": 74738, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:43.000Z", "contentLength": 74738, "httpStatusCode": 200}	487b3eba-2dbb-4ed2-acc5-3c0a8aba43c9	\N	{}
7a2560e0-89d9-40a9-89a7-339a26d28e3e	library	D/tool-32-kit.pdf	\N	2026-07-09 01:56:40.703723+00	2026-07-10 15:58:41.576941+00	2026-07-09 01:56:40.703723+00	{"eTag": "\\"6859f11f6f5656327432bab5deafd615\\"", "size": 44643, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:42.000Z", "contentLength": 44643, "httpStatusCode": 200}	f34fd335-4ba1-4f6f-be6b-b2d8d1788646	\N	{}
13cad950-dc90-4cd2-bc52-7b5fe33547be	library	D/tool-33-onepager.pdf	\N	2026-07-09 01:56:41.285314+00	2026-07-10 15:58:42.294463+00	2026-07-09 01:56:41.285314+00	{"eTag": "\\"e598f4b0ea8a29400d6b110c8eb479ec\\"", "size": 74001, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:43.000Z", "contentLength": 74001, "httpStatusCode": 200}	70353752-551f-4cfc-91f2-d53834f6a2c2	\N	{}
371b702d-9fd8-4f03-af22-22ba42fa2e8e	library	E/tool-35-kit.pdf	\N	2026-07-09 01:56:41.953638+00	2026-07-10 15:58:43.293036+00	2026-07-09 01:56:41.953638+00	{"eTag": "\\"90187e77b92acd69f6f8fb4c6c3af2df\\"", "size": 77686, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:44.000Z", "contentLength": 77686, "httpStatusCode": 200}	3a16c261-4c05-411c-b69e-e8c8718dee7f	\N	{}
b9984d22-a087-47d7-93a3-fc2cbf5f320e	library	C/tool-30-kit.pdf	\N	2026-07-09 01:56:39.900867+00	2026-07-10 15:58:40.543354+00	2026-07-09 01:56:39.900867+00	{"eTag": "\\"9bd1112f01ac27bd23a0686a5cdd0a69\\"", "size": 57938, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:41.000Z", "contentLength": 57938, "httpStatusCode": 200}	ae1726ee-32e7-428b-b399-befe990dfbf2	\N	{}
7925abfc-c195-4d0e-bac1-872ac164cc0d	library	E/tool-35-onepager.pdf	\N	2026-07-09 01:56:42.189855+00	2026-07-10 15:58:43.584898+00	2026-07-09 01:56:42.189855+00	{"eTag": "\\"f2654142f080b283e6d60707cd7ada99\\"", "size": 71940, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:44.000Z", "contentLength": 71940, "httpStatusCode": 200}	70af6dac-981d-4f52-af8b-4d1bd2729666	\N	{}
42559509-be98-48a9-a9a0-0e76a5ee02a6	library	D/tool-34-kit.pdf	\N	2026-07-09 01:56:41.558812+00	2026-07-10 15:58:42.695961+00	2026-07-09 01:56:41.558812+00	{"eTag": "\\"6b6a4920b583374869483a12625ed6f3\\"", "size": 41689, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:43.000Z", "contentLength": 41689, "httpStatusCode": 200}	8ca3b0b3-03a5-4b07-8d18-ac61ed2a7956	\N	{}
3dad1b76-66cc-47ac-8f14-6639a007c811	library	C/tool-30-onepager.pdf	\N	2026-07-09 01:56:40.06652+00	2026-07-10 15:58:40.772926+00	2026-07-09 01:56:40.06652+00	{"eTag": "\\"119f9b1b911159f3bbcd40fe875c0204\\"", "size": 71124, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:41.000Z", "contentLength": 71124, "httpStatusCode": 200}	dc568177-30b1-4d51-a90e-e1ea13cbba9e	\N	{}
eb09bf05-0521-46a1-972d-60b2d91f8b5e	library	D/tool-32-onepager.pdf	\N	2026-07-09 01:56:40.911058+00	2026-07-10 15:58:41.812042+00	2026-07-09 01:56:40.911058+00	{"eTag": "\\"096189e506820d0fcc80d986e750d707\\"", "size": 74190, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:42.000Z", "contentLength": 74190, "httpStatusCode": 200}	ed9b14b5-16b7-48f2-a4b3-9b47f0b49f75	\N	{}
9ce07b51-696a-4377-9cf1-72bdb9f40ce1	library	D/tool-31-kit.pdf	\N	2026-07-09 01:56:40.276288+00	2026-07-10 15:58:41.032982+00	2026-07-09 01:56:40.276288+00	{"eTag": "\\"060e54692e87bdccf1e8d86d59d26618\\"", "size": 43686, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:41.000Z", "contentLength": 43686, "httpStatusCode": 200}	36d4db91-0e0b-4a8c-842b-af46df8e393e	\N	{}
6aba494a-5495-4f92-b296-5eecd706baef	library	E/tool-36-onepager.pdf	\N	2026-07-09 01:56:42.580239+00	2026-07-10 15:58:44.220034+00	2026-07-09 01:56:42.580239+00	{"eTag": "\\"076a3e0175be1e894acc643cc8627c7f\\"", "size": 71563, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:45.000Z", "contentLength": 71563, "httpStatusCode": 200}	74b16bb2-5732-47bb-bc7c-0283daaef6bb	\N	{}
8f5ea450-7901-407a-9643-fdf79a88f5b8	library	E/tool-38-onepager.pdf	\N	2026-07-09 01:56:43.406608+00	2026-07-10 15:58:46.210591+00	2026-07-09 01:56:43.406608+00	{"eTag": "\\"355c1061924851a225c6348f6974fb93\\"", "size": 72350, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:47.000Z", "contentLength": 72350, "httpStatusCode": 200}	84fc7aef-4184-4530-9ef4-c1310b9b290a	\N	{}
ac922469-c881-4129-9a9b-8dbd9b9a411a	library	E/tool-40-onepager.pdf	\N	2026-07-09 01:56:44.278509+00	2026-07-10 15:58:47.561381+00	2026-07-09 01:56:44.278509+00	{"eTag": "\\"effad29cef35e2bb8f478f1d760fb8e3\\"", "size": 71688, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:48.000Z", "contentLength": 71688, "httpStatusCode": 200}	f2536199-4de6-4da3-88d6-ffaedf9f5dbd	\N	{}
6525c14f-dbaa-4680-8754-a078dad6d3dd	library	E/tool-39-kit.pdf	\N	2026-07-09 01:56:43.639582+00	2026-07-10 15:58:46.499805+00	2026-07-09 01:56:43.639582+00	{"eTag": "\\"977559d3925fda634f4a8c783fb0053c\\"", "size": 48385, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:47.000Z", "contentLength": 48385, "httpStatusCode": 200}	ae6f7fed-7f20-46ba-9911-ce5f6f5db54d	\N	{}
4de9f039-12c4-4dc1-9ba0-80b91aaa8e5d	library	E/tool-41-kit.pdf	\N	2026-07-09 01:56:44.499389+00	2026-07-10 15:58:47.876384+00	2026-07-09 01:56:44.499389+00	{"eTag": "\\"38d02a5aa50f9ae48475fe4a594c1e27\\"", "size": 48070, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:48.000Z", "contentLength": 48070, "httpStatusCode": 200}	463af5d2-f752-4388-b47b-0300278e75ea	\N	{}
a57a7968-b32e-4e3b-993c-252128d07d14	library	E/tool-39-onepager.pdf	\N	2026-07-09 01:56:43.85261+00	2026-07-10 15:58:47.00454+00	2026-07-09 01:56:43.85261+00	{"eTag": "\\"34772067a9ba3b2198e1625edea6f29a\\"", "size": 73401, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:47.000Z", "contentLength": 73401, "httpStatusCode": 200}	6b027399-daa3-4451-a044-468534881152	\N	{}
e146fefb-493a-47f4-9d72-20e1c048f246	library	E/tool-37-kit.pdf	\N	2026-07-09 01:56:42.786183+00	2026-07-10 15:58:44.499221+00	2026-07-09 01:56:42.786183+00	{"eTag": "\\"dd4186cf7b736441f5b067bd0a1a6d28\\"", "size": 59955, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:45.000Z", "contentLength": 59955, "httpStatusCode": 200}	d0732696-0283-4f07-bd9f-6bcbcb1814df	\N	{}
d6864a9a-2902-4133-8b8b-62a32edec843	library	E/tool-36-kit.pdf	\N	2026-07-09 01:56:42.403056+00	2026-07-10 15:58:43.893456+00	2026-07-09 01:56:42.403056+00	{"eTag": "\\"e26a2bc4c6056fcc598aa316d118bb03\\"", "size": 58970, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:44.000Z", "contentLength": 58970, "httpStatusCode": 200}	93a55a0b-2edc-4976-b43d-0c7cb5135d30	\N	{}
2df4c892-5aed-4f03-a475-892e74e57cf6	library	E/tool-37-onepager.pdf	\N	2026-07-09 01:56:42.961746+00	2026-07-10 15:58:44.814385+00	2026-07-09 01:56:42.961746+00	{"eTag": "\\"07506d24934a3dc6a369cfc396763e7e\\"", "size": 72945, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:45.000Z", "contentLength": 72945, "httpStatusCode": 200}	99f212df-524d-41a8-bfdb-9f2418ba5cb3	\N	{}
cd277fb0-ac00-4252-a1da-1ef988790334	library	E/tool-40-kit.pdf	\N	2026-07-09 01:56:44.104722+00	2026-07-10 15:58:47.259796+00	2026-07-09 01:56:44.104722+00	{"eTag": "\\"0aea93629bafee861d9761bb117edb29\\"", "size": 48629, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:48.000Z", "contentLength": 48629, "httpStatusCode": 200}	e3fd4213-247a-400f-bbe7-8235c0d70437	\N	{}
340c9808-11c1-45bf-866e-5a9065f4fd05	library	E/tool-38-kit.pdf	\N	2026-07-09 01:56:43.197558+00	2026-07-10 15:58:45.679836+00	2026-07-09 01:56:43.197558+00	{"eTag": "\\"1cddbb971fa5e115e5c991aa917500aa\\"", "size": 40569, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:46.000Z", "contentLength": 40569, "httpStatusCode": 200}	043bc90c-4ae2-4dc2-85e0-3e1eb84ac99d	\N	{}
fcfc1deb-9ee9-4110-b086-b65f7a4339bb	library	E/tool-43-kit.pdf	\N	2026-07-09 01:56:45.377863+00	2026-07-10 15:58:49.006701+00	2026-07-09 01:56:45.377863+00	{"eTag": "\\"d5e73e9a9f58b271e76d5781f513f604\\"", "size": 46536, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:49.000Z", "contentLength": 46536, "httpStatusCode": 200}	94da6c60-f6ee-4b0b-9c25-1b7413b9cc88	\N	{}
e6da9026-3cd3-4857-bc2a-9470d356dbb7	library	E/tool-43-onepager.pdf	\N	2026-07-09 01:56:45.56858+00	2026-07-10 15:58:49.221926+00	2026-07-09 01:56:45.56858+00	{"eTag": "\\"b1f5304cfc5c007a85d7a28519d26837\\"", "size": 70578, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:50.000Z", "contentLength": 70578, "httpStatusCode": 200}	23d1a608-bced-450d-ac10-0d307b7ae6f8	\N	{}
39501ee8-d21b-4ba1-a9d1-d8bd9eb552d0	library	E/tool-41-onepager.pdf	\N	2026-07-09 01:56:44.700027+00	2026-07-10 15:58:48.105367+00	2026-07-09 01:56:44.700027+00	{"eTag": "\\"79a270aa7e46284072cac7361e5eb571\\"", "size": 70726, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:49.000Z", "contentLength": 70726, "httpStatusCode": 200}	2d83c2c0-30c6-4126-9ca8-967386527c10	\N	{}
b4508325-a9e5-4a25-b769-f3be616c2924	library	E/tool-42-kit.pdf	\N	2026-07-09 01:56:44.932931+00	2026-07-10 15:58:48.517095+00	2026-07-09 01:56:44.932931+00	{"eTag": "\\"3c8d78c5989cb177685a39ec79da496c\\"", "size": 54203, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:49.000Z", "contentLength": 54203, "httpStatusCode": 200}	6d337d98-b970-466d-a1c5-338c5da23502	\N	{}
226b0640-ebfb-4b2c-9083-20a555fb32eb	library	E/tool-42-onepager.pdf	\N	2026-07-09 01:56:45.175952+00	2026-07-10 15:58:48.70928+00	2026-07-09 01:56:45.175952+00	{"eTag": "\\"aa4b633204489dada70e86945471099d\\"", "size": 71232, "mimetype": "application/pdf", "cacheControl": "no-cache", "lastModified": "2026-07-10T15:58:49.000Z", "contentLength": 71232, "httpStatusCode": 200}	a3c13e72-ba2e-4868-9f8b-0de70eb7c465	\N	{}
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: account_licenses account_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_licenses
    ADD CONSTRAINT account_licenses_pkey PRIMARY KEY (id);


--
-- Name: assessments assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT assessments_pkey PRIMARY KEY (id);


--
-- Name: career_guidance_reports career_guidance_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.career_guidance_reports
    ADD CONSTRAINT career_guidance_reports_pkey PRIMARY KEY (id);


--
-- Name: client_accounts client_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_pkey PRIMARY KEY (id);


--
-- Name: client_accounts client_accounts_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_accounts
    ADD CONSTRAINT client_accounts_slug_key UNIQUE (slug);


--
-- Name: client_users client_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_users
    ADD CONSTRAINT client_users_email_key UNIQUE (email);


--
-- Name: client_users client_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_users
    ADD CONSTRAINT client_users_pkey PRIMARY KEY (id);


--
-- Name: detection_feedback detection_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detection_feedback
    ADD CONSTRAINT detection_feedback_pkey PRIMARY KEY (id);


--
-- Name: fit_results fit_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fit_results
    ADD CONSTRAINT fit_results_pkey PRIMARY KEY (id);


--
-- Name: library_items library_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_items
    ADD CONSTRAINT library_items_pkey PRIMARY KEY (id);


--
-- Name: library_items library_items_tool_num_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_items
    ADD CONSTRAINT library_items_tool_num_key UNIQUE (tool_num);


--
-- Name: mirror_tokens mirror_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mirror_tokens
    ADD CONSTRAINT mirror_tokens_pkey PRIMARY KEY (id);


--
-- Name: mirror_tokens mirror_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mirror_tokens
    ADD CONSTRAINT mirror_tokens_token_key UNIQUE (token);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_stripe_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_stripe_session_id_key UNIQUE (stripe_session_id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_token_key UNIQUE (token);


--
-- Name: tool_sessions tool_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_sessions
    ADD CONSTRAINT tool_sessions_pkey PRIMARY KEY (id);


--
-- Name: writing_samples writing_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.writing_samples
    ADD CONSTRAINT writing_samples_pkey PRIMARY KEY (id);


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages
    ADD CONSTRAINT messages_payload_exclusive CHECK (((payload IS NULL) OR (binary_payload IS NULL))) NOT VALID;


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_created_at_desc ON auth.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_last_sign_in_at_desc ON auth.users USING btree (last_sign_in_at DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_users_name ON auth.users USING btree (((raw_user_meta_data ->> 'name'::text))) WHERE ((raw_user_meta_data ->> 'name'::text) IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: account_licenses_account_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_licenses_account_id_idx ON public.account_licenses USING btree (account_id);


--
-- Name: assessments_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX assessments_token_idx ON public.assessments USING btree (token);


--
-- Name: client_users_account_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_users_account_id_idx ON public.client_users USING btree (account_id);


--
-- Name: client_users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_users_email_idx ON public.client_users USING btree (email);


--
-- Name: detection_feedback_labeled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX detection_feedback_labeled_idx ON public.detection_feedback USING btree (actual_profile) WHERE (actual_profile IS NOT NULL);


--
-- Name: detection_feedback_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX detection_feedback_user_created_idx ON public.detection_feedback USING btree (user_id, created_at);


--
-- Name: library_items_collection_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX library_items_collection_idx ON public.library_items USING btree (collection);


--
-- Name: library_items_item_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX library_items_item_type_idx ON public.library_items USING btree (item_type);


--
-- Name: library_items_item_type_profile_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX library_items_item_type_profile_idx ON public.library_items USING btree (item_type, profile);


--
-- Name: mirror_tokens_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mirror_tokens_token_idx ON public.mirror_tokens USING btree (token);


--
-- Name: password_reset_tokens_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_reset_tokens_token_idx ON public.password_reset_tokens USING btree (token);


--
-- Name: password_reset_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_reset_tokens_user_id_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: purchases_buyer_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_buyer_email_idx ON public.purchases USING btree (buyer_email);


--
-- Name: purchases_stripe_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_stripe_session_id_idx ON public.purchases USING btree (stripe_session_id);


--
-- Name: tokens_account_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tokens_account_id_idx ON public.tokens USING btree (account_id);


--
-- Name: tool_sessions_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_sessions_account_idx ON public.tool_sessions USING btree (account_id);


--
-- Name: tool_sessions_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tool_sessions_user_created_idx ON public.tool_sessions USING btree (user_id, created_at);


--
-- Name: writing_samples_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX writing_samples_token_idx ON public.writing_samples USING btree (mirror_token_id, created_at);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_selec ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter, COALESCE(selected_columns, '{}'::text[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: account_licenses account_licenses_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_licenses
    ADD CONSTRAINT account_licenses_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.client_accounts(id) ON DELETE CASCADE;


--
-- Name: client_users client_users_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_users
    ADD CONSTRAINT client_users_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.client_accounts(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.client_users(id) ON DELETE CASCADE;


--
-- Name: tokens tokens_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.client_accounts(id);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: account_licenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.account_licenses ENABLE ROW LEVEL SECURITY;

--
-- Name: assessments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;

--
-- Name: career_guidance_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.career_guidance_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: client_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.client_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: client_users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.client_users ENABLE ROW LEVEL SECURITY;

--
-- Name: detection_feedback; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.detection_feedback ENABLE ROW LEVEL SECURITY;

--
-- Name: fit_results; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fit_results ENABLE ROW LEVEL SECURITY;

--
-- Name: library_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.library_items ENABLE ROW LEVEL SECURITY;

--
-- Name: mirror_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mirror_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: password_reset_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.password_reset_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: purchases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;

--
-- Name: tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: tool_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tool_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: writing_samples; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.writing_samples ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict MYb0vGVg88gallReJ6QMCYz96diqSY51a28ZIkh5djWeRRvkI7CcQaMKLHKf87N

